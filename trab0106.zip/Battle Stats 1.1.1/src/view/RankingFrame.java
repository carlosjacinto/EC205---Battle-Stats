package view;

public class RankingFrame {

}
