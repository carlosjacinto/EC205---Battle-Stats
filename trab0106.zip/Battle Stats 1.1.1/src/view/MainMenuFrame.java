package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JButton;

public class MainMenuFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 595002342231123046L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenuFrame frame = new MainMenuFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainMenuFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("D:\\workpace\\Battle Stats 1.1.1\\Media\\Cover4 - LD.jpg"));
		contentPane.add(label, BorderLayout.WEST);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("D:\\workpace\\Battle Stats 1.1.1\\Media\\Cover4 - LE.jpg"));
		contentPane.add(label_1, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("Novo Personagem");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(new Color(218, 59, 1));
		btnNewButton.setBounds(10, 141, 420, 23);
		panel.add(btnNewButton);
		
		JButton button = new JButton("Editar Personagem");
		button.setFont(new Font("Tahoma", Font.BOLD, 12));
		button.setForeground(Color.WHITE);
		button.setBackground(new Color(218, 59, 1));
		button.setBounds(10, 175, 420, 23);
		panel.add(button);
		
		JButton button_1 = new JButton("Ver Personagens");
		button_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(218, 59, 1));
		button_1.setBounds(10, 209, 420, 23);
		panel.add(button_1);
		
		JButton button_2 = new JButton("Excluir Personagens");
		button_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(new Color(218, 59, 1));
		button_2.setBounds(10, 243, 420, 23);
		panel.add(button_2);
		
		JButton button_3 = new JButton("Ver Armas");
		button_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(new Color(218, 59, 1));
		button_3.setBounds(10, 277, 420, 23);
		panel.add(button_3);
		
		JButton button_4 = new JButton("Ver Ve�culos");
		button_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_4.setForeground(Color.WHITE);
		button_4.setBackground(new Color(218, 59, 1));
		button_4.setBounds(10, 311, 420, 23);
		panel.add(button_4);
		
		JButton button_5 = new JButton("Ver Classes");
		button_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_5.setForeground(Color.WHITE);
		button_5.setBackground(new Color(218, 59, 1));
		button_5.setBounds(10, 345, 420, 23);
		panel.add(button_5);
		
		JButton button_6 = new JButton("Ver Minha Conta");
		button_6.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_6.setForeground(Color.WHITE);
		button_6.setBackground(new Color(218, 59, 1));
		button_6.setBounds(10, 379, 420, 23);
		panel.add(button_6);
		
		JButton button_7 = new JButton("Editar Minha Conta");
		button_7.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_7.setForeground(Color.WHITE);
		button_7.setBackground(new Color(218, 59, 1));
		button_7.setBounds(10, 413, 420, 23);
		panel.add(button_7);
		
		JButton button_8 = new JButton("Ranking dos Jogadores");
		button_8.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_8.setForeground(Color.WHITE);
		button_8.setBackground(new Color(218, 59, 1));
		button_8.setBounds(10, 447, 420, 23);
		panel.add(button_8);
		
		JButton button_9 = new JButton("Voltar");
		button_9.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_9.setForeground(Color.WHITE);
		button_9.setBackground(new Color(218, 59, 1));
		button_9.setBounds(10, 481, 420, 23);
		panel.add(button_9);
	}

}
