package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import control.ArmaDAO;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JTable;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class ListarArmaFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 94051881786682991L;
	private JPanel contentPane;
	private JTable table;
	private JTable table2;
	private ArmaDAO armaDAO = new ArmaDAO();
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListarArmaFrame frame = new ListarArmaFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListarArmaFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("D:\\workpace\\Battle Stats 1.1.1\\Media\\ArmaCover LE.jpg"));
		contentPane.add(label, BorderLayout.WEST);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		ArrayList<String> teste = armaDAO.buscaArma();
		
		String[] colunas = { "Nome", "Tipo","Dano","Alcance","Precis�o","Tiro sem Visada","Estabilidade","Cadencia","Capacidade" };
		String[][] dados = armaDAO.listaArma();
		table = new JTable(dados,colunas);
		table.setFont(new Font("Tahoma", Font.PLAIN, 11));
		table.setBounds(10, 11, 404, 697);
		panel.add(table);
		
		JScrollPane scrollBar = new JScrollPane(table);
		scrollBar.setBounds(63, 11, 817, 277);
		panel.add(scrollBar);
		
		String[] colunas2 = { "Nome", "Tipo"};
		String[][] dados2 = armaDAO.listaAcessorio();
		table_1 = new JTable(dados2,colunas2);
		table_1.setBounds(192, 299, 672, 212);
		panel.add(table_1);
		
		JScrollPane scrollBar_1 = new JScrollPane(table_1);
		scrollBar_1.setBounds(484, 299, 396, 212);
		panel.add(scrollBar_1);
		
	}
}
