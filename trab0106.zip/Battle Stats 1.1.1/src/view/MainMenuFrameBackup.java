package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MainMenuFrameBackup extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6727930359206926641L;
	
	JButton novoPersonagemBt = new JButton("Novo personagem");
	JButton editarPersonagemBt = new JButton("Editar um personagem");
	JButton verPersonagensBt = new JButton("Ver personagens");
	JButton excluirPersonagemBt = new JButton("Excluir um personagem");
	JButton verArmasBt = new JButton("Ver armas");
	JButton verVeiculosBt= new JButton("Ver veiculos");
	JButton verClassesBt = new JButton("Ver classes");
	JButton verContaBt = new JButton("Ver minha conta");
	JButton editarContaBt = new JButton("Editar minha conta");
	JButton rankingBt = new JButton("Ranking de jogadores");
	JButton voltarBt = new JButton("Voltar");
	
	JPanel jp = new JPanel(new GridLayout(0, 1));
	JLabel background=new JLabel(new ImageIcon("Media/Default.jpg"));
	
	public MainMenuFrameBackup() {
		
		setTitle("Main Menu");
		setSize(1366,768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setLayout(new BorderLayout());
		
		config();
		adicionar();
		
		refresh();
	}
	
	private void refresh(){
		setSize(1360,760);
		setSize(1366,768);
	}
	
	private void adicionar(){
		add(background);
		background.setLayout(new GridBagLayout());
		jp.add(novoPersonagemBt);
		jp.add(editarPersonagemBt);
		jp.add(verPersonagensBt);
		jp.add(excluirPersonagemBt);
		jp.add(verArmasBt);
		jp.add(verVeiculosBt);
		jp.add(verClassesBt);
		jp.add(verContaBt);
		jp.add(editarContaBt);
		jp.add(rankingBt);
		jp.add(voltarBt);
		background.add(jp);
	}
	
	private void config(){
		novoPersonagemBt.setActionCommand("novoPersonagem");
		novoPersonagemBt.addActionListener(this);
		novoPersonagemBt.setBackground(new Color(255, 0, 0));
		novoPersonagemBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		novoPersonagemBt.setForeground(Color.WHITE);
		editarPersonagemBt.setActionCommand("editarPersonagem");
		editarPersonagemBt.addActionListener(this);
		editarPersonagemBt.setBackground(new Color(250, 95, 0));
		editarPersonagemBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		editarPersonagemBt.setForeground(Color.WHITE);
		verPersonagensBt.setActionCommand("verPersonagens");
		verPersonagensBt.addActionListener(this);
		verPersonagensBt.setBackground(new Color(255, 0, 0));
		verPersonagensBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		verPersonagensBt.setForeground(Color.WHITE);
		excluirPersonagemBt.setActionCommand("excluirPersonagem");
		excluirPersonagemBt.addActionListener(this);
		excluirPersonagemBt.setBackground(new Color(250, 95, 0));
		excluirPersonagemBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		excluirPersonagemBt.setForeground(Color.WHITE);
		verArmasBt.setActionCommand("verArmas");
		verArmasBt.addActionListener(this);
		verArmasBt.setBackground(new Color(255, 0, 0));
		verArmasBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		verArmasBt.setForeground(Color.WHITE);
		verVeiculosBt.setActionCommand("verVeiculos");
		verVeiculosBt.addActionListener(this);
		verVeiculosBt.setBackground(new Color(250, 95, 0));
		verVeiculosBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		verVeiculosBt.setForeground(Color.WHITE);
		verClassesBt.setActionCommand("verClasses");
		verClassesBt.addActionListener(this);
		verClassesBt.setBackground(new Color(255, 0, 0));
		verClassesBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		verClassesBt.setForeground(Color.WHITE);
		verContaBt.setActionCommand("verConta");
		verContaBt.addActionListener(this);
		verContaBt.setBackground(new Color(250, 95, 0));
		verContaBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		verContaBt.setForeground(Color.WHITE);
		editarContaBt.setActionCommand("editarConta");
		editarContaBt.addActionListener(this);
		editarContaBt.setBackground(new Color(255, 0, 0));
		editarContaBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		editarContaBt.setForeground(Color.WHITE);
		rankingBt.setActionCommand("ranking");
		rankingBt.addActionListener(this);
		rankingBt.setBackground(new Color(250, 95, 0));
		rankingBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		rankingBt.setForeground(Color.WHITE);
		voltarBt.setActionCommand("voltar");
		voltarBt.addActionListener(this);
		voltarBt.setBackground(new Color(255, 0, 0));
		voltarBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		voltarBt.setForeground(Color.WHITE);
	}
	
	public void actionPerformed(ActionEvent e) {
		if("voltar".equals(e.getActionCommand())){
			dispose();
			new LoginFrame();
		}
		else if("novoPersonagem".equals(e.getActionCommand())){
			dispose();
			new CadastroPersonagemFrame();
		}
		else if("editarPersonagem".equals(e.getActionCommand())){
			dispose();
			new EditarPersonagemFrame();
		}
		else if("verPersonagem".equals(e.getActionCommand())){
			dispose();
			new ListarPersonagemFrame();
		}
		else if("excluirPersonagem".equals(e.getActionCommand())){
			dispose();
			new ExcluirPersonagemFrame();
		}
		else if("verArmas".equals(e.getActionCommand())){
			dispose();
			new ListarArmaFrame();
		}
		else if("verVeiculos".equals(e.getActionCommand())){
			dispose();
			new ListarVeiculoFrame();
		}
		else if("verConta".equals(e.getActionCommand())){
			dispose();
			new ListarJogadorFrame();
		}
		else if("verClasse".equals(e.getActionCommand())){
			dispose();
			new ListarClasseFrame();
		}
		else if("editarConta".equals(e.getActionCommand())){
			dispose();
			new EditarJogadorFrame();
		}
		else if("ranking".equals(e.getActionCommand())){
			dispose();
			new RankingFrame();
		}
	}
	
}
