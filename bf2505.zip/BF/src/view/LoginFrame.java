package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/*import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;*/

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import control.DataBase;
import control.EmailValidator;

public class LoginFrame extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1999667136136945782L;
	
	DataBase bd = new DataBase();
	//Connection conex = bd.Conectar();
	JTextField emailTxt = new JTextField(40);
	JPasswordField senhaTxt =  new JPasswordField(40);
	JTextArea emailTxtAr = new JTextArea("E-mail",1,40);
	JTextArea senhaTxtAr = new JTextArea("Senha",1,40);
	JButton okBt = new JButton("Login");
	JButton cadastroBt = new JButton("Nova conta");
	
	JPanel jp = new JPanel(new GridLayout(0, 1));
	JLabel background=new JLabel(new ImageIcon("imagens/Default.jpg"));
	
	public LoginFrame() {
		
		setTitle("Login");
		setSize(1366,768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setLayout(new BorderLayout());
		
		config();
		adicionar();
		
		refresh();
	}
	
	private void refresh(){
		setSize(1360,760);
		setSize(1366,768);
	}
	
	private void adicionar(){
		add(background);
		background.setLayout(new GridBagLayout());
		jp.add(emailTxtAr);
		jp.add(emailTxt);
		jp.add(senhaTxtAr);
		jp.add(senhaTxt);
		jp.add(okBt);
		jp.add(cadastroBt);
		background.add(jp);
	}
	
	private void config(){
		emailTxtAr.setEditable(false);
		emailTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		emailTxtAr.setBackground(new Color(0, 0, 0));
		emailTxtAr.setForeground(Color.WHITE);
		senhaTxtAr.setEditable(false);
		senhaTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		senhaTxtAr.setBackground(new Color(0, 0, 0));
		senhaTxtAr.setForeground(Color.WHITE);
		okBt.setActionCommand("loginB");
		okBt.addActionListener(this);
		okBt.setBackground(new Color(250, 95, 0));
		okBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		okBt.setForeground(Color.WHITE);
		cadastroBt.setActionCommand("cadastroB");
		cadastroBt.addActionListener(this);
		cadastroBt.setBackground(new Color(255, 0, 0));
		cadastroBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cadastroBt.setForeground(Color.WHITE);
	}
	/*
	public boolean Login(String snome, String ssenha) {
		conex = bd.Conectar();
		
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador";
			ResultSet rs = stmt.executeQuery(SQL);
			
			while (rs.next()) {
				
				String nome = rs.getString("email");
				System.out.println(nome);
				System.out.println(snome);
				String senha = rs.getString("senha");
				System.out.println(ssenha);
				System.out.println(senha);
				if (senha.equals(ssenha) && snome.equals(nome)) {
					
					JOptionPane.showMessageDialog(new JFrame(),"Bem vindo " + rs.getString("nomeDeUsuario") + " ao programa Battle Stats!!!!", "Bem Vindo", JOptionPane.OK_OPTION);
					return true;
				}
			}
			rs.close();
			stmt.close();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		
		return false;
	}
	
	public boolean LoginAdm(String snome, String ssenha) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM usuariosadmin WHERE email LIKE '" + snome + "' AND senha LIKE '" + ssenha
					+ "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("email");
				String senha = rs.getString("senha");

				if (senha.equals(ssenha) && snome.equals(nome)) {
					JOptionPane.showMessageDialog(new JFrame(),"Bem vindo " + rs.getString("nome") + " ao programa Battle Stats!!!!", "Bem Vindo", JOptionPane.OK_OPTION);
					return true;
				}
			}
			rs.close();
			stmt.close();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		
		return false;
	}*/

	public void actionPerformed(ActionEvent e) {
		if("loginB".equals(e.getActionCommand())){
			
			if(emailTxt.getText().equals("") || senhaTxt.getPassword().equals("")){
				JOptionPane.showMessageDialog(new JFrame(), "Entre com o nome de usu�rio e senha","Campos em branco", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			EmailValidator emailValidator = new EmailValidator();
			if(!emailValidator.validate(emailTxt.getText().trim())){
				JOptionPane.showMessageDialog(new JFrame(),"Digite um e-mail v�lido","E-mail inv�lido!", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			/*if(Login(emailTxt.getText(), senhaTxt.getText().toString())){
				
			}
			
			if(LoginAdm(emailTxt.getText(), senhaTxt.getText().toString())){
				
			}
			JOptionPane.showMessageDialog(new JFrame(), "N�o encontramos nenhum usu�rio, verifique seus dados!","Usu�rio n�o existe!", JOptionPane.ERROR_MESSAGE);			
			 */
		}
		
		else{
			
		}
	}
	
}
