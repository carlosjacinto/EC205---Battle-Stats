package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import control.DataBase;
import model.Arma;

public class CadastroArmaFrame extends JFrame implements ActionListener {
	DataBase bd = new DataBase();
	Connection conex = bd.Conectar();
	/**
	 * 
	 */
	private static final long serialVersionUID = 7180513158489494234L;

	private String[] tipos = { "Assalto", "ADP", "M.L.", "Rifle de precis�o", "Carabina", "Escopeta", "DMR", "Pistola" };
	JComboBox<String> tiposArma = new JComboBox<>(tipos);
	JSlider danoSlider = new JSlider(0,100);

	JTextField nomeTxt = new JTextField(40);
	JTextField danoTxt = new JTextField(40);  //TODO: TIRAR
	JTextField alcanceTxt = new JTextField(40);
	JTextField precisaoTxt = new JTextField(40);
	JTextField tiroSemVisadaTxt = new JTextField(40);
	JTextField estabilidadeTxt = new JTextField(40);
	JTextField cadenciaTxt = new JTextField(40);
	JTextField capacidadeTxt = new JTextField(40);
	JTextArea nomeTxtAr = new JTextArea("Nome", 1, 10);
	JTextArea danoTxtAr = new JTextArea("Dano", 1, 10);
	JTextArea alcanceTxtAr = new JTextArea("Alcance", 1, 10);
	JTextArea precisaoTxtAr = new JTextArea("Precis�o", 1, 10);
	JTextArea tiroSemVisadaTxtAr = new JTextArea("Tiro sem visada", 1, 10);
	JTextArea estabilidadeTxtAr = new JTextArea("Establilidade", 1, 10);
	JTextArea cadenciaTxtAr = new JTextArea("Cad�ncia", 1, 10);
	JTextArea capacidadeTxtAr = new JTextArea("Capacidade do pente", 1, 10);

	JButton okBt = new JButton("Confirmar");
	JButton cancelaBt = new JButton("Cancelar");

	JCheckBox check = new JCheckBox("Acess�rio");

	JPanel jp = new JPanel(new GridLayout(0, 1));
	JLabel background=new JLabel(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.1\\Images/Default.jpg"));
	
	public CadastroArmaFrame() {
		
		setTitle("Main Menu");
		setSize(1366,768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setLayout(new BorderLayout());
		
		config();
		adicionar();
		refresh();

	}
	
	private void refresh(){
		setSize(1360,760);
		setSize(1366,768);
	}
	
	private void config(){
		tiposArma.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		tiposArma.setBackground(new Color(100, 100, 100));
		tiposArma.setForeground(Color.WHITE);
		nomeTxtAr.setEditable(false);
		nomeTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		nomeTxtAr.setBackground(new Color(0, 0, 0));
		nomeTxtAr.setForeground(Color.WHITE);
		danoTxtAr.setEditable(false);
		danoTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		danoTxtAr.setBackground(new Color(0, 0, 0));
		danoTxtAr.setForeground(Color.WHITE);
		alcanceTxtAr.setEditable(false);
		alcanceTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		alcanceTxtAr.setBackground(new Color(0, 0, 0));
		alcanceTxtAr.setForeground(Color.WHITE);
		precisaoTxtAr.setEditable(false);
		precisaoTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		precisaoTxtAr.setBackground(new Color(0, 0, 0));
		precisaoTxtAr.setForeground(Color.WHITE);
		tiroSemVisadaTxtAr.setEditable(false);
		tiroSemVisadaTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		tiroSemVisadaTxtAr.setBackground(new Color(0, 0, 0));
		tiroSemVisadaTxtAr.setForeground(Color.WHITE);
		estabilidadeTxtAr.setEditable(false);
		estabilidadeTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		estabilidadeTxtAr.setBackground(new Color(0, 0, 0));
		estabilidadeTxtAr.setForeground(Color.WHITE);
		cadenciaTxtAr.setEditable(false);
		cadenciaTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cadenciaTxtAr.setBackground(new Color(0, 0, 0));
		cadenciaTxtAr.setForeground(Color.WHITE);
		capacidadeTxtAr.setEditable(false);
		capacidadeTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		capacidadeTxtAr.setBackground(new Color(0, 0, 0));
		capacidadeTxtAr.setForeground(Color.WHITE);
		check.addActionListener(this);
		check.setBackground(new Color(255, 0, 0));
		check.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		check.setForeground(Color.WHITE);
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		okBt.setBackground(new Color(255, 0, 0));
		okBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		okBt.setForeground(Color.WHITE);
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		cancelaBt.setBackground(new Color(250, 95, 0));
		cancelaBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cancelaBt.setForeground(Color.WHITE);
	}
	
	private void adicionar(){
		add(background);
		background.setLayout(new GridBagLayout());
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tiposArma);
		jp.add(check);
		jp.add(danoTxtAr);
		//jp.add(danoTxt);
		jp.add(danoSlider);
		jp.add(alcanceTxtAr);
		jp.add(alcanceTxt);
		jp.add(precisaoTxtAr);
		jp.add(precisaoTxt);
		jp.add(tiroSemVisadaTxtAr);
		jp.add(tiroSemVisadaTxt);
		jp.add(estabilidadeTxtAr);
		jp.add(estabilidadeTxt);
		jp.add(cadenciaTxtAr);
		jp.add(cadenciaTxt);
		jp.add(capacidadeTxtAr);
		jp.add(capacidadeTxt);
		jp.add(okBt);
		jp.add(cancelaBt);
		background.add(jp);
	}

	boolean temCampoEmBranco() {
		if (nomeTxt.getText().equals(""))
			return true;
		if (danoTxt.getText().equals(""))
			return true;
		if (alcanceTxt.getText().equals(""))
			return true;
		if (precisaoTxt.getText().equals(""))
			return true;
		if (tiroSemVisadaTxt.getText().equals(""))
			return true;
		if (estabilidadeTxt.getText().equals(""))
			return true;
		if (cadenciaTxt.getText().equals(""))
			return true;
		if (capacidadeTxt.getText().equals(""))
			return true;
		return false;
	}

	public void actionPerformed(ActionEvent e) {

		if ("confirma".equals(e.getActionCommand())) {
			Arma novaArma = new Arma();
			if (!check.isSelected()) {
				if (temCampoEmBranco()) {
					JOptionPane.showMessageDialog(new JFrame(), "Preencha todos os campos", "Campos em branco",
							JOptionPane.WARNING_MESSAGE);
					return;
				}

				novaArma.setNome(nomeTxt.getText());
				novaArma.setTipo(tiposArma.getSelectedItem().toString());
				novaArma.setDano(Integer.parseInt(danoTxt.getText()));

				novaArma.setAcessorio(0);
				novaArma.setAlcance(Integer.parseInt(alcanceTxt.getText()));
				novaArma.setPrecisao(Integer.parseInt(precisaoTxt.getText()));
				novaArma.setTiroSemVisada(Integer.parseInt(tiroSemVisadaTxt.getText()));
				novaArma.setCadencia(Integer.parseInt(cadenciaTxt.getText()));
				novaArma.setCapacidadeDoPente(Integer.parseInt(capacidadeTxt.getText()));
				novaArma.setEstabilidade(Integer.parseInt(estabilidadeTxt.getText()));
			} else{
				novaArma.setNome(nomeTxt.getText());
				novaArma.setTipo(tiposArma.getSelectedItem().toString());
				novaArma.setAcessorio(1);
				if(nomeTxt.getText().equals("")){
					JOptionPane.showMessageDialog(new JFrame(), "Preencha todos os campos", "Campos em branco",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
			}
				

			if ((buscarArma(novaArma.getNome()) != null)) {
				JOptionPane.showMessageDialog(new JFrame(), "Arma j� cadastrada no sistema!", "Erro!",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			gravarArma(novaArma);
			JOptionPane.showMessageDialog(new JFrame(), "Arma cadastrada no sistema!", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
			dispose();
		}
		if ("cancela".equals(e.getActionCommand())) {
			return;
		}

		if (check.isSelected()) {
			danoTxt.setVisible(false);
			danoTxtAr.setVisible(false);
			alcanceTxt.setVisible(false);
			alcanceTxtAr.setVisible(false);
			precisaoTxt.setVisible(false);
			precisaoTxtAr.setVisible(false);
			tiroSemVisadaTxt.setVisible(false);
			tiroSemVisadaTxtAr.setVisible(false);
			estabilidadeTxt.setVisible(false);
			estabilidadeTxtAr.setVisible(false);
			cadenciaTxt.setVisible(false);
			cadenciaTxtAr.setVisible(false);
			capacidadeTxt.setVisible(false);
			capacidadeTxtAr.setVisible(false);
			return;
		} else {
			danoTxt.setVisible(true);
			danoTxtAr.setVisible(true);
			alcanceTxt.setVisible(true);
			alcanceTxtAr.setVisible(true);
			precisaoTxt.setVisible(true);
			precisaoTxtAr.setVisible(true);
			tiroSemVisadaTxt.setVisible(true);
			tiroSemVisadaTxtAr.setVisible(true);
			estabilidadeTxt.setVisible(true);
			estabilidadeTxtAr.setVisible(true);
			cadenciaTxt.setVisible(true);
			cadenciaTxtAr.setVisible(true);
			capacidadeTxt.setVisible(true);
			capacidadeTxtAr.setVisible(true);
		}

	}

	public ResultSet buscarArma(String snome) {
		// iop =1 mostra, 2 = nao
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM arma";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nome");

				if (snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarArma(Arma a) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO arma(nome, tipo, acessorio, dano, alcance, precisao, tiroSemVisada, estabilidade, cadencia, capacidadeDoPente)VALUES ('"
							+ a.getNome() + "','" + a.getTipo() + "','" + a.getAcessorio() + "','" + a.getDano() + "','"
							+ a.getAlcance() + "','" + a.getPrecisao() + "','" + a.getTiroSemVisada() + "','"
							+ a.getEstabilidade() + "','" + a.getCadencia() + "','" + a.getCapacidadeDoPente() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}

	}
	public static void main(String[] args) {
		new CadastroArmaFrame();
	}

}
