package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class StartFrame extends JFrame implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8490160171069157379L;
	
	private JButton startButton = new JButton("START");
	
	public StartFrame() {
		
		setTitle("BATTLE STATS 1.1");
		setSize(1366,768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		
		startButton.setBackground(new Color(70, 150, 255));
		startButton.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		startButton.setForeground(Color.WHITE);
		startButton.addActionListener(this);
		
		setLayout(new GridBagLayout());
		JLabel background=new JLabel(new ImageIcon("Media/StartCover.jpg"));
		add(background);
		background.setLayout(new GridBagLayout());
		background.add(startButton);
		
		refresh();
	}
	
	private void refresh(){
		setSize(1360,760);
		setSize(1366,768);
	}
	
	public void actionPerformed(ActionEvent e) {
		new LoginFrame();
		dispose();
	}
	
}
