package view;

public class EditarClasseFrame {

}
