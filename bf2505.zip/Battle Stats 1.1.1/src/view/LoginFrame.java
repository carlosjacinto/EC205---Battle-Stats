package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import control.EmailValidator;
import control.JogadorDAO;
import control.MD5;

public class LoginFrame extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1999667136136945782L;

	JTextField emailTxt = new JTextField(40);
	JPasswordField senhaTxt = new JPasswordField(40);
	JTextArea emailTxtAr = new JTextArea("E-mail", 1, 40);
	JTextArea senhaTxtAr = new JTextArea("Senha", 1, 40);
	JButton okBt = new JButton("Login");
	JButton cadastroBt = new JButton("Nova conta");

	JPanel jp = new JPanel(new GridLayout(0, 1));
	JLabel background = new JLabel(new ImageIcon("Media/Cover3.jpg"));

	public LoginFrame() {

		setTitle("Login");
		setSize(1366, 768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setLayout(new BorderLayout());

		config();
		adicionar();

		refresh();
	}

	private void refresh() {
		setSize(1360, 760);
		setSize(1366, 768);
	}

	private void adicionar() {
		add(background);
		background.setLayout(new GridBagLayout());
		jp.add(emailTxtAr);
		jp.add(emailTxt);
		jp.add(senhaTxtAr);
		jp.add(senhaTxt);
		jp.add(okBt);
		jp.add(cadastroBt);
		background.add(jp);
	}

	private void config() {
		emailTxtAr.setEditable(false);
		emailTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		emailTxtAr.setBackground(new Color(0, 0, 0));
		emailTxtAr.setForeground(Color.WHITE);
		senhaTxtAr.setEditable(false);
		senhaTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		senhaTxtAr.setBackground(new Color(0, 0, 0));
		senhaTxtAr.setForeground(Color.WHITE);
		okBt.setActionCommand("loginB");
		okBt.addActionListener(this);
		okBt.setBackground(new Color(250, 95, 0));
		okBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		okBt.setForeground(Color.WHITE);
		cadastroBt.setActionCommand("cadastroB");
		cadastroBt.addActionListener(this);
		cadastroBt.setBackground(new Color(255, 0, 0));
		cadastroBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cadastroBt.setForeground(Color.WHITE);
	}

	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e) {
		
		JogadorDAO login = new JogadorDAO();
		MD5 md5 = new MD5();
		
		if ("loginB".equals(e.getActionCommand())) {

			//verifica campos em branco
			if (emailTxt.getText().equals("") || senhaTxt.getPassword().equals("")) {
				JOptionPane.showMessageDialog(new JFrame(), "Entre com o nome de usu�rio e senha", "Campos em branco",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			//validacao do email
			EmailValidator emailValidator = new EmailValidator();
			if (!emailValidator.validate(emailTxt.getText().trim())) {
				JOptionPane.showMessageDialog(new JFrame(), "Digite um e-mail v�lido", "E-mail inv�lido!",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			
			if (login.Login( md5.encrypt(emailTxt.getText()) , md5.encrypt(senhaTxt.getText().toString()) ) ) {
				new MainMenuFrame();
				dispose();
				return;
			}

			if (login.LoginAdm( md5.encrypt(emailTxt.getText()), md5.encrypt(senhaTxt.getText().toString()) ) ) {
				new MainMenuAdmFrame();
				dispose();
				return;
			}
			
			JOptionPane.showMessageDialog(new JFrame(), "N�o encontramos nenhum usu�rio, verifique seus dados!",
					"Usu�rio n�o existe!", JOptionPane.ERROR_MESSAGE);
		}

		else {
			new CadastroJogadorFrame();
			dispose();
		}
	}

}
