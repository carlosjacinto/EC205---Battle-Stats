package control;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.Arma;

public class ArmaDAO {
	
	DataBase bd = new DataBase();
	Connection conex = bd.Conectar();

	public ResultSet buscarArma(String snome) {
		// iop =1 mostra, 2 = nao
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM arma";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nome");

				if (snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarArma(Arma a) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO arma(nome, tipo, acessorio, dano, alcance, precisao, tiroSemVisada, estabilidade, cadencia, capacidadeDoPente)VALUES ('"
							+ a.getNome() + "','" + a.getTipo() + "','" + a.getAcessorio() + "','" + a.getDano() + "','"
							+ a.getAlcance() + "','" + a.getPrecisao() + "','" + a.getTiroSemVisada() + "','"
							+ a.getEstabilidade() + "','" + a.getCadencia() + "','" + a.getCapacidadeDoPente() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}

	}
}
