package control;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.Jogador;

public class JogadorDAO {
	
	DataBase bd = new DataBase();
	Connection conex = bd.Conectar();
	
	JComboBox<?> selClasse = buscaClasse();
	JComboBox<?> selArmaFavorita = buscaArma();
	JComboBox<?> selVeiculoFavorito = buscaVeiculo();
	
	public boolean Login(String snome, String ssenha) {
		conex = bd.Conectar();
		
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador";
			ResultSet rs = stmt.executeQuery(SQL);
			
			while (rs.next()) {
				
				String nome = rs.getString("email");
				System.out.println(nome);
				System.out.println(snome);
				String senha = rs.getString("senha");
				System.out.println(ssenha);
				System.out.println(senha);
				if (senha.equals(ssenha) && snome.equals(nome)) {
					
					JOptionPane.showMessageDialog(new JFrame(),"Bem vindo " + rs.getString("nomeDeUsuario") + " ao programa Battle Stats!!!!", "Bem Vindo", JOptionPane.OK_OPTION);
					return true;
				}
			}
			rs.close();
			stmt.close();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		
		return false;
	}
	
	public boolean LoginAdm(String snome, String ssenha) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM usuariosadmin WHERE email LIKE '" + snome + "' AND senha LIKE '" + ssenha
					+ "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("email");
				String senha = rs.getString("senha");

				if (senha.equals(ssenha) && snome.equals(nome)) {
					JOptionPane.showMessageDialog(new JFrame(),"Bem vindo " + rs.getString("nome") + " ao programa Battle Stats!!!!", "Bem Vindo", JOptionPane.OK_OPTION);
					return true;
				}
			}
			rs.close();
			stmt.close();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		
		return false;
	}
	
	public JComboBox<?> buscaVeiculo(){		
		conex = bd.Conectar();
		
		try {
			JComboBox<String> selVeiculo = new JComboBox<>();
			selVeiculo.addItem("--Selecione--");
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM veiculo ORDER BY nome";
			ResultSet rs = stmt.executeQuery(SQL);
			
			
			while (rs.next()) {
				String nome = rs.getString("nome");	
				selVeiculo.addItem(nome);
				
			}
			rs.close();
			stmt.close();
			return selVeiculo;

		} catch (java.lang.Exception ex) {
			System.out.println("erro conexao");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
		
		
	}
	
	public JComboBox<?> buscaArma (){		
		conex = bd.Conectar();
		
		try {
			JComboBox<String> selArma = new JComboBox<>();
			selArma.addItem("--Selecione--");
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM arma ORDER BY nome";
			ResultSet rs = stmt.executeQuery(SQL);
			
			
			while (rs.next()) {
				String nome = rs.getString("nome");	
				selArma.addItem(nome);
				
			}
			rs.close();
			stmt.close();
			return selArma;

		} catch (java.lang.Exception ex) {
			System.out.println("erro conexao");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
		
		
	}
	
	public JComboBox<?> buscaClasse (){		
		conex = bd.Conectar();
		
		try {
			JComboBox<String> selClasse = new JComboBox<>();
			selClasse.addItem("--Selecione--");
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM classe ORDER BY nome";
			ResultSet rs = stmt.executeQuery(SQL);
			
			
			while (rs.next()) {
				String nome = rs.getString("nome");	
				selClasse.addItem(nome);
				
			}
			rs.close();
			stmt.close();
			return selClasse;

		} catch (java.lang.Exception ex) {
			System.out.println("erro conexao");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
		
		
	}
	
	
	public ResultSet buscarJogador(String snome, String semail) {
		// iop = 1 mostrar dados , 2 nao mostrar dados
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador WHERE nomeDeUsuario LIKE '" + snome + "' OR email LIKE '" + semail
					+ "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nomeDeUsuario");
				String email = rs.getString("email");

				if (semail.toLowerCase().equals(email.toLowerCase()) || snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}
			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarJogador(Jogador j) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO Jogador(nomeDeUsuario, senha, nome, email, patente, kd, score, tempoJogo, classeFavorita, armaFavorita, veiculoFavorito)VALUES ('"
							+ j.getNomeDeUsuario() + "','" + j.getSenha() + "','" + j.getNome() + "','" + j.getEmail() + "','" + j.getPatente()
							+ "','" + j.getKd() + "','" + j.getScore() + "','" + j.getTempoJogo()+ "','"+j.getClasseFavorita()+ "','"+j.getArmaFavorita()
							+"','"+j.getVeiculoFavorito() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}
	}


}
