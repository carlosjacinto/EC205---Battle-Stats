package control;

import java.security.*;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.math.*;

public class MD5 {
	
	public String encrypt(String pass){
		
		try {
			MessageDigest m=MessageDigest.getInstance("MD5");
	    	m.update(pass.getBytes(),0,pass.length());
	    	String result = new BigInteger(1,m.digest()).toString(16);
	    	return result;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(new JFrame(),"Ocorreu um erro! :(","Erro",JOptionPane.ERROR_MESSAGE);
		}
		return "";
	}
	
	public MD5() {
	}
	
}