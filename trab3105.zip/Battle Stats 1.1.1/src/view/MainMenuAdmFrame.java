package view;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainMenuAdmFrame extends JFrame {


	/**
	 * 
	 */
	private static final long serialVersionUID = -5957645396936954203L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenuAdmFrame frame = new MainMenuAdmFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	private void refresh() {
		setSize(1360, 760);
		setSize(1366, 768);
	}
	
	public MainMenuAdmFrame() {
		refresh();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0,0,1366,768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1, 1);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 575, 768);
		lblNewLabel.setIcon(new ImageIcon("D:\\workpace\\BF\\Media\\Menu.jpg"));
		contentPane.add(lblNewLabel);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBounds(775, 0, 600, 729);
		contentPane.add(panel_2);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(0, 0, 575, 768);
		lblNewLabel_1.setIcon(new ImageIcon("D:\\workpace\\BF\\Media\\Menu 2.jpg"));
		panel_2.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(575, 0, 197, 768);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnCadastrarArma = new JButton("Cadastrar Arma");
		btnCadastrarArma.setBounds(0, 0, 200, 50);
		panel_1.add(btnCadastrarArma);
		
		JButton btnVisualizarArmas = new JButton("Visualizar Armas");
		btnVisualizarArmas.setBounds(0, 50, 200, 50);
		panel_1.add(btnVisualizarArmas);
		
		JButton btnVisualizarContas = new JButton("Visualizar Contas");
		btnVisualizarContas.setBounds(0, 100, 200, 50);
		panel_1.add(btnVisualizarContas);
		
		JButton btnNewButton = new JButton("Excluir Contas");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setBounds(0, 150, 200, 50);
		panel_1.add(btnNewButton);
		
		JButton btnEditarArma = new JButton("Editar Arma");
		btnEditarArma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnEditarArma.setBounds(0, 200, 200, 50);
		panel_1.add(btnEditarArma);
		
		JButton btnExcluirArma = new JButton("Excluir Arma");
		btnExcluirArma.setBounds(0, 250, 200, 50);
		panel_1.add(btnExcluirArma);
		
		JButton btnVisualizarClasse = new JButton("Visualizar Classes");
		btnVisualizarClasse.setBounds(0, 300, 200, 50);
		panel_1.add(btnVisualizarClasse);
		
		JButton btnCadastrarClasse = new JButton("Cadastrar Classe");
		btnCadastrarClasse.setBounds(0, 350, 200, 50);
		panel_1.add(btnCadastrarClasse);
		
		JButton btnEditarClasse = new JButton("Editar Classe");
		btnEditarClasse.setBounds(0, 400, 200, 50);
		panel_1.add(btnEditarClasse);
		
		JButton btnExcluirClasse = new JButton("Excluir Classe");
		btnExcluirClasse.setBounds(0, 450, 200, 50);
		panel_1.add(btnExcluirClasse);
		
		JButton btnVisualizarVeiculos = new JButton("Visualizar Veiculos");
		btnVisualizarVeiculos.setBounds(0, 500, 200, 50);
		panel_1.add(btnVisualizarVeiculos);
		
		JButton btnCadastrarVeiculo = new JButton("Cadastrar Veiculo");
		btnCadastrarVeiculo.setBounds(0, 550, 200, 50);
		panel_1.add(btnCadastrarVeiculo);
		
		JButton btnEditarVeiculo = new JButton("Editar Veiculo");
		btnEditarVeiculo.setBounds(0, 600, 200, 50);
		panel_1.add(btnEditarVeiculo);
		
		JButton btnExcluirVeiculo = new JButton("Excluir Veiculo");
		btnExcluirVeiculo.setBounds(0, 650, 200, 50);
		panel_1.add(btnExcluirVeiculo);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(0, 700, 200, 50);
		panel_1.add(btnVoltar);
	}
}
