package view;

public class ListarVeiculoFrame {

}
