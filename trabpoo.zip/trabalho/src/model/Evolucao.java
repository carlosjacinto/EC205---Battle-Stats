package model;

import java.util.ArrayList;
import java.util.Scanner;

public class Evolucao {
	private String nome;
	private String level;
	private ArrayList<Habilidade> habilidadePoder = new ArrayList<Habilidade>();
	
	public ArrayList<Habilidade> getHabilidadePoder() {
		return habilidadePoder;
	}

	Scanner ler = new Scanner(System.in);

	public void ListarHabilidade() {
		System.out.println("Habilidades da Evolu��o: ");
		for (Habilidade h : habilidadePoder) {
			System.out.println("\tNome: " + h.getNome());
		}
	}

	public void addHabilidade(Habilidade hab) {
		habilidadePoder.add(hab);
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
}