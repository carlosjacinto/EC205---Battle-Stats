package model;

import java.util.ArrayList;

public class Vilao extends Treinador {

	ArrayList<Digimon> digiControlados = new ArrayList<>();
	
	public ArrayList<Digimon> getDigiControlados() {
		return digiControlados;
	}

	public void addDigiControlado(Digimon digimon){
		digiControlados.add(digimon);
	}
	
	public void listarDigiControlados(){
		for(Digimon d: digiControlados){
			System.out.println("Elemento: "+d.getElemento());
			d.ListarEvolucao();
			System.out.println();
		}
	}
	
	public String toCSV(){
		StringBuilder sb = new StringBuilder();
		sb.append("2,").append(super.toCSV());
		for(Digimon d: getDigiControlados()){
			sb.append("{").append(d.getElemento());
			for(Evolucao e : d.CopiaArray()){
				sb.append("[").append(e.getNome()).append(",").append(e.getLevel());
				for(Habilidade h :e.getHabilidadePoder()){
					sb.append("(").append(h.getNome());
				}
			}
		}
		return sb.toString();
	}
	
}
