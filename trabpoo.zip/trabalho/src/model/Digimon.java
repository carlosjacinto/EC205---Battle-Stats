package model;

import java.util.ArrayList;

public class Digimon implements Comparable<Digimon> {

	private String elemento; // [] = {"Fogo", "�gua", "Gelo", "Vento", "Trov�o",
								// "Madeira", "Metal", "Terra", "Luz" ,
								// "Trevas"};
	

	private ArrayList<Evolucao> evolucoes = new ArrayList<Evolucao>();
//TODO: ADICIONADO PARA ARQUIVO
	public Digimon(){
		
	}
	
	public Digimon(String csv){
		String[] partes = csv.split(",");
		try{
			if(partes.length==1){
				elemento = partes[0];
			}
		}catch(NumberFormatException e){
			
		}
		
	}
	
	public ArrayList<Evolucao> CopiaArray() {
		return evolucoes;
	}

	public void ListarEvolucao() {
		if (evolucoes.size() > 0)
			for (Evolucao e : evolucoes) {
				System.out.println("Nome: " + e.getNome());
				System.out.println("Level: " + e.getLevel());
				e.ListarHabilidade();
				System.out.println();
			}
		else
			System.out.println("Digimon nao possui evolu��o");

	}

	public void addEvolucao(Evolucao evolucao) {
		evolucoes.add(evolucao);
	}

	public void removeEvolucao(String nome) {
		int i = 0;
		boolean encontrado = false;
		for (Evolucao e : evolucoes) {
			if (e.getNome().equals(nome)) {
				evolucoes.remove(i);
				System.out.println("Evolu��o removida com sucesso");
				encontrado = true;
				break;
			}
			i++;
		}
		if (!encontrado)
			System.out.println("Evolu��o n�o Removida!");
	}

	public void setElemento(String elemento) {
		this.elemento = elemento;
	}

	public String getElemento() {
		return elemento;
	}
	
	
	
	public int compareTo(Digimon outro) {
		return this.elemento.compareTo(outro.getElemento());
	}

	
	public String toCSV(){
		StringBuilder sb = new StringBuilder();
		sb.append(getElemento()).append(",");
		//TODO: FALTA ADICIONAR O RESTO DOS ITENS
		
		return sb.toString();
	}
}
