package model;

public class Treinador {

	String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	} 
	
	public String toCSV(){
		StringBuilder sb = new StringBuilder();
		sb.append(getNome());
		return sb.toString();
	}
}
