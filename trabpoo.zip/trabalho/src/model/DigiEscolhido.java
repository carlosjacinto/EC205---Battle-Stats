package model;

public class DigiEscolhido extends Treinador{
	
	String brasao;
	Digimon digimon;
	
	public String getBrasao() {
		return brasao;
	}

	public void setBrasao(String brasao) {
		this.brasao = brasao;
	}

	public Digimon getDigimon() {
		return digimon;
	}

	public void setDigimon(Digimon digimon) {
		this.digimon = digimon;
	}
	
	public String toCSV(){
		StringBuilder sb = new StringBuilder();
		sb.append("1,").append(super.toCSV()).append(",").append(getBrasao()).append(",");
		sb.append(getDigimon().getElemento());
		for(Evolucao e : digimon.CopiaArray()){
			sb.append("[").append(e.getNome()).append(",").append(e.getLevel());
			for(Habilidade h :e.getHabilidadePoder()){
				sb.append("(").append(h.getNome());
			}
		}
		
		return sb.toString();
	}

}
