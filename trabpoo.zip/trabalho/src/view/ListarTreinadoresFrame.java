package view;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

import model.DigiEscolhido;
import model.Digimon;
import model.Evolucao;
import model.Habilidade;
import model.Treinador;
import model.Vilao;

public class ListarTreinadoresFrame extends JFrame {

	private static final long serialVersionUID = 1201221513208381296L;

	private JLabel tipoLabel;
	private JTextArea tipoTextArea;
	private JLabel nomeLabel;
	private JTextArea nomeTextArea;
	private JLabel brasaoLabel;
	private JTextArea brasaoTextArea;
	private JButton proximoButton;
	private JButton anteriorButton;
	private JButton cancelarButton;
	private JButton listarDigimonButton;
	private JTable digimonTable;
	private JPanel painelFundo;
	private int cont = 0;
	private JLabel elementoLabel;
	private JButton proximoDigiButton;
	private JButton anteriorDigiButton;
	private JButton addDigiButton;
	private JButton removeDigiButton;
	private JButton removerTreinadorButton;
	
	private ArrayList<Treinador> treinadores = new ArrayList<>();
	private int pos;

	private GridBagConstraints tipoLabelConstraints;
	private GridBagConstraints tipoTextAreaConstraints;
	private GridBagConstraints nomeLabelConstraints;
	private GridBagConstraints nomeTextAreaConstraints;
	private GridBagConstraints brasaoLabelConstraints;
	private GridBagConstraints brasaoTextAreaConstraints;
	private GridBagConstraints proximoButtonConstraints;
	private GridBagConstraints anteriorButtonConstraints;
	private GridBagConstraints cancelarButtonConstraints;
	private GridBagConstraints listarDigimonButtonConstraints;
	private GridBagConstraints digimonTableConstraints;
	private GridBagConstraints elementoLabelConstraints;
	private GridBagConstraints proximoDigiButtonConstraints;
	private GridBagConstraints anteriorDigiButtonConstraints;
	private GridBagConstraints addDigiButtonConstraints;
	private GridBagConstraints removeDigiButtonConstraints;
	private GridBagConstraints removerTreinadorButtonConstraints;

	public ListarTreinadoresFrame(ArrayList<Treinador> cadTreinador, int posi) {
		super("Listagem de Treinadores");
		pos = posi;
		treinadores = cadTreinador;
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Treinador t = treinadores.get(pos);
		if (t instanceof DigiEscolhido) {
			tipoTextArea.setText("DigiEscolhido");
			DigiEscolhido tr = (DigiEscolhido) t;
			brasaoTextArea.setText(tr.getBrasao());
			nomeTextArea.setText(tr.getNome());
		} else {
			tipoTextArea.setText("Vil�o");
			Vilao tr = (Vilao) t;
			nomeTextArea.setText(tr.getNome());
		}

	}

	private void initialize() {
		setLayout(new GridBagLayout());
		add(getTipoLabel(), getTipoLabelConstraints());
		add(getTipoTextArea(), getTipoTextAreaConstraints());
		add(getNomeLabel(), getNomeLabelConstraints());
		add(getNomeTextArea(), getNomeTextAreaConstraints());
		if (treinadores.get(pos) instanceof DigiEscolhido) {
			add(getBrasaoLabel(), getBrasaoLabelConstraints());
			add(getBrasaoTextArea(), getBrasaoTextAreaConstraints());
		}
		if (pos > 0)
			add(getAnteriorButton(), getAnteriorButtonConstraints());
		if (pos < treinadores.size() - 1)
			add(getProximoButton(), getProximoButtonConstraints());
		add(getCancelarButton(), getCancelarButtonConstraints());
		add(getRemoverTreinadorButton(),getRemoverTreinadorButtonConstraints());
		add(getListarDigimonButton(), getListarDigimonButtonConstraints());
	}

	public JLabel getTipoLabel() {
		if (tipoLabel == null) {
			tipoLabel = new JLabel();
			tipoLabel.setText("Tipo do Treinador");
			tipoLabel.setPreferredSize(new Dimension(100, 50));
		}
		return tipoLabel;
	}

	public GridBagConstraints getTipoLabelConstraints() {
		if (tipoLabelConstraints == null) {
			tipoLabelConstraints = new GridBagConstraints();
			tipoLabelConstraints.gridx = 0;
			tipoLabelConstraints.gridy = 0;
		}
		return tipoLabelConstraints;
	}

	public JTextArea getTipoTextArea() {
		if (tipoTextArea == null) {
			tipoTextArea = new JTextArea();
			Dimension prefSize = tipoTextArea.getPreferredSize();
			prefSize.height = 30;
			prefSize.width = 150;
			tipoTextArea.setPreferredSize(prefSize);
		}
		return tipoTextArea;
	}

	public GridBagConstraints getTipoTextAreaConstraints() {
		if (tipoTextAreaConstraints == null) {
			tipoTextAreaConstraints = new GridBagConstraints();
			tipoTextAreaConstraints.gridx = 1;
			tipoTextAreaConstraints.gridy = 0;
			tipoTextAreaConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return tipoTextAreaConstraints;
	}

	public JLabel getNomeLabel() {
		if (nomeLabel == null) {
			nomeLabel = new JLabel();
			nomeLabel.setText("Nome:");
		}
		return nomeLabel;
	}

	public GridBagConstraints getNomeLabelConstraints() {
		if (nomeLabelConstraints == null) {
			nomeLabelConstraints = new GridBagConstraints();
			nomeLabelConstraints.gridx = 0;
			nomeLabelConstraints.gridy = 1;
		}
		return nomeLabelConstraints;
	}

	public JTextArea getNomeTextArea() {
		if (nomeTextArea == null) {
			nomeTextArea = new JTextArea();
			Dimension prefSize = nomeTextArea.getPreferredSize();
			prefSize.height = 30;
			prefSize.width = 150;
			nomeTextArea.setPreferredSize(prefSize);
		}
		return nomeTextArea;
	}

	public GridBagConstraints getNomeTextAreaConstraints() {
		if (nomeTextAreaConstraints == null) {
			nomeTextAreaConstraints = new GridBagConstraints();
			nomeTextAreaConstraints.gridx = 1;
			nomeTextAreaConstraints.gridy = 1;
			nomeTextAreaConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return nomeTextAreaConstraints;
	}

	public JLabel getBrasaoLabel() {
		if (brasaoLabel == null) {
			brasaoLabel = new JLabel();
			brasaoLabel.setText("Bras�o: ");
		}
		return brasaoLabel;
	}

	public GridBagConstraints getBrasaoLabelConstraints() {
		if (brasaoLabelConstraints == null) {
			brasaoLabelConstraints = new GridBagConstraints();
			brasaoLabelConstraints.gridx = 0;
			brasaoLabelConstraints.gridy = 2;
			brasaoLabelConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return brasaoLabelConstraints;
	}

	public JTextArea getBrasaoTextArea() {
		if (brasaoTextArea == null) {
			brasaoTextArea = new JTextArea();
			Dimension prefSize = brasaoTextArea.getPreferredSize();
			prefSize.height = 30;
			prefSize.width = 150;
			brasaoTextArea.setPreferredSize(prefSize);
		}
		return brasaoTextArea;
	}

	public GridBagConstraints getBrasaoTextAreaConstraints() {
		if (brasaoTextAreaConstraints == null) {
			brasaoTextAreaConstraints = new GridBagConstraints();
			brasaoTextAreaConstraints.gridx = 1;
			brasaoTextAreaConstraints.gridy = 2;
			brasaoTextAreaConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return brasaoTextAreaConstraints;
	}

	public JButton getAnteriorButton() {
		if (anteriorButton == null) {
			anteriorButton = new JButton("Anterior");
			anteriorButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					new ListarTreinadoresFrame(treinadores, pos - 1).setVisible(true);
				}
			});
		}
		return anteriorButton;
	}

	public GridBagConstraints getAnteriorButtonConstraints() {
		if (anteriorButtonConstraints == null) {
			anteriorButtonConstraints = new GridBagConstraints();
			anteriorButtonConstraints.gridx = 0;
			anteriorButtonConstraints.gridy = 4;
			anteriorButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return anteriorButtonConstraints;
	}

	public JButton getProximoButton() {
		if (proximoButton == null) {
			proximoButton = new JButton("Pr�ximo");
			proximoButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					new ListarTreinadoresFrame(treinadores, pos + 1).setVisible(true);
				}
			});
		}
		return proximoButton;
	}

	public GridBagConstraints getProximoButtonConstraints() {
		if (proximoButtonConstraints == null) {
			proximoButtonConstraints = new GridBagConstraints();
			proximoButtonConstraints.gridx = 1;
			proximoButtonConstraints.gridy = 4;
			proximoButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return proximoButtonConstraints;
	}

	public JButton getCancelarButton() {
		if (cancelarButton == null) {
			cancelarButton = new JButton("Cancelar");
			cancelarButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					new Menu().setVisible(true);
				}
			});
		}
		return cancelarButton;
	}

	public GridBagConstraints getCancelarButtonConstraints() {
		if (cancelarButtonConstraints == null) {
			cancelarButtonConstraints = new GridBagConstraints();
			cancelarButtonConstraints.gridx = 2;
			cancelarButtonConstraints.gridy = 4;
			cancelarButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return cancelarButtonConstraints;
	}
	
	private JButton getRemoverTreinadorButton() {
		if(removerTreinadorButton == null){
			removerTreinadorButton = new JButton();
			removerTreinadorButton.setText("Remover Treinador");
			removerTreinadorButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					dispose();
					treinadores.remove(pos);
					new Menu().setVisible(true);
					JOptionPane.showMessageDialog(null, "Treinador removido com sucesso");
					
				}
			});
		}
		return removerTreinadorButton;
	}

	private GridBagConstraints getRemoverTreinadorButtonConstraints() {
		if (removerTreinadorButtonConstraints == null) {
			removerTreinadorButtonConstraints = new GridBagConstraints();
			removerTreinadorButtonConstraints.gridx = 1;
			removerTreinadorButtonConstraints.gridy = 5;
			removerTreinadorButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return removerTreinadorButtonConstraints;
	}

	private JButton getAddDigiButton(Vilao vilao) {
		if(addDigiButton == null){
			addDigiButton = new JButton();
			addDigiButton.setText("Adicionar DigiControlado");
			addDigiButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					new AddDigiControladosFrame(vilao).setVisible(true);
					//listarDigimon();
				}
			});
		}
		return addDigiButton;
	}

	private GridBagConstraints getAddDigiButtonConstraints() {
		if(addDigiButtonConstraints == null){
			addDigiButtonConstraints = new GridBagConstraints();
			addDigiButtonConstraints.gridx = 0;
			addDigiButtonConstraints.gridy = 9;
			addDigiButtonConstraints.insets = new Insets(5,5,5,5);
		}
		return addDigiButtonConstraints;
	}

	private JButton getRemoveDigiButton(Vilao vilao) {
		if(removeDigiButton == null){
			removeDigiButton = new JButton();
			removeDigiButton.setText("Remover DigiControlado");
			removeDigiButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					vilao.getDigiControlados().remove(cont);
					dispose();
					new Menu().setVisible(true);
					JOptionPane.showMessageDialog(null, "Digimon removido com sucesso");
				}
			});
		}
		return removeDigiButton;
	}

	private GridBagConstraints getRemoveDigiButtonConstraints() {
		if(removeDigiButtonConstraints == null){
			removeDigiButtonConstraints = new GridBagConstraints();
			removeDigiButtonConstraints.gridx = 1;
			removeDigiButtonConstraints.gridy = 9;
			removeDigiButtonConstraints.insets = new Insets(5,5,5,5);
		}
		return removeDigiButtonConstraints;
	}

	public JButton getListarDigimonButton() {
		if (listarDigimonButton == null) {
			if (treinadores.get(pos) instanceof DigiEscolhido) {
				listarDigimonButton = new JButton("Listar Digimon");
			} else
				listarDigimonButton = new JButton("Listar DigiControlados");
			listarDigimonButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					listarDigimon();
				}
			});
		}
		return listarDigimonButton;
	}

	public GridBagConstraints getListarDigimonButtonConstraints() {
		if (listarDigimonButtonConstraints == null) {
			listarDigimonButtonConstraints = new GridBagConstraints();
			listarDigimonButtonConstraints.gridx = 1;
			listarDigimonButtonConstraints.gridy = 3;
			listarDigimonButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return listarDigimonButtonConstraints;
	}

	public JLabel getElementoLabel(Digimon digimon) {
		if (elementoLabel == null) {
			elementoLabel = new JLabel();
			elementoLabel.setText("Elemento: "+digimon.getElemento() );
		}
		return elementoLabel;
	}

	public GridBagConstraints getElementoLabelConstraints() {
		if (elementoLabelConstraints == null) {
			elementoLabelConstraints = new GridBagConstraints();
			elementoLabelConstraints.gridx = 0;
			elementoLabelConstraints.gridy = 6;
			elementoLabelConstraints.gridwidth = 3;
			elementoLabelConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return elementoLabelConstraints;
	}

	public JPanel getDigimonTable(Digimon digimon) {
		if (painelFundo == null) {
			String[] colunas = { "Evolu��es", "Level","Habilidades" };
			ArrayList<Evolucao> evolucoes = digimon.CopiaArray();
			String[][] dados = new String[evolucoes.size()][3];
			int i=0;
			for(Evolucao e: evolucoes){
				dados[i][0] = e.getNome();
				dados[i][1] = e.getLevel();
				int j =0;
				for(Habilidade h:e.getHabilidadePoder()){
					if(j==0){
						dados[i][2] = h.getNome();
					}else{
						dados[i][2] = dados[i][2] + h.getNome();
					}
					if(j<e.getHabilidadePoder().size()-1){
						dados[i][2] = dados[i][2]+", ";
					}
					
					j++;
				}
				i++;
			}
			
			
			digimonTable = new JTable(dados,colunas);
			Dimension prefSize = digimonTable.getPreferredSize();
			prefSize.width = 300;
			digimonTable.setPreferredSize(prefSize);
			JScrollPane barraRolagem = new JScrollPane(digimonTable);
			prefSize = barraRolagem.getPreferredSize();
			prefSize.width = 300;
			prefSize.height = 100;
			barraRolagem.setPreferredSize(prefSize);;
			painelFundo =  new JPanel();
			painelFundo.setLayout(new GridLayout(1,1));
			painelFundo.add(barraRolagem);
			prefSize = painelFundo.getPreferredSize();
			prefSize.width = 400;
			prefSize.height = 100;
			painelFundo.setPreferredSize(prefSize);
			
		}
		return painelFundo;
	}
//TODO: DEFAULT TABLE MODEL 
	public GridBagConstraints getDigimonTableConstraints() {
		if (digimonTableConstraints == null) {
			digimonTableConstraints = new GridBagConstraints();
			digimonTableConstraints.gridx = 0;
			digimonTableConstraints.gridy = 7;
			digimonTableConstraints.gridwidth = 3;
			digimonTableConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return digimonTableConstraints;
	}

	public JButton getAnteriorDigiButton() {
		if (anteriorDigiButton== null) {
			anteriorDigiButton = new JButton("Digimon Anterior");
			anteriorDigiButton.addActionListener(new ActionListener() {

				
				public void actionPerformed(ActionEvent e) {
						cont--;
						Vilao v = (Vilao) treinadores.get(pos);
						ArrayList<Digimon> digiControlados = v.getDigiControlados();
						remove(elementoLabel);
						elementoLabel = null;
						remove(painelFundo);
						painelFundo = null;
						if(cont>=digiControlados.size()-1)
							proximoDigiButton.setEnabled(false);
						else proximoDigiButton.setEnabled(true);
						if(cont>0)
							anteriorDigiButton.setEnabled(true);
						else anteriorDigiButton.setEnabled(false);
						pack();
						add(getElementoLabel(digiControlados.get(cont)),getElementoLabelConstraints());
						add(getDigimonTable(digiControlados.get(cont)),getDigimonTableConstraints());
						pack();
						
				}
			});
		}
		return anteriorDigiButton;
	}

	public GridBagConstraints getAnteriorDigiButtonConstraints() {
		if (anteriorDigiButtonConstraints == null) {
			anteriorDigiButtonConstraints = new GridBagConstraints();
			anteriorDigiButtonConstraints.gridx = 0;
			anteriorDigiButtonConstraints.gridy = 8;
			anteriorDigiButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return anteriorDigiButtonConstraints;
	}

	public JButton getProximoDigiButton() {
		if (proximoDigiButton== null) {
			proximoDigiButton = new JButton("Pr�ximo Digimon");
			proximoDigiButton.addActionListener(new ActionListener() {

				
				public void actionPerformed(ActionEvent e) {
						cont++;
						Vilao v = (Vilao) treinadores.get(pos);
						ArrayList<Digimon> digiControlados = v.getDigiControlados();
						remove(elementoLabel);
						elementoLabel = null;
						remove(painelFundo);
						painelFundo = null;
						if(cont>=digiControlados.size()-1){
							proximoDigiButton.setEnabled(false);
						}else proximoDigiButton.setEnabled(true);
						if(cont>0){
							anteriorDigiButton.setEnabled(true);
						}else anteriorDigiButton.setEnabled(false);
						pack();
						add(getElementoLabel(digiControlados.get(cont)),getElementoLabelConstraints());
						add(getDigimonTable(digiControlados.get(cont)),getDigimonTableConstraints());
						pack();
					
				}
			});
		}
		return proximoDigiButton;
	}

	public GridBagConstraints getProximoDigiButtonConstraints() {
		if (proximoDigiButtonConstraints == null) {
			proximoDigiButtonConstraints = new GridBagConstraints();
			proximoDigiButtonConstraints.gridx = 1;
			proximoDigiButtonConstraints.gridy = 8;
			proximoDigiButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return proximoDigiButtonConstraints;
	}
	
	private void listarDigimon(){
		if (treinadores.get(pos) instanceof Vilao) {
			Vilao v = (Vilao) treinadores.get(pos);
			ArrayList<Digimon> digiControlados = v.getDigiControlados();
			add(getAnteriorDigiButton(),getAnteriorDigiButtonConstraints());
			anteriorDigiButton.setEnabled(false);
			add(getProximoDigiButton(), getProximoDigiButtonConstraints());
			if(digiControlados.size()>1){
				proximoDigiButton.setEnabled(true);
			}else proximoDigiButton.setEnabled(false);
			add(getElementoLabel(digiControlados.get(cont)),getElementoLabelConstraints());
			add(getDigimonTable(digiControlados.get(cont)),getDigimonTableConstraints());
			add(getAddDigiButton(v),getAddDigiButtonConstraints());
			if(digiControlados.size()>1){
				add(getRemoveDigiButton(v),getRemoveDigiButtonConstraints());
			}
			pack();

		}else{
			DigiEscolhido d = (DigiEscolhido) treinadores.get(pos);
			Digimon digimon = d.getDigimon();
			add(getElementoLabel(digimon),getElementoLabelConstraints());
			add(getDigimonTable(digimon),getDigimonTableConstraints());
			pack();
		}
	}
	
}
