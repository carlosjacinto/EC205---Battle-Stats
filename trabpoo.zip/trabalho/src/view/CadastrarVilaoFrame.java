package view;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.Treinador;
import model.Vilao;

public class CadastrarVilaoFrame extends JFrame {

	private static final long serialVersionUID = 3798326779987456077L;
	
	private JLabel nomeLabel;
	private JTextField nomeTextField;
	private JButton continuarButton;
	private JButton cancelarButton;
	private ArrayList<Treinador> treinadores;
	
	private GridBagConstraints nomeLabelConstraints;
	private GridBagConstraints nomeTextFieldConstraints;
	private GridBagConstraints continuarButtonConstraints;
	private GridBagConstraints cancelarButtonConstraints;
	
	public CadastrarVilaoFrame(ArrayList<Treinador> treinador){
		super("Cadastrar Vil�o");
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		treinadores = treinador;
	}

	private void initialize() {
		setLayout(new GridBagLayout());
		add(getNomeLabel(),getNomeLabelConstraints());
		add(getNomeTextField(),getNomeTextFieldConstraints());
		add(getContinuarButton(), getContinuarButtonConstraints());
		add(getCancelarButton(), getCancelarButtonConstraints());
	}
	
	public JLabel getNomeLabel() {
		if(nomeLabel==null)
		{
			nomeLabel = new JLabel();
			nomeLabel.setText("Nome: ");
		}
		return nomeLabel;
	}

	public GridBagConstraints getNomeLabelConstraints() {
		if(nomeLabelConstraints==null)
		{
			nomeLabelConstraints = new GridBagConstraints();
			nomeLabelConstraints.gridx = 0;
			nomeLabelConstraints.gridy = 0;
		}
		return nomeLabelConstraints;
	}
	
	public JTextField getNomeTextField() {
		if(nomeTextField==null)
		{
			nomeTextField = new JTextField();
			Dimension prefSize = nomeTextField.getPreferredSize();
			prefSize.height = 30;
			prefSize.width = 150;
			nomeTextField.setPreferredSize(prefSize);
		}
		return nomeTextField;
	}
	
	public GridBagConstraints getNomeTextFieldConstraints() {
		if(nomeTextFieldConstraints==null)
		{
			nomeTextFieldConstraints = new GridBagConstraints();
			nomeTextFieldConstraints.gridx = 1;
			nomeTextFieldConstraints.gridy = 0;
		}
		return nomeTextFieldConstraints;
	}
	
	public JButton getContinuarButton() {
		if(continuarButton==null){
			continuarButton = new JButton("Continuar");
			continuarButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					if(!nomeTextField.getText().equals("")){
						Vilao vilao = new Vilao();
						vilao.setNome(nomeTextField.getText());
						new CadastrarDigiControladosFrame(treinadores, vilao).setVisible(true);
						dispose();
					}else{
						JOptionPane.showMessageDialog(null, "Existem Campos em branco");
					}
				}
			});
		}
		return continuarButton;
	}
	public GridBagConstraints getContinuarButtonConstraints() {
		if(continuarButtonConstraints==null)
		{
			continuarButtonConstraints = new GridBagConstraints();
			continuarButtonConstraints.gridx = 0;
			continuarButtonConstraints.gridy = 1;
		}
		return continuarButtonConstraints;
	}
	
	public JButton getCancelarButton() {
		if(cancelarButton==null){
			cancelarButton = new JButton("Cancelar");
			cancelarButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					new Menu().setVisible(true);
				}
			});
		}
		return cancelarButton;
	}

	public GridBagConstraints getCancelarButtonConstraints() {
		if(cancelarButtonConstraints==null)
		{
			cancelarButtonConstraints = new GridBagConstraints();
			cancelarButtonConstraints.gridx = 1;
			cancelarButtonConstraints.gridy = 1;
		}
		return cancelarButtonConstraints;
	}
	
}
