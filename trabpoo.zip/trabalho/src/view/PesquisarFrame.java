package view;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.Treinador;

public class PesquisarFrame extends JFrame {

	private static final long serialVersionUID = 2249934158096129562L;

	private ArrayList<Treinador> treinadores = new ArrayList<>();
	private ArrayList<Treinador> treinador = new ArrayList<>();
	
	private JLabel nomePesquisaLabel;
	private JTextField nomePesquisaTextField;
	private JButton pesquisaButton;
	private JButton cancelaButton;

	private GridBagConstraints nomePesquisaLabelConstraints;
	private GridBagConstraints nomePesquisaTextFieldConstraints;
	private GridBagConstraints pesquisaButtonConstraints;
	private GridBagConstraints cancelaButtonConstraints;

	public PesquisarFrame(ArrayList<Treinador> pesqTreinadores) {
		super("Pesquisar");
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		treinadores = pesqTreinadores;
	}

	private void initialize() {
		setLayout(new GridBagLayout());
		add(getNomePesquisaLabel(), getNomePesquisaLabelConstraints());
		add(getNomePesquisaTextField(), getNomePesquisaTextFieldConstraints());
		add(getPesquisaButton(), getPesquisaButtonConstraints());
		add(getCancelaButton(),getCancelaButtonConstraints());
	}

	private JLabel getNomePesquisaLabel() {
		if (nomePesquisaLabel == null) {
			nomePesquisaLabel = new JLabel();
			nomePesquisaLabel.setText("Nome do Treinador:");
		}
		return nomePesquisaLabel;
	}

	private GridBagConstraints getNomePesquisaLabelConstraints() {
		if (nomePesquisaLabelConstraints == null) {
			nomePesquisaLabelConstraints = new GridBagConstraints();
			nomePesquisaLabelConstraints.gridx = 0;
			nomePesquisaLabelConstraints.gridy = 0;
			nomePesquisaLabelConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return nomePesquisaLabelConstraints;
	}

	private JTextField getNomePesquisaTextField() {
		if (nomePesquisaTextField == null) {
			nomePesquisaTextField = new JTextField();
			Dimension prefSize = nomePesquisaTextField.getPreferredSize();
			prefSize.height = 30;
			prefSize.width = 200;
			nomePesquisaTextField.setPreferredSize(prefSize);
		}
		return nomePesquisaTextField;
	}

	private GridBagConstraints getNomePesquisaTextFieldConstraints() {
		if (nomePesquisaTextFieldConstraints == null) {
			nomePesquisaTextFieldConstraints = new GridBagConstraints();
			nomePesquisaTextFieldConstraints.gridx = 1;
			nomePesquisaTextFieldConstraints.gridy = 0;
			nomePesquisaTextFieldConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return nomePesquisaTextFieldConstraints;
	}

	private JButton getPesquisaButton() {
		if(pesquisaButton == null){
			pesquisaButton = new JButton();
			pesquisaButton.setText("Pesquisar");
			pesquisaButton.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent e) {
					getTreinador();
					if(treinador.isEmpty()){
						JOptionPane.showMessageDialog(null, "Treinador n�o encontrado");
						new Menu().setVisible(true);
					}else{
						new ListarTreinadoresFrame(treinador , 0).setVisible(true);
					}
					dispose();
				}

			});
		}
		return pesquisaButton;
	}
	
	private GridBagConstraints getPesquisaButtonConstraints() {
		if(pesquisaButtonConstraints == null){
			pesquisaButtonConstraints = new GridBagConstraints();
			pesquisaButtonConstraints.gridx = 0;
			pesquisaButtonConstraints.gridy = 1;
		}
		return pesquisaButtonConstraints;
	}

	private JButton getCancelaButton() {
		if(cancelaButton == null){
			cancelaButton = new JButton();
			cancelaButton.setText("Cancelar");
			cancelaButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					new Menu().setVisible(true);
				}
			});
		}
		return cancelaButton;
	}

	private GridBagConstraints getCancelaButtonConstraints() {
		if(cancelaButtonConstraints == null){
			cancelaButtonConstraints = new GridBagConstraints();
			cancelaButtonConstraints.gridx = 1;
			cancelaButtonConstraints.gridy = 1;
		}
		return cancelaButtonConstraints;
	}
	
	private ArrayList<Treinador> getTreinador() {
		for(Treinador t: treinadores){
			if(t.getNome().equals(nomePesquisaTextField.getText())){
				treinador.add(t);
			}
		}
		
		return treinador;
	}
	
}
