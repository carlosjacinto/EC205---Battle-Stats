package view;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.Evolucao;
import model.Habilidade;

public class CadastrarHabilidadesFrame extends JFrame {

	private static final long serialVersionUID = 5381044188107406389L;

	private JLabel nomeHabilidadeLabel;
	private JTextField nomeHabilidadeTextField;
	private JButton addHabilidadeButton;
	private JButton addOutraHabilidadeButton;
	private Evolucao evolucao = new Evolucao();

	private GridBagConstraints nomeHabilidadeLabelConstraints;
	private GridBagConstraints nomeHabilidadeTextFieldConstraints;
	private GridBagConstraints addHabilidadeButtonConstraints;
	private GridBagConstraints addOutraHabilidadeButtonConstraints;

	public CadastrarHabilidadesFrame( Evolucao cadEvolucao) {
		super("Cadastrar Habilidade");
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		evolucao = cadEvolucao;
	}

	private void initialize() {
		setLayout(new GridBagLayout());
		add(getNomeHabilidadeLabel(), getNomeEvolucaoLabelConstraints());
		add(getNomeHabilidadeTextField(), getNomeHabilidadeTextFieldConstraints());
		add(getAddHabilidadeButton(), getAddHabilidadeButtonConstraints());
		add(getAddOutraHabilidadeButton(), getAddOutraHabilidadeButtonConstraints());
	}

	public JLabel getNomeHabilidadeLabel() {
		if (nomeHabilidadeLabel == null) {
			nomeHabilidadeLabel = new JLabel();
			nomeHabilidadeLabel.setText("Nome Habilidade: ");
		}
		return nomeHabilidadeLabel;
	}

	public GridBagConstraints getNomeEvolucaoLabelConstraints() {
		if (nomeHabilidadeLabelConstraints == null) {
			nomeHabilidadeLabelConstraints = new GridBagConstraints();
			nomeHabilidadeLabelConstraints.gridx = 0;
			nomeHabilidadeLabelConstraints.gridy = 0;
		}
		return nomeHabilidadeLabelConstraints;
	}

	public JTextField getNomeHabilidadeTextField() {
		if (nomeHabilidadeTextField == null) {
			nomeHabilidadeTextField = new JTextField();
			Dimension prefSize = nomeHabilidadeTextField.getPreferredSize();
			prefSize.height = 30;
			prefSize.width = 200;
			nomeHabilidadeTextField.setPreferredSize(prefSize);
		}
		return nomeHabilidadeTextField;
	}

	public GridBagConstraints getNomeHabilidadeTextFieldConstraints() {
		if (nomeHabilidadeTextFieldConstraints == null) {
			nomeHabilidadeTextFieldConstraints = new GridBagConstraints();
			nomeHabilidadeTextFieldConstraints.gridx = 1;
			nomeHabilidadeTextFieldConstraints.gridy = 0;
		}
		return nomeHabilidadeTextFieldConstraints;
	}

	public JButton getAddHabilidadeButton() {
		if (addHabilidadeButton == null) {
			addHabilidadeButton = new JButton("Salvar e voltar");
			addHabilidadeButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					if (!nomeHabilidadeTextField.getText().equals("")) {
						Habilidade hab = new Habilidade();
						hab.setNome(nomeHabilidadeTextField.getText());
						evolucao.addHabilidade(hab);
						JOptionPane.showMessageDialog(null, "Evolu��o: "+evolucao.getNome()+" Adicionada com sucesso");
						dispose();
					} else
						JOptionPane.showMessageDialog(null, "O campo nome est� em branco");
				}
			});
		}
		return addHabilidadeButton;
	}

	public GridBagConstraints getAddHabilidadeButtonConstraints() {
		if (addHabilidadeButtonConstraints == null) {
			addHabilidadeButtonConstraints = new GridBagConstraints();
			addHabilidadeButtonConstraints.gridx = 0;
			addHabilidadeButtonConstraints.gridy = 1;
		}
		return addHabilidadeButtonConstraints;
	}

	public JButton getAddOutraHabilidadeButton() {
		if (addOutraHabilidadeButton == null) {
			addOutraHabilidadeButton = new JButton("Salvar e adicionar outra");
			addOutraHabilidadeButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					if (!nomeHabilidadeTextField.getText().equals("")) {
						Habilidade hab = new Habilidade();
						hab.setNome(nomeHabilidadeTextField.getText());
						evolucao.addHabilidade(hab);
						nomeHabilidadeTextField.setText("");

						// new Menu().setVisible(true);
					} else
						JOptionPane.showMessageDialog(null, "O campo nome est� em branco");
					// dispose();
					// new Menu().setVisible(true);
				}
			});
		}
		return addOutraHabilidadeButton;
	}

	public GridBagConstraints getAddOutraHabilidadeButtonConstraints() {
		if (addOutraHabilidadeButtonConstraints == null) {
			addOutraHabilidadeButtonConstraints = new GridBagConstraints();
			addOutraHabilidadeButtonConstraints.gridx = 1;
			addOutraHabilidadeButtonConstraints.gridy = 1;
		}
		return addOutraHabilidadeButtonConstraints;
	}

	

}
