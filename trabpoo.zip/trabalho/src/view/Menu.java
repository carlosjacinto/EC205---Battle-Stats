package view;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import model.Treinador;

public class Menu extends JFrame {

	private static final long serialVersionUID = 2401343171737574518L;

	private Clip clip;
	private JButton cadastroVilaoButton;
	private JButton cadastroDigiEscolhidoButton;
	private JButton listarButton;
	private JButton listarDigimonsButton;
	private JButton pesquisarButton;
	private JButton sairButton;
	private JButton pararMusicaButton;
	private JButton iniciarMusicaButton;
	private JLabel imagemFundo;
	static private ArrayList<Treinador> treinadores = new ArrayList<>();

	private GridBagConstraints cadastroVilaoConstraints;
	private GridBagConstraints cadastroDigiEscolhidoConstraints;
	private GridBagConstraints listarConstraints;
	private GridBagConstraints pesquisarConstraints;
	private GridBagConstraints sairButtonConstraints;
	private GridBagConstraints pararMusicaButtonConstraints;
	private GridBagConstraints iniciarMusicaButtonConstraints;
	private GridBagConstraints imagemLabelConstraints;
	private GridBagConstraints listarDigimonsButtonConstraints;

	public Menu() {

		super("Menu");
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private void initialize() {
		setLayout(new GridBagLayout());
		add(getCadastroButton(), getcadastroVilaoConstraints());
		add(getCadastroDigiEscolhidoButton(), getCadastroDigiEscolhidoConstraints());
		add(getListarButton(), getListarConstraints());
		add(getPesquisarButton(), getPesquisarConstraints());
		add(getSairButton(), getSairConstraints());
		add(getImagemFundo(), getImagemLabelConstraints());
		add(getListarDigimonsButton(), getListarDigimonsButtonConstraints());
		add(getIniciarMusicaButton(), getIniciarMusicaButtonConstraints());
		add(getPararMusicaButton(), getPararMusicaButtonConstraints());
	}

	public JButton getCadastroButton() {

		if (cadastroVilaoButton == null) {
			ImageIcon img = new ImageIcon("Imagens projeto/vilao.jpg");
			cadastroVilaoButton = new JButton(img);
			cadastroVilaoButton.setPreferredSize(new Dimension(80, 80));
			cadastroVilaoButton.setToolTipText("Cadastrar Vil�o");
			cadastroVilaoButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					new CadastrarVilaoFrame(treinadores).setVisible(true);
					dispose();
				}
			});
		}
		return cadastroVilaoButton;
	}

	public GridBagConstraints getcadastroVilaoConstraints() {
		if (cadastroVilaoConstraints == null) {
			cadastroVilaoConstraints = new GridBagConstraints();
			cadastroVilaoConstraints.gridx = 0;
			cadastroVilaoConstraints.gridy = 0;
		}
		return cadastroVilaoConstraints;
	}

	public JButton getCadastroDigiEscolhidoButton() {
		if (cadastroDigiEscolhidoButton == null) {
			ImageIcon img = new ImageIcon("Imagens projeto/digiescolhido.jpg");
			cadastroDigiEscolhidoButton = new JButton(img);
			cadastroDigiEscolhidoButton.setPreferredSize(new Dimension(80, 80));
			cadastroDigiEscolhidoButton.setToolTipText("Cadastrar DigiEscolhido");
			cadastroDigiEscolhidoButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					new CadastrarDigiEscolhidoFrame(treinadores).setVisible(true);
					dispose();
				}
			});
		}
		return cadastroDigiEscolhidoButton;
	}

	public GridBagConstraints getCadastroDigiEscolhidoConstraints() {
		if (cadastroDigiEscolhidoConstraints == null) {
			cadastroDigiEscolhidoConstraints = new GridBagConstraints();
			cadastroDigiEscolhidoConstraints.gridx = 1;
			cadastroDigiEscolhidoConstraints.gridy = 0;
		}
		return cadastroDigiEscolhidoConstraints;
	}

	public JButton getListarButton() {

		if (listarButton == null) {
			ImageIcon img = new ImageIcon("Imagens projeto/listar.png");
			listarButton = new JButton(img);
			listarButton.setPreferredSize(new Dimension(80, 80));
			listarButton.setToolTipText("Listar Treinadores");
			listarButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					if (treinadores.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Nenhum treinador cadastrado");
					} else {
						dispose();
						new ListarTreinadoresFrame(treinadores, 0).setVisible(true);
					}
				}
			});
		}
		return listarButton;
	}

	public GridBagConstraints getListarConstraints() {
		if (listarConstraints == null) {
			listarConstraints = new GridBagConstraints();
			listarConstraints.gridx = 2;
			listarConstraints.gridy = 0;
		}
		return listarConstraints;
	}

	private JButton getListarDigimonsButton() {
		if (listarDigimonsButton == null) {
			ImageIcon img = new ImageIcon("Imagens projeto/digimons.jpg");
			listarDigimonsButton = new JButton(img);
			listarDigimonsButton.setPreferredSize(new Dimension(80, 80));
			listarDigimonsButton.setToolTipText("Listar Digimons");
			listarDigimonsButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					if (treinadores.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Nenhum digimon cadastrado");
					} else {
						new ListarDigimonsFrame(treinadores).setVisible(true);
					}
				}
			});
		}
		return listarDigimonsButton;
	}

	private GridBagConstraints getListarDigimonsButtonConstraints() {
		if (listarDigimonsButtonConstraints == null) {
			listarDigimonsButtonConstraints = new GridBagConstraints();
			listarDigimonsButtonConstraints.gridx = 3;
			listarDigimonsButtonConstraints.gridy = 0;
		}
		return listarDigimonsButtonConstraints;
	}

	public JButton getPesquisarButton() {
		if (pesquisarButton == null) {
			ImageIcon img = new ImageIcon("Imagens projeto/pesquisa.png");
			pesquisarButton = new JButton(img);
			pesquisarButton.setPreferredSize(new Dimension(80, 80));
			pesquisarButton.setToolTipText("Pesquisar");
			pesquisarButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					if (treinadores.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Nenhum treinador cadastrado");
					} else {
						dispose();
						new PesquisarFrame(treinadores).setVisible(true);
					}
				}
			});
		}
		return pesquisarButton;
	}

	public GridBagConstraints getPesquisarConstraints() {
		if (pesquisarConstraints == null) {
			pesquisarConstraints = new GridBagConstraints();
			pesquisarConstraints.gridx = 4;
			pesquisarConstraints.gridy = 0;
		}
		return pesquisarConstraints;
	}

	public JButton getSairButton() {

		if (sairButton == null) {
			ImageIcon img = new ImageIcon("Imagens projeto/sair.png");
			sairButton = new JButton(img);
			sairButton.setToolTipText("Sair");
			sairButton.setPreferredSize(new Dimension(80, 80));
			sairButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Saindo");
					dispose();
				}
			});
		}
		return sairButton;
	}

	public GridBagConstraints getSairConstraints() {
		if (sairButtonConstraints == null) {
			sairButtonConstraints = new GridBagConstraints();
			sairButtonConstraints.gridx = 5;
			sairButtonConstraints.gridy = 0;
		}
		return sairButtonConstraints;
	}

	public GridBagConstraints getImagemLabelConstraints() {
		if (imagemLabelConstraints == null) {
			imagemLabelConstraints = new GridBagConstraints();
			imagemLabelConstraints.gridx = 0;
			imagemLabelConstraints.gridy = 1;
			imagemLabelConstraints.gridheight = 2;
			imagemLabelConstraints.gridwidth = 6;
		}
		return imagemLabelConstraints;
	}

	public JLabel getImagemFundo() {
		if (imagemFundo == null) {
			ImageIcon img = new ImageIcon("Imagens projeto/fundo.png");
			imagemFundo = new JLabel(img);
			imagemFundo.setPreferredSize(new Dimension(480, 290));

		}
		return imagemFundo;
	}

	public JButton getPararMusicaButton() {
		if (pararMusicaButton == null) {
			ImageIcon img = new ImageIcon("Imagens projeto/pararmusica.png");
			pararMusicaButton = new JButton(img);
			pararMusicaButton.setPreferredSize(new Dimension(20, 20));
			pararMusicaButton.setToolTipText("Parar Musica");
			pararMusicaButton.setEnabled(false);
			pararMusicaButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {

						try {
							//clip.close();
							clip.stop();
							pararMusicaButton.setEnabled(false);
							iniciarMusicaButton.setEnabled(true);
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					
				}
			});
		}

		return pararMusicaButton;
	}

	public JButton getIniciarMusicaButton() {

		if (iniciarMusicaButton == null) {
			ImageIcon img = new ImageIcon("Imagens projeto/iniciarmusica.png");
			iniciarMusicaButton = new JButton(img);
			iniciarMusicaButton.setPreferredSize(new Dimension(20, 20));
			iniciarMusicaButton.setToolTipText("Iniciar Musica");

			
			iniciarMusicaButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					
					try {
						Random aleatorio = new Random();
						int n = aleatorio.nextInt(4) + 1; // numero de musica na pasta (come�ando em 0)
						File soundFile = new File("Musicas Projeto/" + n + ".wav");
						AudioInputStream sound = AudioSystem.getAudioInputStream(soundFile);
						DataLine.Info info = new DataLine.Info(Clip.class, sound.getFormat());
						clip = (Clip) AudioSystem.getLine(info);
						clip.open(sound);
						clip.start();
						clip.loop(100000000);
						iniciarMusicaButton.setEnabled(false);
						pararMusicaButton.setEnabled(true);
					}catch (UnsupportedAudioFileException | IOException | LineUnavailableException ev) {
						JOptionPane.showMessageDialog(null, "Deu ruim a musica!");
					}
				}
			});
		}
		return iniciarMusicaButton;
	}

	public GridBagConstraints getPararMusicaButtonConstraints() {
		if (pararMusicaButtonConstraints == null) {
			pararMusicaButtonConstraints = new GridBagConstraints();
			pararMusicaButtonConstraints.gridx = 1;
			pararMusicaButtonConstraints.gridy = 3;
		}

		return pararMusicaButtonConstraints;
	}

	public GridBagConstraints getIniciarMusicaButtonConstraints() {

		if (iniciarMusicaButtonConstraints == null) {
			iniciarMusicaButtonConstraints = new GridBagConstraints();
			iniciarMusicaButtonConstraints.gridx = 0;
			iniciarMusicaButtonConstraints.gridy = 3;
		}
		return iniciarMusicaButtonConstraints;
	}

}