package view;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import model.DigiEscolhido;
import model.Digimon;
import model.Evolucao;
import model.Habilidade;
import model.Treinador;
import model.Vilao;

public class ListarDigimonsFrame extends JFrame {

	private static final long serialVersionUID = 8993994686082667343L;

	private JTable digimonTable;
	private JPanel painelFundo;
	private int cont = 0;
	private JLabel elementoLabel;
	private JButton proximoDigiButton;
	private JButton anteriorDigiButton;

	private ArrayList<Treinador> treinadores = new ArrayList<>();
	private ArrayList<Digimon> digimons = new ArrayList<>();

	private GridBagConstraints painelFundoConstraints;
	private GridBagConstraints elementoLabelConstraints;
	private GridBagConstraints proximoDigiButtonConstraints;
	private GridBagConstraints anteriorDigiButtonConstraints;

	public ListarDigimonsFrame(ArrayList<Treinador> treinador) {
		super("Listagem de Digimons");
		treinadores = treinador;
		getDigimons();
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		

	}

	private void getDigimons() {
		for(Treinador t:treinadores){
			if(t instanceof Vilao){
				digimons.addAll(((Vilao)t).getDigiControlados()); 
			}else {
				digimons.add(((DigiEscolhido)t).getDigimon());
			}
		}
	}

	private void initialize() {
		setLayout(new GridBagLayout());
		add(getElementoLabel(digimons.get(cont)),getElementoLabelConstraints());
		add(getPainelFundo(digimons.get(cont)),getPainelFundoConstraints());
		add(getProximoDigiButton(),getProximoDigiButtonConstraints());
		add(getAnteriorDigiButton(),getAnteriorDigiButtonConstraints());
		anteriorDigiButton.setEnabled(false);
		if(digimons.size()==1) proximoDigiButton.setEnabled(false);
		
	}

	private JLabel getElementoLabel(Digimon digimon) {
		if (elementoLabel == null) {
			elementoLabel = new JLabel();
			elementoLabel.setText("Elemento: "+digimon.getElemento() );
		}
		return elementoLabel;
	}

	private GridBagConstraints getElementoLabelConstraints() {
		if (elementoLabelConstraints == null) {
			elementoLabelConstraints = new GridBagConstraints();
			elementoLabelConstraints.gridx = 0;
			elementoLabelConstraints.gridy = 0;
			elementoLabelConstraints.gridwidth = 3;
			elementoLabelConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return elementoLabelConstraints;
	}

	private JPanel getPainelFundo(Digimon digimon) {
		if (painelFundo == null) {
			String[] colunas = { "Evolu��es", "Level","Habilidades" };
			ArrayList<Evolucao> evolucoes = digimon.CopiaArray();
			String[][] dados = new String[evolucoes.size()][3];
			int i=0;
			for(Evolucao e: evolucoes){
				dados[i][0] = e.getNome();
				dados[i][1] = e.getLevel();
				int j =0;
				for(Habilidade h:e.getHabilidadePoder()){
					if(j==0){
						dados[i][2] = h.getNome();
					}else{
						dados[i][2] = dados[i][2] + h.getNome();
					}
					if(j<e.getHabilidadePoder().size()-1){
						dados[i][2] = dados[i][2]+", ";
					}
					
					j++;
				}
				i++;
			}
			
			
			digimonTable = new JTable(dados,colunas);
			Dimension prefSize = digimonTable.getPreferredSize();
			prefSize.width = 300;
			digimonTable.setPreferredSize(prefSize);
			JScrollPane barraRolagem = new JScrollPane(digimonTable);
			prefSize = barraRolagem.getPreferredSize();
			prefSize.width = 300;
			prefSize.height = 100;
			barraRolagem.setPreferredSize(prefSize);;
			painelFundo =  new JPanel();
			painelFundo.setLayout(new GridLayout(1,1));
			painelFundo.add(barraRolagem);
			prefSize = painelFundo.getPreferredSize();
			prefSize.width = 400;
			prefSize.height = 100;
			painelFundo.setPreferredSize(prefSize);
		}
		return painelFundo;
	}

	private GridBagConstraints getPainelFundoConstraints() {
		if (painelFundoConstraints == null) {
			painelFundoConstraints = new GridBagConstraints();
			painelFundoConstraints.gridx = 0;
			painelFundoConstraints.gridy = 1;
			painelFundoConstraints.gridwidth = 3;
			painelFundoConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return painelFundoConstraints;
	}
	
	public JButton getAnteriorDigiButton() {
		if (anteriorDigiButton== null) {
			anteriorDigiButton = new JButton("Digimon Anterior");
			anteriorDigiButton.addActionListener(new ActionListener() {

				
				public void actionPerformed(ActionEvent e) {
						cont--;
						
						remove(elementoLabel);
						elementoLabel = null;
						remove(painelFundo);
						painelFundo = null;
						if(cont>=digimons.size()-1)
							proximoDigiButton.setEnabled(false);
						else proximoDigiButton.setEnabled(true);
						if(cont>0)
							anteriorDigiButton.setEnabled(true);
						else anteriorDigiButton.setEnabled(false);
						pack();
						add(getElementoLabel(digimons.get(cont)),getElementoLabelConstraints());
						add(getPainelFundo(digimons.get(cont)),getPainelFundoConstraints());
						pack();
						
				}
			});
		}
		return anteriorDigiButton;
	}

	public GridBagConstraints getAnteriorDigiButtonConstraints() {
		if (anteriorDigiButtonConstraints == null) {
			anteriorDigiButtonConstraints = new GridBagConstraints();
			anteriorDigiButtonConstraints.gridx = 0;
			anteriorDigiButtonConstraints.gridy = 3;
			anteriorDigiButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return anteriorDigiButtonConstraints;
	}

	public JButton getProximoDigiButton() {
		if (proximoDigiButton== null) {
			proximoDigiButton = new JButton("Pr�ximo Digimon");
			proximoDigiButton.addActionListener(new ActionListener() {

				
				public void actionPerformed(ActionEvent e) {
						cont++;
						remove(elementoLabel);
						elementoLabel = null;
						remove(painelFundo);
						painelFundo = null;
						if(cont>=digimons.size()-1){
							proximoDigiButton.setEnabled(false);
						}else proximoDigiButton.setEnabled(true);
						if(cont>0){
							anteriorDigiButton.setEnabled(true);
						}else anteriorDigiButton.setEnabled(false);
						pack();
						add(getElementoLabel(digimons.get(cont)),getElementoLabelConstraints());
						add(getPainelFundo(digimons.get(cont)),getPainelFundoConstraints());
						pack();
					
				}
			});
		}
		return proximoDigiButton;
	}

	public GridBagConstraints getProximoDigiButtonConstraints() {
		if (proximoDigiButtonConstraints == null) {
			proximoDigiButtonConstraints = new GridBagConstraints();
			proximoDigiButtonConstraints.gridx = 1;
			proximoDigiButtonConstraints.gridy = 3;
			proximoDigiButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return proximoDigiButtonConstraints;
	}

}
