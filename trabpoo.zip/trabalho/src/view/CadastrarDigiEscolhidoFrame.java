package view;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import control.DAOException;
import control.DigimonDAO;
import model.DigiEscolhido;
import model.Digimon;
import model.Evolucao;
import model.Treinador;

public class CadastrarDigiEscolhidoFrame extends JFrame {

	private static final long serialVersionUID = 4673984048327928891L;
	
	private JLabel nomeLabel;
	private JLabel brasaoLabel;
	private JTextField nomeTextField;
	private JTextField brasaoTextField;
	private JButton continuarButton;
	private JButton cancelarButton;
	private JComboBox<String> selElemento;
	private JComboBox<String> selLevel;
	private JLabel elementoLabel;
	private JLabel evolucaoLabel;
	private JLabel nomeEvolucaoLabel;
	private JLabel levelLabel;
	private JLabel digimonLabel;
	private JButton addEvolucaoButton;
	private JTextField nomeEvolucaoTextField;
	private ArrayList<Treinador> treinador;
	private ArrayList<Evolucao> evolucoes = new ArrayList<>();
	
	private GridBagConstraints nomeLabelConstraints;
	private GridBagConstraints brasaoLabelConstraints;
	private GridBagConstraints nomeTextFieldConstraints;
	private GridBagConstraints brasaoTextFieldConstraints;
	private GridBagConstraints continuarButtonConstraints;
	private GridBagConstraints cancelarButtonConstraints;
	private GridBagConstraints selElementoConstraints;
	private GridBagConstraints elementoLabelConstraints;
	private GridBagConstraints evolucaoLabelConstraints;
	private GridBagConstraints selLevelConstraints;
	private GridBagConstraints nomeEvolucaoLabelConstraints;
	private GridBagConstraints nomeEvolucaoConstraints;
	private GridBagConstraints levelLabelConstraints;
	private GridBagConstraints addEvolucaoButtonConstraints;
	private GridBagConstraints digimonLabelConstraints;
	
	public CadastrarDigiEscolhidoFrame(ArrayList<Treinador> treinadores){
		super("Cadastrar DigiEscolhido");
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		treinador = treinadores;
	}

	private void initialize() {
		setLayout(new GridBagLayout());
		add(getNomeLabel(),getNomeLabelConstraints());
		add(getBrasaoLabel(),getBrasaoLabelConstraints());
		add(getNomeTextField(),getNomeTextFieldConstraints());
		add(getBrasaoTextField(),getBrasaoTextFieldConstraints());
		add(getContinuarButton(), getContinuarButtonConstraints());
		add(getCancelarButton(), getCancelarButtonConstraints());
		add(getElementoLabel(),getElementoLabelConstraints());
		add(getSelElemento(), getSelElementoConstraints());
		add(getEvolucaoLabel(),getEvolucaoLabelConstraints());
		add(getNomeEvolucaoLabel(), getNomeEvolucaoLabelConstraints());
		add(getNomeEvolucaoTextField(), getNomeEvolucaoConstraints());
		add(getLevelLabel(), getLevelLabelConstraints());
		add(getSelLevel(), getSelLevelConstraints());
		add(getAddEvolucaoButton(),getAddEvolucaoButtonConstraints());
		add(getDigimonLabel(),getDigimonLabelConstraints());
		//add(getSelElemento(), getSelElmentoConstraints());
	}
	
	public JLabel getNomeLabel() {
		if(nomeLabel==null)
		{
			nomeLabel = new JLabel();
			nomeLabel.setText("Nome: ");
		}
		return nomeLabel;
	}

	public GridBagConstraints getNomeLabelConstraints() {
		if(nomeLabelConstraints==null)
		{
			nomeLabelConstraints = new GridBagConstraints();
			nomeLabelConstraints.gridx = 0;
			nomeLabelConstraints.gridy = 0;
		}
		return nomeLabelConstraints;
	}
	public JLabel getBrasaoLabel() {
		if(brasaoLabel==null)
		{
			brasaoLabel = new JLabel();
			brasaoLabel.setText("Bras�o: ");
		}
		return brasaoLabel;
	}

	public GridBagConstraints getBrasaoLabelConstraints() {
		if(brasaoLabelConstraints==null)
		{
			brasaoLabelConstraints = new GridBagConstraints();
			brasaoLabelConstraints.gridx = 0;
			brasaoLabelConstraints.gridy = 1;
		}
		return brasaoLabelConstraints;
	}
	
	public JTextField getNomeTextField() {
		if(nomeTextField==null)
		{
			nomeTextField = new JTextField();
			Dimension prefSize = nomeTextField.getPreferredSize();
			prefSize.height = 30;
			prefSize.width = 150;
			nomeTextField.setPreferredSize(prefSize);
		}
		return nomeTextField;
	}
	
	public GridBagConstraints getNomeTextFieldConstraints() {
		if(nomeTextFieldConstraints==null)
		{
			nomeTextFieldConstraints = new GridBagConstraints();
			nomeTextFieldConstraints.gridx = 1;
			nomeTextFieldConstraints.gridy = 0;
		}
		return nomeTextFieldConstraints;
	}
	
	public JTextField getBrasaoTextField() {
		if(brasaoTextField==null)
		{
			brasaoTextField = new JTextField();
			Dimension prefSize = nomeTextField.getPreferredSize();
			prefSize.height = 30;
			prefSize.width = 150;
			brasaoTextField.setPreferredSize(prefSize);
		}
		return brasaoTextField;
	}
	
	public GridBagConstraints getBrasaoTextFieldConstraints() {
		if(brasaoTextFieldConstraints==null)
		{
			brasaoTextFieldConstraints = new GridBagConstraints();
			brasaoTextFieldConstraints.gridx = 1;
			brasaoTextFieldConstraints.gridy = 1;
		}
		return brasaoTextFieldConstraints;
	}
	
	public JLabel getDigimonLabel() {
		if(digimonLabel==null)
		{
			digimonLabel = new JLabel();
			digimonLabel.setText("Digimon");
			digimonLabel.setFont( new Font( "Serif", Font.BOLD,20 ) ); 
		}
		return digimonLabel;
	}

	public GridBagConstraints getDigimonLabelConstraints() {
		if(digimonLabelConstraints==null)
		{
			digimonLabelConstraints = new GridBagConstraints();
			digimonLabelConstraints.gridx = 0;
			digimonLabelConstraints.gridy = 2;
			digimonLabelConstraints.gridwidth = 2;
			digimonLabelConstraints.insets = new Insets(10, 10, 10, 10);
		}
		return digimonLabelConstraints;
	}
	
	public JButton getContinuarButton() {
		if(continuarButton==null){
			continuarButton = new JButton("Continuar");
			continuarButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					if(!nomeTextField.getText().equals("") && !brasaoTextField.getText().equals("") && evolucoes.size()!=0 ){
							if(selElemento.getSelectedIndex()!=0){
							DigiEscolhido digiEscolhido = new DigiEscolhido();
							digiEscolhido.setBrasao(brasaoTextField.getText());
							digiEscolhido.setNome(nomeTextField.getText());
							Digimon digimon = new Digimon();
							digimon.setElemento((String)selElemento.getSelectedItem());
							for(Evolucao ev: evolucoes){
								digimon.addEvolucao(ev);
							}
							digiEscolhido.setDigimon(digimon);
							treinador.add(digiEscolhido);
							digiEscolhido.setDigimon(digimon);
							
							try {
								new DigimonDAO().addDigimon(digiEscolhido);
							} catch (DAOException e1) {
								new DAOException("Erro ao salvar no arquivo",e1);
							}
							new Menu().setVisible(true);
							dispose();
						}else JOptionPane.showMessageDialog(null, "Selecione um elemento v�lido para o digimon");
					}else{
						JOptionPane.showMessageDialog(null, "Existem Campos em branco e/ou n�o adicionou uma evolucao");
					}
				}
			});
		}
		return continuarButton;
	}
	public GridBagConstraints getContinuarButtonConstraints() {
		if(continuarButtonConstraints==null)
		{
			continuarButtonConstraints = new GridBagConstraints();
			continuarButtonConstraints.gridx = 0;
			continuarButtonConstraints.gridy = 8;
			continuarButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return continuarButtonConstraints;
	}
	
	public JButton getCancelarButton() {
		if(cancelarButton==null){
			cancelarButton = new JButton("Cancelar");
			cancelarButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					new Menu().setVisible(true);
				}
			});
		}
		return cancelarButton;
	}

	public GridBagConstraints getCancelarButtonConstraints() {
		if(cancelarButtonConstraints==null)
		{
			cancelarButtonConstraints = new GridBagConstraints();
			cancelarButtonConstraints.gridx = 1;
			cancelarButtonConstraints.gridy = 8;
			cancelarButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return cancelarButtonConstraints;
	}
	
	public JComboBox<?> getSelElemento() {
		if(selElemento==null){
			String el[] = {"-Selecione-", "Agua", "Fogo", "Gelo", "Luz", "Madeira", "Metal", "Terra", "Trevas", "Trovao", "Vento" };
			selElemento = new JComboBox<String>(el);
		}
		return selElemento;
	}

	public GridBagConstraints getSelElementoConstraints() {
		if(selElementoConstraints==null){
			selElementoConstraints = new GridBagConstraints();
			selElementoConstraints.gridx = 1;
			selElementoConstraints.gridy = 3;
		}
		return selElementoConstraints;
	}
	
	


	public JLabel getElementoLabel() {
		if(elementoLabel==null){
			elementoLabel = new JLabel();
			elementoLabel.setText("Elemento: ");
		}
		return elementoLabel;
	}


	public GridBagConstraints getElementoLabelConstraints() {
		if(elementoLabelConstraints==null){
			elementoLabelConstraints = new GridBagConstraints();
			elementoLabelConstraints.gridx = 0;
			elementoLabelConstraints.gridy = 3;
		}
		return elementoLabelConstraints;
	}


	public JLabel getEvolucaoLabel() {
		if(evolucaoLabel==null){
			evolucaoLabel = new JLabel();
			evolucaoLabel.setText("   Evolu��o");
			evolucaoLabel.setFont( new Font( "Serif", Font.BOLD,16 ) ); 
			evolucaoLabel.setPreferredSize(new Dimension(100,50));
		}
		return evolucaoLabel;
	}


	public GridBagConstraints getEvolucaoLabelConstraints() {
		if(evolucaoLabelConstraints==null){
			evolucaoLabelConstraints = new GridBagConstraints();
			evolucaoLabelConstraints.gridx = 0;
			evolucaoLabelConstraints.gridy = 4;
			evolucaoLabelConstraints.gridwidth = 2;
		}
		return evolucaoLabelConstraints;
	}

	public JLabel getNomeEvolucaoLabel() {
		if(nomeEvolucaoLabel==null){
			nomeEvolucaoLabel = new JLabel();
			nomeEvolucaoLabel.setText("Nome da Evolu��o: ");
		}
		return nomeEvolucaoLabel;
	}


	public GridBagConstraints getNomeEvolucaoLabelConstraints() {
		if(nomeEvolucaoLabelConstraints==null){
			nomeEvolucaoLabelConstraints = new GridBagConstraints();
			nomeEvolucaoLabelConstraints.gridx = 0;
			nomeEvolucaoLabelConstraints.gridy = 5;
		}
		return nomeEvolucaoLabelConstraints;
	}


	public JTextField getNomeEvolucaoTextField() {
		if(nomeEvolucaoTextField==null)
		{
			nomeEvolucaoTextField = new JTextField();
			Dimension prefSize = nomeEvolucaoTextField.getPreferredSize();
			prefSize.height = 30;
			prefSize.width = 200;
			nomeEvolucaoTextField.setPreferredSize(prefSize);
		}
		return nomeEvolucaoTextField;
	}


	public GridBagConstraints getNomeEvolucaoConstraints() {
		if(nomeEvolucaoConstraints==null)
		{
			nomeEvolucaoConstraints = new GridBagConstraints();
			nomeEvolucaoConstraints.gridx = 1;
			nomeEvolucaoConstraints.gridy = 5;
		}
		return nomeEvolucaoConstraints;
	}

	public JLabel getLevelLabel() {
		if(levelLabel==null){
			levelLabel = new JLabel();
			levelLabel.setText("Level da Evolu��o: ");
		}
		return levelLabel;
	}


	public GridBagConstraints getLevelLabelConstraints() {
		if(levelLabelConstraints==null){
			levelLabelConstraints = new GridBagConstraints();
			levelLabelConstraints.gridx = 0;
			levelLabelConstraints.gridy = 6;
		}
		return levelLabelConstraints;
	}
	

	public JComboBox<?> getSelLevel() {
		if(selLevel==null){
			String evol[] = { "-Selecione-","Bebe", "Treinamento", "Novato", "Campeao", "Supremo" };
			selLevel = new JComboBox<String>(evol);
		}
		return selLevel;
	}
	public GridBagConstraints getSelLevelConstraints() {
		if(selLevelConstraints==null){
			selLevelConstraints = new GridBagConstraints();
			selLevelConstraints.gridx = 1;
			selLevelConstraints.gridy = 6;
		}
		return selLevelConstraints;
	}


	public JButton getAddEvolucaoButton() {
		if(addEvolucaoButton==null){
			addEvolucaoButton = new JButton("Adicionar Evolu��o");
			addEvolucaoButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					if(selLevel.getSelectedIndex()!=0){
						//dispose();
						//new Menu().setVisible(true);
						//Digimon digimon = new Digimon();
						//digimon.setElemento((String)selElemento.getSelectedItem());
						Evolucao evolucao = new Evolucao();
						evolucao.setNome(nomeEvolucaoTextField.getText());
						evolucao.setLevel((String)selLevel.getSelectedItem());
						new CadastrarHabilidadesFrame(evolucao).setVisible(true);
						evolucoes.add(evolucao);
						nomeEvolucaoTextField.setText("");
						selLevel.setSelectedIndex(0);
						//dispose();
					}else JOptionPane.showMessageDialog(null, "Selecione um level v�lido para a evolu��o");
				}
			});
		}
		return addEvolucaoButton;
	}


	public GridBagConstraints getAddEvolucaoButtonConstraints() {
		if(addEvolucaoButtonConstraints==null){
			addEvolucaoButtonConstraints = new GridBagConstraints();
			addEvolucaoButtonConstraints.gridx = 0;
			addEvolucaoButtonConstraints.gridy = 7;
			addEvolucaoButtonConstraints.insets = new Insets(5, 5, 5, 5);
			
		}
		return addEvolucaoButtonConstraints;
	}
}
	

