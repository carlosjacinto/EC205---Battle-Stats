package view;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.Digimon;
import model.Evolucao;
import model.Vilao;

public class AddDigiControladosFrame extends JFrame{

	private static final long serialVersionUID = 490883283617765193L;
	
	private JComboBox<String> selElemento;
	private JComboBox<String>  selLevel;
	private JLabel elementoLabel;
	private JLabel evolucaoLabel;
	private JLabel nomeEvolucaoLabel;
	private JLabel levelLabel;
	private JButton addEvolucaoButton;
	private JTextField nomeEvolucaoTextField;
	private JButton salvarButton;
	private JButton addESalvarButton;
	private Vilao vilao = new Vilao(); 
	private Digimon digimon = new Digimon();
	
	private GridBagConstraints selElementoConstraints;
	private GridBagConstraints elementoLabelConstraints;
	private GridBagConstraints evolucaoLabelConstraints;
	private GridBagConstraints selLevelConstraints;
	private GridBagConstraints nomeEvolucaoLabelConstraints;
	private GridBagConstraints nomeEvolucaoConstraints;
	private GridBagConstraints levelLabelConstraints;
	private GridBagConstraints addEvolucaoButtonConstraints;
	private GridBagConstraints salvarButtonConstraints;
	private GridBagConstraints addESalvarButtonConstraints;
	
	public AddDigiControladosFrame( Vilao cadVilao ){
		super("Adicionar DigiControlado");
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		vilao = cadVilao;
	}
	
	
	private void initialize() {
		setLayout(new GridBagLayout());
		add(getElementoLabel(),getElementoLabelConstraints());
		add(getSelElemento(), getSelElementoConstraints());
		add(getEvolucaoLabel(),getEvolucaoLabelConstraints());
		add(getNomeEvolucaoLabel(), getNomeEvolucaoLabelConstraints());
		add(getNomeEvolucaoTextField(), getNomeEvolucaoConstraints());
		add(getLevelLabel(), getLevelLabelConstraints());
		add(getSelLevel(), getSelLevelConstraints());
		add(getAddEvolucaoButton(),getAddEvolucaoButtonConstraints());
		add(getSalvarButton(),getSalvarButtonConstraints());
		add(getAddESalvarButton(), getAddESalvarButtonConstraints());
	}
	
	public JComboBox<?> getSelElemento() {
		if(selElemento==null){
			String el[] = { "-Selecione-","Agua", "Fogo", "Gelo", "Luz", "Madeira", "Metal", "Terra", "Trevas", "Trovao", "Vento" };
			selElemento = new JComboBox<String> (el);
		}
		return selElemento;
	}

	public GridBagConstraints getSelElementoConstraints() {
		if(selElementoConstraints==null){
			selElementoConstraints = new GridBagConstraints();
			selElementoConstraints.gridx = 1;
			selElementoConstraints.gridy = 0;
		}
		return selElementoConstraints;
	}
	
	


	public JLabel getElementoLabel() {
		if(elementoLabel==null){
			elementoLabel = new JLabel();
			elementoLabel.setText("Elemento: ");
		}
		return elementoLabel;
	}


	public GridBagConstraints getElementoLabelConstraints() {
		if(elementoLabelConstraints==null){
			elementoLabelConstraints = new GridBagConstraints();
			elementoLabelConstraints.gridx = 0;
			elementoLabelConstraints.gridy = 0;
		}
		return elementoLabelConstraints;
	}


	public JLabel getEvolucaoLabel() {
		if(evolucaoLabel==null){
			evolucaoLabel = new JLabel();
			evolucaoLabel.setText("Evolu��o");
			evolucaoLabel.setFont( new Font( "Serif", Font.BOLD,16 ) ); 
			evolucaoLabel.setPreferredSize(new Dimension(100,50));
		}
		return evolucaoLabel;
	}


	public GridBagConstraints getEvolucaoLabelConstraints() {
		if(evolucaoLabelConstraints==null){
			evolucaoLabelConstraints = new GridBagConstraints();
			evolucaoLabelConstraints.gridx = 0;
			evolucaoLabelConstraints.gridy = 1;
			evolucaoLabelConstraints.gridwidth = 2;
		}
		return evolucaoLabelConstraints;
	}

	public JLabel getNomeEvolucaoLabel() {
		if(nomeEvolucaoLabel==null){
			nomeEvolucaoLabel = new JLabel();
			nomeEvolucaoLabel.setText("Nome da Evolu��o: ");
		}
		return nomeEvolucaoLabel;
	}


	public GridBagConstraints getNomeEvolucaoLabelConstraints() {
		if(nomeEvolucaoLabelConstraints==null){
			nomeEvolucaoLabelConstraints = new GridBagConstraints();
			nomeEvolucaoLabelConstraints.gridx = 0;
			nomeEvolucaoLabelConstraints.gridy = 2;
		}
		return nomeEvolucaoLabelConstraints;
	}


	public JTextField getNomeEvolucaoTextField() {
		if(nomeEvolucaoTextField==null)
		{
			nomeEvolucaoTextField = new JTextField();
			Dimension prefSize = nomeEvolucaoTextField.getPreferredSize();
			prefSize.height = 30;
			prefSize.width = 200;
			nomeEvolucaoTextField.setPreferredSize(prefSize);
		}
		return nomeEvolucaoTextField;
	}


	public GridBagConstraints getNomeEvolucaoConstraints() {
		if(nomeEvolucaoConstraints==null)
		{
			nomeEvolucaoConstraints = new GridBagConstraints();
			nomeEvolucaoConstraints.gridx = 1;
			nomeEvolucaoConstraints.gridy = 2;
		}
		return nomeEvolucaoConstraints;
	}

	public JLabel getLevelLabel() {
		if(levelLabel==null){
			levelLabel = new JLabel();
			levelLabel.setText("Level da Evolu��o: ");
		}
		return levelLabel;
	}


	public GridBagConstraints getLevelLabelConstraints() {
		if(levelLabelConstraints==null){
			levelLabelConstraints = new GridBagConstraints();
			levelLabelConstraints.gridx = 0;
			levelLabelConstraints.gridy = 3;
		}
		return levelLabelConstraints;
	}
	

	public JComboBox<?> getSelLevel() {
		if(selLevel==null){
			String evol[] = { "-Selecione-","Bebe", "Treinamento", "Novato", "Campeao", "Supremo" };
			selLevel = new JComboBox<String>(evol);
		}
		return selLevel;
	}
	public GridBagConstraints getSelLevelConstraints() {
		if(selLevelConstraints==null){
			selLevelConstraints = new GridBagConstraints();
			selLevelConstraints.gridx = 1;
			selLevelConstraints.gridy = 3;
		}
		return selLevelConstraints;
	}


	public JButton getAddEvolucaoButton() {
		if(addEvolucaoButton==null){
			addEvolucaoButton = new JButton("Adicionar Evolu��o");
			addEvolucaoButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					if(selLevel.getSelectedIndex()!=0){
						Evolucao evolucao = new Evolucao();
						evolucao.setNome(nomeEvolucaoTextField.getText());
						evolucao.setLevel((String)selLevel.getSelectedItem());
						digimon.addEvolucao(evolucao);
						new CadastrarHabilidadesFrame(evolucao).setVisible(true);
						nomeEvolucaoTextField.setText("");
						selLevel.setSelectedIndex(0);
					}else JOptionPane.showMessageDialog(null, "Selecione um level v�lido para a evolu��o");
				}
			});
		}
		return addEvolucaoButton;
	}


	public GridBagConstraints getAddEvolucaoButtonConstraints() {
		if(addEvolucaoButtonConstraints==null){
			addEvolucaoButtonConstraints = new GridBagConstraints();
			addEvolucaoButtonConstraints.gridx = 0;
			addEvolucaoButtonConstraints.gridy = 4;
			addEvolucaoButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return addEvolucaoButtonConstraints;
	}


	public JButton getSalvarButton() {
		if(salvarButton==null){
			salvarButton = new JButton("Salvar e voltar");
			salvarButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					if(selElemento.getSelectedIndex()!=0){
						digimon.setElemento((String)selElemento.getSelectedItem());
						vilao.addDigiControlado(digimon);
						new Menu().setVisible(true);
						dispose();
					}else JOptionPane.showMessageDialog(null, "Selecione um elemento v�lido para o DigiControlado");
				}
			});
		}
		return salvarButton;
	}


	public GridBagConstraints getSalvarButtonConstraints() {
		if(salvarButtonConstraints==null){
			salvarButtonConstraints = new GridBagConstraints();
			salvarButtonConstraints.gridx = 0;
			salvarButtonConstraints.gridy = 5;
			salvarButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return salvarButtonConstraints;
	}


	public JButton getAddESalvarButton() {
		if(addESalvarButton==null){
			addESalvarButton = new JButton("Salvar e Adicionar outro");
			addESalvarButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					if(selElemento.getSelectedIndex()!=0){
						digimon.setElemento((String)selElemento.getSelectedItem());
						vilao.addDigiControlado(digimon);
						dispose();
						new AddDigiControladosFrame( vilao).setVisible(true);
					}
				}
			});
		}
		return addESalvarButton;
	}


	public GridBagConstraints getAddESalvarButtonConstraints() {
		if(addESalvarButtonConstraints==null){
			addESalvarButtonConstraints = new GridBagConstraints();
			addESalvarButtonConstraints.gridx = 1;
			addESalvarButtonConstraints.gridy = 5;
			addESalvarButtonConstraints.insets = new Insets(5, 5, 5, 5);
		}
		return addESalvarButtonConstraints;
	}
	
}
