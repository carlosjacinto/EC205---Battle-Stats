package control;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import model.Treinador;

public class DigimonDAO {

	private static final String fileName = "Digimons.csv";

	public void addDigimon(Treinador d) throws DAOException {
		FileOutputStream fos = null;
		PrintStream filePrintStream = null;
		try {
			File file = new File(fileName);
			if (file.exists()) {
				file.createNewFile();
			}
			fos = new FileOutputStream(file, true);
			filePrintStream = new PrintStream(fos);
			String linha = d.toCSV();
			filePrintStream.println(linha);
		} catch (IOException e) {
			new DAOException("Falha ao adicionar Digimon", e);
		} finally {
			if (filePrintStream != null) {
				filePrintStream.close();
			} else if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
				}
			}
		}
	}

//	public ArrayList<Digimon> listarDigimon() throws DAOException{
//		ArrayList<Digimon> array =  new ArrayList<Digimon>();
//		
//		Scanner fileScanner;
//		try{
//			File file = new File(fileName);
//			if(file.exists()){
//				fileScanner = new Scanner(file);
//				while(fileScanner.hasNextLine()){
//					String line = fileScanner.nextLine();
//					int index = line.indexOf(",");
//					if(index==1){
//						throw new DAOException("Erro ao buscar no arquivo");
//					}
//					array.add(new Digimon(line));
//				}
//			}else{
//				System.out.println("N�o cadastrado, pois o arquivo nao existe");
//			}
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
}
