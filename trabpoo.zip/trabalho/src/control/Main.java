package control;

public class Main {

	public static void main(String[] args) {
		new view.Menu().setVisible(true);
	}

}