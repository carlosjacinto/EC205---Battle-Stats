package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import control.EmailValidator;

public class CadastroJogadorFrame extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5405046071294782278L;

	private static JFrame frame = new JFrame("Cadastro de Jogador");
	
	JTextField nomeUsuarioTxt = new JTextField(40);
	JTextField emailTxt = new JTextField(40);
	JTextField patenteTxt = new JTextField(40);
	JTextField kdTxt = new JTextField(40);
	JTextField scoreTxt = new JTextField(40);
	JTextField tempoJogoTxt = new JTextField(40);
	JPasswordField senhaTxt = new JPasswordField(40);
	JPasswordField senhaAgainTxt = new JPasswordField(40);
	
	JTextArea nomeUsuarioTxtAr = new JTextArea("Nome de usu�rio",1,40);
	JTextArea emailTxtAr = new JTextArea("E-mail",1,40);
	JTextArea patenteTxtAr = new JTextArea("Patente",1,40);
	JTextArea kdTxtAr = new JTextArea("K.D.",1,40);
	JTextArea scoreTxtAr = new JTextArea("Pontua��o",1,40);
	JTextArea tempoJogoTxtAr = new JTextArea("Tempo de Jogo",1,40);
	JTextArea senhaTxtAr = new JTextArea("Senha",1,40);
	JTextArea senhaAgainTxtAr = new JTextArea("Repita a senha",1,40);
	
	JButton okBt = new JButton("Confirmar");
	JButton cancelBt = new JButton("Cancelar");

	JPanel jp = new JPanel(new GridLayout(0,1));
	
	public CadastroJogadorFrame() {
		super (new BorderLayout());
		
		nomeUsuarioTxtAr.setEditable(false);
		emailTxtAr.setEditable(false);
		patenteTxtAr.setEditable(false);
		kdTxtAr.setEditable(false);
		scoreTxtAr.setEditable(false);
		tempoJogoTxtAr.setEditable(false);
		senhaTxtAr.setEditable(false);
		senhaAgainTxtAr.setEditable(false);
		
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelBt.addActionListener(this);
		cancelBt.setActionCommand("cancela");
		
		jp.add(nomeUsuarioTxtAr);
		jp.add(nomeUsuarioTxt);
		jp.add(emailTxtAr);
		jp.add(emailTxt);
		jp.add(patenteTxtAr);
		jp.add(patenteTxt);
		jp.add(kdTxtAr);
		jp.add(kdTxt);
		jp.add(scoreTxtAr);
		jp.add(scoreTxt);
		jp.add(tempoJogoTxtAr);
		jp.add(tempoJogoTxt);
		jp.add(senhaTxtAr);
		jp.add(senhaTxt);
		jp.add(senhaAgainTxtAr);
		jp.add(senhaAgainTxt);
		jp.add(okBt);
		jp.add(cancelBt);
		
		add(jp,BorderLayout.LINE_START);
	}
	
	boolean temCampoVazio(){
		if(nomeUsuarioTxt.getText().equals("")) return true;
		if(emailTxt.getText().equals("")) return true;
		if(patenteTxt.getText().equals("")) return true;
		if(kdTxt.getText().equals("")) return true;
		if(scoreTxt.getText().equals("")) return true;
		if(tempoJogoTxt.getText().equals("")) return true;
		if(senhaTxt.getPassword().length==0) return true;
		if(senhaAgainTxt.getPassword().length==0) return true;
		return false;
	}
	
	public void actionPerformed(ActionEvent e) {
		if("confirma".equals(e.getActionCommand())){
			
			if(temCampoVazio()){
				JOptionPane.showMessageDialog(frame, "Preencha todos os campos!","Campos em branco",JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			EmailValidator emailValidator = new EmailValidator();
			if(!emailValidator.validate(emailTxt.getText().trim())){
				JOptionPane.showMessageDialog(frame, "Entre com um e-mail v�lido!","E-mail inv�lido",JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			if(!senhaAgainTxt.getPassword().equals(senhaTxt.getPassword())){
				JOptionPane.showMessageDialog(frame, "As senhas n�o combinam!", "Senhas diferentes", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
		}
		else{
			LoginFrame volta = new LoginFrame();
			frame.dispose();
			volta.createAndShow();
		}
		
	}
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new CadastroJogadorFrame());
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		createAndShow();
	}
}
