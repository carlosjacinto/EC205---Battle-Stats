package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class CadastroPersonagemFrame extends JPanel implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7182186633670861622L;

	JTextArea classeTxtAr = new JTextArea("Classe",1,30);
	JTextArea primariaTxtAr = new JTextArea("Arma primaria",1,30);
	JTextArea secundariaTxtAr = new JTextArea("Arma secundaria",1,30);
	JTextArea item1TxtAr = new JTextArea("Item 1",1,30);
	JTextArea item2TxtAr = new JTextArea("Item 2",1,30);
	
	JComboBox<String> classeCb = new JComboBox<>();
	JComboBox<String> primariaCb = new JComboBox<>();
	JComboBox<String> secundariaCb = new JComboBox<>();
	JComboBox<String> item1Cb = new JComboBox<>();
	JComboBox<String> item2Cb = new JComboBox<>();
	
	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancelar");
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	
	private static JFrame frame = new JFrame("Novo personagem");
	
	public CadastroPersonagemFrame() {
		super(new BorderLayout());
		
		
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		
		jp.add(classeTxtAr);
		jp.add(classeCb);
		jp.add(primariaTxtAr);
		jp.add(primariaCb);
		jp.add(secundariaTxtAr);
		jp.add(secundariaCb);
		jp.add(item1TxtAr);
		jp.add(item1Cb);
		jp.add(item2TxtAr);
		jp.add(item2Cb);
		jp.add(okBt);
		jp.add(cancelaBt);
		
		add(jp, BorderLayout.LINE_START);
	}
	
	public void actionPerformed(ActionEvent e) {
		if("confirma".equals(e.getActionCommand())){
			MainMenuFrame volta = new MainMenuFrame();
			frame.dispose();
			volta.createAndShow();
		}
		else{
			MainMenuFrame volta = new MainMenuFrame();
			frame.dispose();
			volta.createAndShow();
		}
	}
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new CadastroPersonagemFrame());
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		createAndShow();
	}
}
