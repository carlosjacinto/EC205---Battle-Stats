package view;


import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class CadastroArmaFrame extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7180513158489494234L;

	String[] tipos = {"Assalto", "ADP", "M.L.", "Rifle de precis�o", "Carabina", "Escopeta", "DMR", "Pistola"};
	JComboBox<String> tiposArma = new JComboBox<>(tipos);
	
	JTextField nomeTxt = new JTextField(40);
	JTextField danoTxt = new JTextField(40);
	JTextField alcanceTxt = new JTextField(40);
	JTextField precisaoTxt = new JTextField(40);
	JTextField tiroSemVisadaTxt = new JTextField(40);
	JTextField estabilidadeTxt = new JTextField(40);
	JTextField cadenciaTxt = new JTextField(40);
	JTextField capacidadeTxt = new JTextField(40);
	JTextArea nomeTxtAr = new JTextArea("Nome",1,10);
	JTextArea danoTxtAr = new JTextArea("Dano",1,10);
	JTextArea alcanceTxtAr = new JTextArea("Alcance",1,10);
	JTextArea precisaoTxtAr = new JTextArea("Precis�o",1,10);
	JTextArea tiroSemVisadaTxtAr =  new JTextArea("Tiro sem visada",1,10);
	JTextArea estabilidadeTxtAr = new JTextArea("Establilidade",1,10);
	JTextArea cadenciaTxtAr = new JTextArea("Cad�ncia",1,10);
	JTextArea capacidadeTxtAr = new JTextArea("Capacidade do pente",1,10);
	
	JButton okBt = new JButton("Confirmar");
	JButton cancelaBt = new JButton("Cancelar");
	
	JCheckBox check = new JCheckBox("Acess�rio");
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	
	private static JFrame frame = new JFrame("Cadastrar Arma");
	
	public CadastroArmaFrame() {
		super(new BorderLayout());
		
		nomeTxtAr.setEditable(false);
		danoTxtAr.setEditable(false);
		alcanceTxtAr.setEditable(false);
		precisaoTxtAr.setEditable(false);
		tiroSemVisadaTxtAr.setEditable(false);
		estabilidadeTxtAr.setEditable(false);
		cadenciaTxtAr.setEditable(false);
		capacidadeTxtAr.setEditable(false);
		
		check.addActionListener(this);
		
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tiposArma);
		jp.add(check);
		jp.add(danoTxtAr);
		jp.add(danoTxt);
		jp.add(alcanceTxtAr);
		jp.add(alcanceTxt);
		jp.add(precisaoTxtAr);
		jp.add(precisaoTxt);
		jp.add(tiroSemVisadaTxtAr);
		jp.add(tiroSemVisadaTxt);
		jp.add(estabilidadeTxtAr);
		jp.add(estabilidadeTxt);
		jp.add(cadenciaTxtAr);
		jp.add(cadenciaTxt);
		jp.add(capacidadeTxtAr);
		jp.add(capacidadeTxt);
		jp.add(okBt);
		jp.add(cancelaBt);
		
		add(jp, BorderLayout.LINE_START);
	}
	
	boolean temCampoEmBranco(){
		if(nomeTxt.getText().equals("")) return true;
		if(danoTxt.getText().equals("")) return true;
		if(alcanceTxt.getText().equals("")) return true;
		if(precisaoTxt.getText().equals("")) return true;
		if(tiroSemVisadaTxt.getText().equals("")) return true;
		if(estabilidadeTxt.getText().equals("")) return true;
		if(cadenciaTxt.getText().equals("")) return true;
		if(capacidadeTxt.getText().equals("")) return true;
		return false;
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if("confirma".equals(e.getActionCommand())){
			
			if(temCampoEmBranco()){
				JOptionPane.showMessageDialog(frame, "Preencha todos os campos", "Campos em branco", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
		}
		if("cancela".equals(e.getActionCommand())){
			MainMenuAdmFrame volta = new MainMenuAdmFrame();
			frame.dispose();
			volta.createAndShow();
			return;
		}
		
		if(check.isSelected()){
			danoTxt.setVisible(false); danoTxtAr.setVisible(false);
			alcanceTxt.setVisible(false); alcanceTxtAr.setVisible(false);
			precisaoTxt.setVisible(false); precisaoTxtAr.setVisible(false);
			tiroSemVisadaTxt.setVisible(false); tiroSemVisadaTxtAr.setVisible(false);
			estabilidadeTxt.setVisible(false); estabilidadeTxtAr.setVisible(false);
			cadenciaTxt.setVisible(false); cadenciaTxtAr.setVisible(false);
			capacidadeTxt.setVisible(false); capacidadeTxtAr.setVisible(false);
			frame.pack();
			return;
		}
		else{
			danoTxt.setVisible(true); danoTxtAr.setVisible(true);
			alcanceTxt.setVisible(true); alcanceTxtAr.setVisible(true);
			precisaoTxt.setVisible(true); precisaoTxtAr.setVisible(true);
			tiroSemVisadaTxt.setVisible(true); tiroSemVisadaTxtAr.setVisible(true);
			estabilidadeTxt.setVisible(true); estabilidadeTxtAr.setVisible(true);
			cadenciaTxt.setVisible(true); cadenciaTxtAr.setVisible(true);
			capacidadeTxt.setVisible(true); capacidadeTxtAr.setVisible(true);
			frame.pack();
		}

	}
	
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new CadastroArmaFrame());
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		createAndShow();
	}
}
