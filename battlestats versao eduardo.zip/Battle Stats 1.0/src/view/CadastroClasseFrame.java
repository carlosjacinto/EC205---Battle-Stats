package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class CadastroClasseFrame extends JPanel implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6228372735673803479L;

	String[] tipos = {"Assalto", "ADP", "M.L.", "Rifle de precis�o"};
	JComboBox<String> tiposCb = new JComboBox<>(tipos);
	
	JTextArea nomeTxtAr = new JTextArea("Nome",1,10);
	JTextArea tipoTxtAr = new JTextArea("Nome",1,10);
	JTextField nomeTxt = new JTextField(40);
	
	private static JFrame frame = new JFrame("Cadastro de classe");
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	
	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancela");
	
	public CadastroClasseFrame() {
		super(new BorderLayout());
		
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		
		nomeTxtAr.setEditable(false);
		tipoTxtAr.setEditable(false);
		
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tipoTxtAr);
		jp.add(tiposCb);
		jp.add(okBt);
		jp.add(cancelaBt);
		
		add(jp,BorderLayout.LINE_START);
		
	}
	
	boolean temCampoEmBranco(){
		if(nomeTxt.getText().equals("")) return true;
		return false;
	}
	
	public void actionPerformed(ActionEvent e) {
		if("confirma".equals(e.getActionCommand())){
			MainMenuAdmFrame volta = new MainMenuAdmFrame();
			frame.dispose();
			volta.createAndShow();
		}
		else{
			MainMenuAdmFrame volta = new MainMenuAdmFrame();
			frame.dispose();
			volta.createAndShow();
		}
	}
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new CadastroClasseFrame());
		frame.setVisible(true);
		frame.pack();
	}
	
	public static void main(String[] args) {
		createAndShow();
	}

}
