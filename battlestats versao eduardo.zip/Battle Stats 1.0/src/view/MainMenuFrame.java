package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainMenuFrame extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6727930359206926641L;
	
	JButton novoPersonagemBt = new JButton("Novo personagem");
	JButton editarPersonagemBt = new JButton("Editar um personagem");
	JButton verPersonagensBt = new JButton("Ver personagens");
	JButton excluirPersonagemBt = new JButton("Excluir um personagem");
	JButton verArmasBt = new JButton("Ver armas");
	JButton verVeiculosBt= new JButton("Ver veiculos");
	JButton verClassesBt = new JButton("Ver classes");
	JButton verContaBt = new JButton("Ver minha conta");
	JButton editarContaBt = new JButton("Editar minha conta");
	JButton rankingBt = new JButton("Ranking de jogadores");
	JButton voltarBt = new JButton("Voltar");
	
	private static JFrame frame = new JFrame("Menu");
	
	JPanel jp = new JPanel(new GridLayout(0, 1));
	
	public MainMenuFrame() {
		super( new BorderLayout());
		
		novoPersonagemBt.setActionCommand("novoPersonagem");
		novoPersonagemBt.addActionListener(this);
		editarPersonagemBt.setActionCommand("editarPersonagem");
		editarPersonagemBt.addActionListener(this);
		verPersonagensBt.setActionCommand("verPersonagens");
		verPersonagensBt.addActionListener(this);
		excluirPersonagemBt.setActionCommand("excluirPersonagem");
		excluirPersonagemBt.addActionListener(this);
		verArmasBt.setActionCommand("verArmas");
		verArmasBt.addActionListener(this);
		verVeiculosBt.setActionCommand("verVeiculos");
		verVeiculosBt.addActionListener(this);
		verClassesBt.setActionCommand("verClasses");
		verClassesBt.addActionListener(this);
		verContaBt.setActionCommand("verConta");
		verContaBt.addActionListener(this);
		editarContaBt.setActionCommand("editarConta");
		editarContaBt.addActionListener(this);
		rankingBt.setActionCommand("ranking");
		rankingBt.addActionListener(this);
		voltarBt.setActionCommand("voltar");
		voltarBt.addActionListener(this);
		
		jp.add(novoPersonagemBt);
		jp.add(editarPersonagemBt);
		jp.add(verPersonagensBt);
		jp.add(excluirPersonagemBt);
		jp.add(verArmasBt);
		jp.add(verVeiculosBt);
		jp.add(verClassesBt);
		jp.add(verContaBt);
		jp.add(editarContaBt);
		jp.add(rankingBt);
		jp.add(voltarBt);
		
		add(jp,BorderLayout.LINE_START);
	}
	
	public void actionPerformed(ActionEvent e) {
		if("voltar".equals(e.getActionCommand())){
			frame.dispose();
			LoginFrame voltar = new LoginFrame();
			voltar.createAndShow();
		}
	}
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new MainMenuFrame());
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		createAndShow();
	}
}
