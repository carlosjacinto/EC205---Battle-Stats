package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import control.EmailValidator;

public class LoginFrame extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1999667136136945782L;
	
	JTextField emailTxt = new JTextField(40);
	JPasswordField senhaTxt =  new JPasswordField(40);
	JTextArea emailTxtAr = new JTextArea("E-mail",1,40);
	JTextArea senhaTxtAr = new JTextArea("Senha",1,40);
	JButton okBt = new JButton("Login");
	JButton cadastroBt = new JButton("Nova conta");
	
	private static JFrame frame =  new JFrame("Battle Stats");
	
	JPanel jp = new JPanel(new GridLayout(0, 1));
	
	public LoginFrame() {
		super( new BorderLayout());
		
		emailTxtAr.setEditable(false);
		senhaTxtAr.setEditable(false);
		
		okBt.setActionCommand("loginB");
		okBt.addActionListener(this);
		
		cadastroBt.setActionCommand("cadastroB");
		cadastroBt.addActionListener(this);
		
		jp.add(emailTxtAr);
		jp.add(emailTxt);
		jp.add(senhaTxtAr);
		jp.add(senhaTxt);
		jp.add(okBt);
		jp.add(cadastroBt);
		add(jp,BorderLayout.LINE_START);
	}

	public void actionPerformed(ActionEvent e) {
		if("loginB".equals(e.getActionCommand())){
			
			if(emailTxt.getText().equals("") || senhaTxt.getPassword().equals("")){
				JOptionPane.showMessageDialog(frame, "Entre com o nome de usu�rio e senha","Campos em branco", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			EmailValidator emailValidator = new EmailValidator();
			if(!emailValidator.validate(emailTxt.getText().trim())){
				JOptionPane.showMessageDialog(frame,"Digite um e-mail v�lido","E-mail inv�lido!", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			if(true){
				MainMenuFrame menu = new MainMenuFrame();
				menu.createAndShow();
				frame.dispose();
				return;
			}
			
			MainMenuAdmFrame menu = new MainMenuAdmFrame();
			menu.createAndShow();
			frame.dispose();
			
		}
		
		else{
			CadastroJogadorFrame novaConta = new CadastroJogadorFrame();
			frame.dispose();
			novaConta.createAndShow();
		}
	}
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new LoginFrame());
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		createAndShow();
	}
	
}
