package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class CadastroVeiculoFrame extends JPanel implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 480749330051613029L;

	JTextField nomeTxt = new JTextField(40);
	JTextField primariaTxt = new JTextField(40);
	JTextField secundariaTxt = new JTextField(40);
	JTextArea nomeTxtAr = new JTextArea("Nome",1,30);
	JTextArea tipoAr = new JTextArea("Tipo",1,30);
	JTextArea primariaTxtAr = new JTextArea("Arma primaria",1,30);
	JTextArea secundariaTxtAr = new JTextArea("Arma secundaria",1,30);
	
	JCheckBox check = new JCheckBox("Possui armamento");
	
	String[] tipos = {"Transporte", "Blindado", "Helic�ptero", "Jato", "Barco"};
	JComboBox<String> tipoCb = new JComboBox<>(tipos);
	
	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancela");
	
	private static JFrame frame = new JFrame();
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	
	public CadastroVeiculoFrame() {
		super(new BorderLayout());
		
		nomeTxtAr.setEditable(false);
		tipoAr.setEditable(false);
		primariaTxtAr.setEditable(false);
		primariaTxt.setVisible(false);
		primariaTxtAr.setVisible(false);
		secundariaTxtAr.setEditable(false);
		secundariaTxt.setVisible(false);
		secundariaTxtAr.setVisible(false);
		
		tipoCb.setSelectedIndex(0);
		
		check.addActionListener(this);
		
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tipoAr);
		jp.add(tipoCb);
		jp.add(check);
		jp.add(primariaTxtAr);
		jp.add(primariaTxt);
		jp.add(secundariaTxtAr);
		jp.add(secundariaTxt);
		jp.add(okBt);
		jp.add(cancelaBt);
		
		add(jp, BorderLayout.LINE_START);
		
	}
	
	boolean temCampoEmBranco(){
		if(nomeTxt.getText().equals("")) return true;
		if(check.isSelected()){
			if(primariaTxt.getText().equals("")) return true;
			if(secundariaTxt.getText().equals("")) return true;
		}
		return false;
	}
	
	public void actionPerformed(ActionEvent e) {
		if("confirma".equals(e.getActionCommand())){
			
			if(temCampoEmBranco()){
				JOptionPane.showMessageDialog(frame, "Preencha todos os campos", "Campos em branco", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
		}
		if("cancela".equals(e.getActionCommand())){
			MainMenuAdmFrame volta = new MainMenuAdmFrame();
			frame.dispose();
			volta.createAndShow();
			return;
		}
		
		if(check.isSelected()){
			primariaTxt.setVisible(true);
			primariaTxtAr.setVisible(true);
			secundariaTxt.setVisible(true);
			secundariaTxtAr.setVisible(true);
			frame.pack();
			return;
		}
		else{
			primariaTxt.setVisible(false);
			primariaTxtAr.setVisible(false);
			secundariaTxt.setVisible(false);
			secundariaTxtAr.setVisible(false);
			frame.pack();
		}
		
	}
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new CadastroVeiculoFrame());
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		createAndShow();
	}

}
