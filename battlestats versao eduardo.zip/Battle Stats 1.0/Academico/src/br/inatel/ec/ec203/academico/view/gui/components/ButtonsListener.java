package br.inatel.ec.ec203.academico.view.gui.components;

public interface ButtonsListener {

	public void okPerformed();
	
	public void cancelPerformed();
	
}
