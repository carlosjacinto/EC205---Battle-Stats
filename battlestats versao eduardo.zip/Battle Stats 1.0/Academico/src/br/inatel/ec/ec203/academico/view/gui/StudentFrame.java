package br.inatel.ec.ec203.academico.view.gui;

import java.awt.BorderLayout;

import javax.swing.JFrame;

import br.inatel.ec.ec203.academico.view.gui.components.ButtonsPanel;

public class StudentFrame extends JFrame {

	private static final long serialVersionUID = -2342866428008834599L;

	private StudentDataPanel studentDataPanel;
	private ButtonsPanel buttonsPanel;
	
	public StudentFrame() {
		super("Cadastro de aluno");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		initialize();
		
		pack();
		setLocationRelativeTo(null);
		setResizable(false);
	}

	private void initialize() {
		add(getStudentDataPanel(), BorderLayout.CENTER);
		add(getButtonsPanel(), BorderLayout.PAGE_END);
	}

	private StudentDataPanel getStudentDataPanel() {
		if (studentDataPanel == null) {
			studentDataPanel = new StudentDataPanel();
		}
		return studentDataPanel;
	}

	private ButtonsPanel getButtonsPanel() {
		if (buttonsPanel == null) {
			buttonsPanel = new ButtonsPanel();
		}
		return buttonsPanel;
	}
	
}




