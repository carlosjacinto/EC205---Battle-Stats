package br.inatel.ec.ec203.academico.view.gui.components;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;

public class ButtonsPanel extends JPanel {

	private static final long serialVersionUID = 5448683756786440994L;

	private JButton okButton;
	private JButton cancelButton;
	
	private ArrayList<ButtonsListener> listeners = new ArrayList<>();

	public ButtonsPanel() {
		super();
		
		initialize();
	}
	
	private void initialize() {
		add(getOkButton());
		add(getCancelButton());
	}

	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setText("OK");
			okButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					okClicked();
				}
			});
		}
		return okButton;
	}

	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setText("Cancelar");
			cancelButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					cancelClicked();
				}
			});
		}
		return cancelButton;
	}
	
	protected void okClicked() {
		for (ButtonsListener listener: listeners) {
			listener.okPerformed();
		}
	}

	protected void cancelClicked() {
		for (ButtonsListener listener: listeners) {
			listener.cancelPerformed();
		}
	}

	public void addButtonsListener(ButtonsListener listener) {
		listeners.add(listener);
	}

}







