package br.inatel.ec.ec203.academico.view.gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class StudentDataPanel extends JPanel {

	private static final long serialVersionUID = -1083517349921651772L;

	private JLabel nameLabel;
	private JTextField nameTextField;
	private JLabel studentNumberLabel;
	private JTextField studentNumberTextField;
	private JLabel typeLabel;
	private JComboBox<String> typeComboBox;
	
	private GridBagConstraints nameLabelConstraints;
	private GridBagConstraints nameTextFieldConstraints;
	private GridBagConstraints studentNumberLabelConstraints;
	private GridBagConstraints studentNumberTextFieldConstraints;
	private GridBagConstraints typeLabelConstraints;
	private GridBagConstraints typeComboBoxConstraints;
	
	public StudentDataPanel() {
		super();
		
		initialize();
	}
	
//	@Override
//	protected void paintComponent(Graphics g) {
//		super.paintComponent(g);
//		ImageIcon imageIcon = new ImageIcon("test.jpg");
//		g.drawImage(imageIcon.getImage(), x, y, observer)
//	}
//
	private void initialize() {
		setLayout(new GridBagLayout());
		setBorder(createBorder());
		
		add(getNameLabel(), getNameLabelConstraints());
		add(getStudentNumberLabel(), getStudentNumberLabelConstraints());
		add(getNameTextField(), getNameTextFieldConstraints());
		add(getStudentNumberTextField(), getStudentNumberTextFieldConstraints());
		add(getTypeLabel(), getTypeLabelConstraints());
		add(getTypeComboBox(), getTypeComboBoxConstraints());
	}

	private Border createBorder() {
		TitledBorder titledBorder = new TitledBorder("Dados do aluno:");
		EmptyBorder outerEmptyBorder = new EmptyBorder(5, 5, 5, 5);
		EmptyBorder innerEmptyBorder = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder innerBorder = new CompoundBorder(titledBorder, innerEmptyBorder);
		CompoundBorder border = new CompoundBorder(outerEmptyBorder, innerBorder);
		return border;
	}

	private JLabel getNameLabel() {
		if (nameLabel == null) {
			nameLabel = new JLabel();
			nameLabel.setText("Nome");
		}
		return nameLabel;
	}

	private JTextField getNameTextField() {
		if (nameTextField == null) {
			nameTextField = new JTextField();
		}
		return nameTextField;
	}

	private JLabel getStudentNumberLabel() {
		if (studentNumberLabel == null) {
			studentNumberLabel = new JLabel();
			studentNumberLabel.setText("Matr�cula");
		}
		return studentNumberLabel;
	}

	private JTextField getStudentNumberTextField() {
		if (studentNumberTextField == null) {
			studentNumberTextField = new JTextField();
		}
		return studentNumberTextField;
	}

	private JLabel getTypeLabel() {
		if (typeLabel == null) {
			typeLabel = new JLabel();
			typeLabel.setText("Tipo");
		}
		return typeLabel;
	}

	private JComboBox<String> getTypeComboBox() {
		if (typeComboBox == null) {
			typeComboBox = new JComboBox<>();
			typeComboBox.addItem("Gradua��o");
			typeComboBox.addItem("P�s-gradua��o");
		}
		return typeComboBox;
	}

	private GridBagConstraints getNameLabelConstraints() {
		if (nameLabelConstraints == null) {
			nameLabelConstraints = new GridBagConstraints();
			nameLabelConstraints.gridx = 0;
			nameLabelConstraints.gridy = 0;
			nameLabelConstraints.anchor = GridBagConstraints.LINE_START;
			nameLabelConstraints.insets = new Insets(2, 2, 2, 5);
		}
		return nameLabelConstraints;
	}

	private GridBagConstraints getNameTextFieldConstraints() {
		if (nameTextFieldConstraints == null) {
			nameTextFieldConstraints = new GridBagConstraints();
			nameTextFieldConstraints.gridx = 1;
			nameTextFieldConstraints.gridy = 0;
			nameTextFieldConstraints.gridwidth = 3;
			nameTextFieldConstraints.fill = GridBagConstraints.HORIZONTAL;
			nameTextFieldConstraints.insets = new Insets(2, 2, 2, 2);
		}
		return nameTextFieldConstraints;
	}

	private GridBagConstraints getStudentNumberLabelConstraints() {
		if (studentNumberLabelConstraints == null) {
			studentNumberLabelConstraints = new GridBagConstraints();
			studentNumberLabelConstraints.gridx = 0;
			studentNumberLabelConstraints.gridy = 1;
			studentNumberLabelConstraints.anchor = GridBagConstraints.LINE_START;
			studentNumberLabelConstraints.insets = new Insets(2, 2, 2, 5);
		}
		return studentNumberLabelConstraints;
	}

	private GridBagConstraints getStudentNumberTextFieldConstraints() {
		if (studentNumberTextFieldConstraints == null) {
			studentNumberTextFieldConstraints = new GridBagConstraints();
			studentNumberTextFieldConstraints.gridx = 1;
			studentNumberTextFieldConstraints.gridy = 1;
			studentNumberTextFieldConstraints.ipadx = 100;
			studentNumberTextFieldConstraints.fill = GridBagConstraints.HORIZONTAL;
			studentNumberTextFieldConstraints.insets = new Insets(2, 2, 2, 2);
		}
		return studentNumberTextFieldConstraints;
	}

	private GridBagConstraints getTypeLabelConstraints() {
		if (typeLabelConstraints == null) {
			typeLabelConstraints = new GridBagConstraints();
			typeLabelConstraints.gridx = 2;
			typeLabelConstraints.gridy = 1;
			typeLabelConstraints.anchor = GridBagConstraints.LINE_START;
			typeLabelConstraints.insets = new Insets(2, 2, 2, 5);
		}
		return typeLabelConstraints;
	}

	private GridBagConstraints getTypeComboBoxConstraints() {
		if (typeComboBoxConstraints == null) {
			typeComboBoxConstraints = new GridBagConstraints();
			typeComboBoxConstraints.gridx = 3;
			typeComboBoxConstraints.gridy = 1;
			typeComboBoxConstraints.fill = GridBagConstraints.HORIZONTAL;
			typeComboBoxConstraints.insets = new Insets(2, 2, 2, 2);
		}
		return typeComboBoxConstraints;
	}
	
}



