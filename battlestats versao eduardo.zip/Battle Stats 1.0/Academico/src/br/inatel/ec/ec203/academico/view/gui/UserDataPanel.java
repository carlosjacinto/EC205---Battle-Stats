package br.inatel.ec.ec203.academico.view.gui;

import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import br.inatel.ec.ec203.academico.model.User;

public class UserDataPanel extends JPanel {

	private static final long serialVersionUID = -4561093184647753436L;

	private JLabel nameLabel;
	private JLabel passwordLabel;
	private JTextField nameTextField;
	private JPasswordField passwordField;
	
	public UserDataPanel() {
		super();

		initialize();
	}

	private void initialize() {
		setLayout(createGridLayout());
		setBorder(createBorder());
		
		add(getNameLabel());
		add(getNameTextField());
		add(getPasswordLabel());
		add(getPasswordField());
	}
	
	private Border createBorder() {
		TitledBorder titledBorder = new TitledBorder("Dados do usu�rio:");
		EmptyBorder outerEmptyBorder = new EmptyBorder(5, 5, 5, 5);
		EmptyBorder innerEmptyBorder = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder innerBorder = new CompoundBorder(titledBorder, innerEmptyBorder);
		CompoundBorder border = new CompoundBorder(outerEmptyBorder, innerBorder);
		return border;
	}

	private GridLayout createGridLayout() {
		GridLayout gridLayout = new GridLayout();
		gridLayout.setRows(2);
		gridLayout.setColumns(2);
		gridLayout.setHgap(5);
		gridLayout.setVgap(5);
		return gridLayout;
	}

	private JLabel getNameLabel() {
		if (nameLabel == null) {
			nameLabel = new JLabel();
			nameLabel.setText("Nome do usu�rio:");
		}
		return nameLabel;
	}

	private JLabel getPasswordLabel() {
		if (passwordLabel == null) {
			passwordLabel = new JLabel();
			passwordLabel.setText("Senha do usu�rio:");
		}
		return passwordLabel;
	}

	private JTextField getNameTextField() {
		if (nameTextField == null) {
			nameTextField = new JTextField();
		}
		return nameTextField;
	}

	private JPasswordField getPasswordField() {
		if (passwordField == null) {
			passwordField = new JPasswordField();
		}
		return passwordField;
	}

	public User getUser() {
		String name = getNameTextField().getText();
		String password = new String(getPasswordField().getPassword());
		User user = new User();
		user.setName(name);
		user.setPassword(password);
		return user;
	}
	
}






