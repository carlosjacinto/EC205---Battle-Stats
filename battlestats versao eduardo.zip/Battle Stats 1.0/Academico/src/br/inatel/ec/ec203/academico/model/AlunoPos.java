package br.inatel.ec.ec203.academico.model;

import java.util.ArrayList;

import br.inatel.ec.ec203.academico.dao.DAOException;

public class AlunoPos extends Aluno {

	private ArrayList<Character> conceitos = new ArrayList<>();

	public AlunoPos(int matricula) {
		super(matricula);
	}

	public AlunoPos(int matricula, String nome) {
		super(matricula, nome);
	}
	
	public AlunoPos(String csv) throws DAOException {
		super(csv);
		String[] parts = csv.split(",");
		for (int i = 3; i < parts.length; i++) {
			String conceitoAsString = parts[i];
			if (conceitoAsString.isEmpty()) {
				throw new DAOException("Dado de aluno inv�lido.");
			}
			char conceito = conceitoAsString.charAt(0);
			conceitos.add(conceito);
		}
	}

	public void addConceito(char conceito) {
		conceitos.add(conceito);
	}

	public char conceitoGeral() {
		char conceitoGeral;
		if (conceitos.isEmpty()) {
			conceitoGeral = 'A';
		} else {
			conceitoGeral = calcularConceitoGeral();
		}
		return conceitoGeral;
	}

	@Override
	public boolean aprovado() {
		boolean result;
		switch (conceitoGeral()) {
		case 'A':
		case 'B':
		case 'C':
			result = true;
			break;
		default:
			result = false;
			break;
		}
		return result;
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append(super.toString());
		result.append("Conceitos:\n");
		for (char conceito : conceitos) {
			result.append("\t").append(conceito).append("\n");
		}
		result.append("Conceito geral: ").append(conceitoGeral()).append("\n");
		return result.toString();
	}

	@Override
	public String toCSV() {
		StringBuilder result = new StringBuilder();
		result.append("2,").append(super.toCSV());
		for (char conceito : conceitos) {
			result.append(",").append(conceito);
		}
		return result.toString();
	}

	private char calcularConceitoGeral() {
		if (conceitos.isEmpty()) return 'I';
		float conceitoGeralAsNota = 0;
		for (char conceito : conceitos) {
			switch (conceito) {
			case 'A':
			case 'a':
				conceitoGeralAsNota += 100;
				break;
			case 'B':
			case 'b':
				conceitoGeralAsNota += 80;
				break;
			case 'C':
			case 'c':
				conceitoGeralAsNota += 60;
				break;
			default:
				conceitoGeralAsNota += 0;
				break;
			}
		}
		conceitoGeralAsNota /= conceitos.size();
		return converterNotaParaConceito(conceitoGeralAsNota);
	}

	private char converterNotaParaConceito(float nota) {
		char conceito;
		if (nota >= 90) {
			conceito = 'A';
		} else if (nota >= 70) {
			conceito = 'B';
		} else if (nota >= 50) {
			conceito = 'C';
		} else {
			conceito = 'I';
		}
		return conceito;
	}
	
}
