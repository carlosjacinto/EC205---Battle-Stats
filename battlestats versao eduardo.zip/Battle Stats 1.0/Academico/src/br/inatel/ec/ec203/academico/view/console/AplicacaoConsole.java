package br.inatel.ec.ec203.academico.view.console;

import br.inatel.ec.ec203.academico.dao.AlunoDAO;
import br.inatel.ec.ec203.academico.dao.DAOException;
import br.inatel.ec.ec203.academico.model.Aluno;
import br.inatel.ec.ec203.academico.model.AlunoGraduacao;
import br.inatel.ec.ec203.academico.model.AlunoPos;

public class AplicacaoConsole {

	public void iniciaAplicacao() {
		int op = -1;
		while (op != 5) {
			System.out.println("\n\nCadastro Acad�mico:");
			System.out.println("==================");
			System.out.println("\nMenu Principal:");
			System.out.println("1) Adicionar aluno");
			System.out.println("2) Listar alunos");
			System.out.println("3) Apresentar situa��es");
			System.out.println("4) Alterar aluno");
			System.out.println("5) Sair");
			op = LeituraConsole.lerInteiro("> ");
			switch (op) {
			case 1:
				adicionarAluno();
				break;
			case 2:
				listarAlunos();
				break;
			case 3:
				apresentarSituacoes();
				break;
			case 4:
				alterarAluno();
				break;
			case 5:
				System.out.println("Saindo da aplica��o...");
				break;
			default:
				System.err.println("Op��o inv�ida!");
				break;
			}
			LeituraConsole.waitOneSecond();
		}
	}

	private void alterarAluno() {
		AlunoDAO dao = new AlunoDAO();
		int matricula = LeituraConsole.lerInteiro("Matr�cula do aluno a ser alterado: ");
		try {
			Aluno aluno = dao.buscarPorMatricula(matricula);
			System.out.println("Aluno a ser alterado: " + aluno.getNome());
			if (aluno instanceof AlunoGraduacao) {
				AlunoGraduacao graduacao = (AlunoGraduacao) aluno;
				alterarAlunoGraduacao(graduacao);
			} else if (aluno instanceof AlunoPos) {
				AlunoPos pos = (AlunoPos) aluno;
				alterarAlunoPos(pos);
			}
			dao.alterar(aluno);
		} catch (DAOException e) {
			System.err.println(e.getMessage());
		}
	}

	private void alterarAlunoGraduacao(AlunoGraduacao graduacao) {
		int quantNotas = LeituraConsole.lerInteiro("Quantas notas deseja adicionar? ");
		for (int i = 0; i < quantNotas; i++) {
			float nota = LeituraConsole.lerFloat("Nota " + (i + 1) + ": ");
			graduacao.addNota(nota);
		}
	}

	private void alterarAlunoPos(AlunoPos pos) {
		int quantConceitos = LeituraConsole.lerInteiro("Quantos conceitos deseja adicionar? ");
		for (int i = 0; i < quantConceitos; i++) {
			char conceito = LeituraConsole.lerChar("Conceito " + (i + 1) + ": ");
			pos.addConceito(conceito);
		}
	}

	private void adicionarAluno() {
		System.out.println("\nAdicionar Aluno:");
		System.out.println("1) Aluno de gradua��o");
		System.out.println("2) Aluno de p�s-gradua��o");
		System.out.println("3) Volar");
		int op = LeituraConsole.lerInteiro("> ");
		switch (op) {
		case 1:
			adicionarAlunoGraduacao();
			break;
		case 2:
			adicionarAlunoPos();
			break;
		case 3:
			System.out.println("Voltando ao menu principal...");
			break;
		default:
			System.err.println("Op��o inv�lida!");
			break;
		}
	}

	private void adicionarAlunoGraduacao() {
		AlunoDAO dao = new AlunoDAO();

		AlunoGraduacao alunoGraduacao = new AlunoGraduacao(lerMatricula());
		lerDadosAluno(alunoGraduacao);

		int quantNotas = LeituraConsole.lerInteiro("Quantas notas deseja adicionar? ");
		for (int i = 0; i < quantNotas; i++) {
			float nota = LeituraConsole.lerFloat("Nota " + (i + 1) + ": ");
			alunoGraduacao.addNota(nota);
		}

		try {
			dao.inserir(alunoGraduacao);
		} catch (DAOException e) {
			System.err.println(e.getMessage());
		}
	}

	private void adicionarAlunoPos() {
		AlunoDAO dao = new AlunoDAO();

		AlunoPos alunoPos = new AlunoPos(lerMatricula());
		lerDadosAluno(alunoPos);
		lerDadosAlunoPos(alunoPos);

		try {
			dao.inserir(alunoPos);
		} catch (DAOException e) {
			System.err.println(e.getMessage());
		}
	}

	private void lerDadosAlunoPos(AlunoPos alunoPos) {
		int quantConceitos = LeituraConsole.lerInteiro("Quantos conceitos deseja adicionar? ");
		for (int i = 0; i < quantConceitos; i++) {
			char conceito = LeituraConsole.lerChar("Conceito " + (i + 1) + ": ");
			alunoPos.addConceito(conceito);
		}
	}

	private int lerMatricula() {
		int matricula = LeituraConsole.lerInteiro("Matr�cula: ");
		return matricula;
	}

	private void lerDadosAluno(Aluno aluno) {
		String nome = LeituraConsole.lerString("Nome: ");
		int idade = LeituraConsole.lerInteiro("Idade: ");

		aluno.setNome(nome);
		aluno.setIdade(idade);
	}

	private void listarAlunos() {
		AlunoDAO dao = new AlunoDAO();
		System.out.println("\n\nLista de alunos:\n");
		try {
			for (Aluno aluno : dao.listar()) {
				System.out.println(aluno);
			}
		} catch (DAOException e) {
			System.err.println(e.getMessage());
		}
	}

	private void apresentarSituacoes() {
		AlunoDAO dao = new AlunoDAO();
		System.out.println("\n\nSitua��es dos alunos:\n");
		try {
			for (Aluno aluno : dao.listar()) {
				String situacao = aluno.aprovado() ? "Aprovado" : "Reprovado";
				String mensagem = "Nome do aluno: " + aluno.getNome();
				mensagem += " - Situa��o: " + situacao;
				System.out.println(mensagem);
			}
		} catch (DAOException e) {
			System.err.println(e.getMessage());
		}
	}

}
