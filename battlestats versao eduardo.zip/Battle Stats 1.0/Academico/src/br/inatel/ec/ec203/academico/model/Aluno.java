package br.inatel.ec.ec203.academico.model;

import br.inatel.ec.ec203.academico.dao.DAOException;

public abstract class Aluno {

	private String nome;
	private int matricula;
	private int idade;

	public Aluno(int matricula) {
		this.matricula = matricula;
	}

	public Aluno(int matricula, String nome) {
		this(matricula);
		this.nome = nome;
	}
	
	public Aluno(String csv) throws DAOException {
		String[] parts = csv.split(",");
		if (parts.length < 3) {
			throw new DAOException("Dado de aluno inv�lido.");
		}
		nome = parts[0];
		try {
			matricula = Integer.parseInt(parts[1]);
			idade = Integer.parseInt(parts[2]);
		} catch (NumberFormatException e) {
			throw new DAOException("Dado de aluno inv�lido.", e);
		}
	}

	public abstract boolean aprovado();

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public int getMatricula() {
		return matricula;
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append("Dados do aluno:\n");
		result.append("Nome: ").append(nome).append("\n");
		result.append("Matr�cula: ").append(matricula).append("\n");
		result.append("Idade: ").append(idade).append("\n");
		return result.toString();
	}

	public String toCSV() {
		StringBuilder result = new StringBuilder();
		result.append(nome);
		result.append(",").append(matricula);
		result.append(",").append(idade);
		return result.toString();
	}

}
