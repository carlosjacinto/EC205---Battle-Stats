package br.inatel.ec.ec203.academico.main;

import br.inatel.ec.ec203.academico.view.gui.LoginFrame;

public class Runner {

	public static void main(String[] args) {
		new LoginFrame().setVisible(true);
//		new AplicacaoConsole().iniciaAplicacao();
	}

}
