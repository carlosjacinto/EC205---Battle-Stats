package br.inatel.ec.ec203.academico.view.console;

import java.util.InputMismatchException;
import java.util.Scanner;

public class LeituraConsole {

	private static Scanner scanner = new Scanner(System.in);

	public static int lerInteiro(String mensagem) {
		Integer result = null;
		while (result == null) {
			try {
				System.out.print(mensagem);
				result = scanner.nextInt();
			} catch (InputMismatchException e) {
				scanner.nextLine();
				System.err.println("O valor digitado n�o � um inteiro v�lido!");
				waitOneSecond();
			}
		}
		return result;
	}

	public static float lerFloat(String mensagem) {
		Float result = null;
		while (result == null) {
			try {
				System.out.print(mensagem);
				result = scanner.nextFloat();
			} catch (InputMismatchException e) {
				scanner.nextLine();
				System.err.println("O valor digitado n�o � um float v�lido!");
				waitOneSecond();
			}
		}
		return result;
	}

	public static String lerString(String mensagem) {
		System.out.print(mensagem);
		return scanner.next() + scanner.nextLine();
	}

	public static char lerChar(String mensagem) {
		return lerString(mensagem).charAt(0);
	}

	public static void waitOneSecond() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
		}
	}

}
