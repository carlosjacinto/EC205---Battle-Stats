package br.inatel.ec.ec203.academico.view.gui;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import br.inatel.ec.ec203.academico.model.User;
import br.inatel.ec.ec203.academico.view.gui.components.ButtonsListener;
import br.inatel.ec.ec203.academico.view.gui.components.ButtonsPanel;

public class LoginFrame extends JFrame {

	private static final long serialVersionUID = 2014219427044614392L;
	
	private UserDataPanel userDataPanel;
	private ButtonsPanel buttonsPanel;
	
	public LoginFrame() {
		super("Login");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		initialize();
		
		pack();
		setLocationRelativeTo(null);
		setResizable(false);
	}

	private void initialize() {
		add(getUserDataPanel(), BorderLayout.CENTER);
		add(getButtonsPanel(), BorderLayout.PAGE_END);
	}

	private UserDataPanel getUserDataPanel() {
		if (userDataPanel == null) {
			userDataPanel = new UserDataPanel();
		}
		return userDataPanel;
	}
	
	private ButtonsPanel getButtonsPanel() {
		if (buttonsPanel == null) {
			buttonsPanel = new ButtonsPanel();
			buttonsPanel.addButtonsListener(new ButtonsListener() {
				@Override
				public void okPerformed() {
					okClicked();
				}
				@Override
				public void cancelPerformed() {
					cancelClicked();
				}
			});
		}
		return buttonsPanel;
	}

	protected void okClicked() {
		User user = getUserDataPanel().getUser();
		if (user != null &&
				"admin".equals(user.getName()) &&
				"1234".equals(user.getPassword())) {
			new StudentFrame().setVisible(true);
			dispose();
		} else {
			JOptionPane.showMessageDialog(this, "Usu�rio ou senha incorretos!",
					"Erro", JOptionPane.ERROR_MESSAGE);
		}
	}

	protected void cancelClicked() {
		int option = JOptionPane.showConfirmDialog(this, "Deseja sair da aplica��o?",
				"Confirma��o", JOptionPane.YES_NO_OPTION);
		if (option == JOptionPane.YES_OPTION) {
			dispose();
			System.exit(0);
		}
	}
	
}






