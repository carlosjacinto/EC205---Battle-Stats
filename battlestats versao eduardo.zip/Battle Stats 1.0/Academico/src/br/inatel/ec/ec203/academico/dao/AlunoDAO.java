package br.inatel.ec.ec203.academico.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import br.inatel.ec.ec203.academico.model.Aluno;
import br.inatel.ec.ec203.academico.model.AlunoGraduacao;
import br.inatel.ec.ec203.academico.model.AlunoPos;

public class AlunoDAO {

	private static final String FILE_NAME_PREFIX = "alunos";
	private static final String FILE_NAME = FILE_NAME_PREFIX + ".csv";
	private static final String BACKUP_FILE_NAME = FILE_NAME_PREFIX + ".bak";
	
	public void inserir(Aluno aluno) throws DAOException {
		PrintStream filePrintStream = null;
		try {
			File file = new File(FILE_NAME);
			if (!file.exists()) {
				file.createNewFile();
			}
			FileOutputStream fos = new FileOutputStream(file, true);
			filePrintStream = new PrintStream(fos);
			filePrintStream.println(aluno.toCSV());
		} catch (FileNotFoundException e) {
			throw new DAOException("O aluno n�o pode ser salvo pois o arquivo n�o existe.", e);
		} catch (IOException e) {
			String mensagem = "Erro ao salvar aluno no arquivo: " + e.getMessage();
			throw new DAOException(mensagem, e);
		} finally {
			if (filePrintStream != null) {
				filePrintStream.close();
			}
		}
	}
	
	public Aluno buscarPorMatricula(int matricula) throws DAOException {
		Aluno result = null;
		for (Aluno aluno: listar()) {
			if (aluno.getMatricula() == matricula) {
				result = aluno;
				break;
			}
		}
		if (result == null) {
			throw new DAOException("Aluno n�o encontrado!");
		}
		return result;
	}
	
	public void alterar(Aluno aluno) throws DAOException {
		// Alterar o aluno no aquivo, seguindo os seguintes passos:
		// 1 - Listar todos os alunos do arquivo
		List<Aluno> alunos = listar();
		// 2 - Mover o aquivo original para um arquivo de backup
		backupFile();
		// 3 - Substituir na lista aquele aluno cuja a matr�cula for a mesma do aluno
		//     passado como par�metro
		substituirAluno(aluno, alunos);
		// 4 - Salvar a lista de alunos novamente no arquivo
		salvarAlunos(alunos);
	}
	
	private void backupFile() throws DAOException {
		try {
			File file = new File(FILE_NAME);
			if (!file.exists()) {
				file.createNewFile();
			}
			File backupFile = new File(BACKUP_FILE_NAME);
			if (backupFile.exists()) {
				backupFile.delete();
			}
			boolean success = file.renameTo(backupFile);
			if (!success) {
				throw new DAOException("N�o foi poss�vel criar o arquivo de backup!");
			}
		} catch (IOException e) {
			String mensagem = "N�o foi poss�vel criar o arquivo de backup: " + e.getMessage();
			throw new DAOException(mensagem, e);
		}
	}

	private void substituirAluno(Aluno aluno, List<Aluno> alunos) throws DAOException {
		int posicaoParaSubstituir = -1;
		for (int i = 0; i < alunos.size(); i++) {
			if (alunos.get(i).getMatricula() == aluno.getMatricula()) {
				posicaoParaSubstituir = i;
				break;
			}
		}
		if (posicaoParaSubstituir == -1) {
			throw new DAOException("N�o foi poss�vel encontrar o aluno para substituir!");
		}
		alunos.set(posicaoParaSubstituir, aluno);
	}

	private void salvarAlunos(List<Aluno> alunos) throws DAOException {
		PrintStream filePrintStream = null;
		try {
			File file = new File(FILE_NAME);
			if (!file.exists()) {
				file.createNewFile();
			}
			FileOutputStream fos = new FileOutputStream(file, false);
			filePrintStream = new PrintStream(fos);
			for (Aluno aluno: alunos) {
				filePrintStream.println(aluno.toCSV());
			}
		} catch (FileNotFoundException e) {
			throw new DAOException("O aluno n�o pode ser salvo pois o arquivo n�o existe.", e);
		} catch (IOException e) {
			String mensagem = "Erro ao salvar aluno no arquivo: " + e.getMessage();
			throw new DAOException(mensagem, e);
		} finally {
			if (filePrintStream != null) {
				filePrintStream.close();
			}
		}
	}

	public List<Aluno> listar() throws DAOException {
		ArrayList<Aluno> alunos = new ArrayList<>();
		Scanner fileScanner = null;
		try {
			File file = new File(FILE_NAME);
			if (!file.exists()) {
				file.createNewFile();
			}
			fileScanner = new Scanner(file);
			while (fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				Aluno aluno = processaLinha(line);
				alunos.add(aluno);
			}
		} catch (IOException e) {
			String mensagem = "Erro ao buscar alunos no arquivo: " + e.getMessage();
			throw new DAOException(mensagem, e);
		} finally {
			if (fileScanner != null) {
				fileScanner.close();
			}
		}
		return alunos;
	}

	private Aluno processaLinha(String line) throws DAOException {
		int indexOfComma = line.indexOf(',');
		if (indexOfComma == -1) {
			throw new DAOException("Erro ao parsear dados do aluno.");
		}
		String tipo = line.substring(0, indexOfComma);
		String csv = line.substring(indexOfComma + 1);
		if ("1".equals(tipo)) {
			return new AlunoGraduacao(csv);
		} else if ("2".equals(tipo)) {
			return new AlunoPos(csv);
		} else {
			throw new DAOException("Tipo de aluno desconhecido.");
		}
	}

}
