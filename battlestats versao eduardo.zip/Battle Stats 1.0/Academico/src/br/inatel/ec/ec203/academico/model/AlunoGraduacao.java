package br.inatel.ec.ec203.academico.model;

import java.util.ArrayList;

import br.inatel.ec.ec203.academico.dao.DAOException;

public class AlunoGraduacao extends Aluno {

	private ArrayList<Float> notas = new ArrayList<>();

	public AlunoGraduacao(int matricula) {
		super(matricula);
	}

	public AlunoGraduacao(int matricula, String nome) {
		super(matricula, nome);
	}
	
	public AlunoGraduacao(String csv) throws DAOException {
		super(csv);
		String[] parts = csv.split(",");
		try {
			for (int i = 3; i < parts.length; i++) {
				float nota = Float.parseFloat(parts[i]);
				notas.add(nota);
			}
		} catch (NumberFormatException e) {
			throw new DAOException("Dado de aluno inv�lido.", e);
		}
	}

	public void addNota(float nota) {
		notas.add(nota);
	}

	public float mediaGeral() {
		if (notas.isEmpty()) return 0;
		float soma = 0;
		for (float nota : notas) {
			soma += nota;
		}
		return soma / notas.size();
	}

	@Override
	public boolean aprovado() {
		boolean result;
		if (mediaGeral() > 59.9) {
			result = true;
		} else {
			result = false;
		}
		return result;
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append(super.toString());
		result.append("Notas:\n");
		for (float nota : notas) {
			result.append("\t").append(nota).append("\n");
		}
		result.append("M�dia geral: ").append(mediaGeral()).append("\n");
		return result.toString();
	}

	@Override
	public String toCSV() {
		StringBuilder result = new StringBuilder();
		result.append("1,").append(super.toCSV());
		for (float nota : notas) {
			result.append(",").append(nota);
		}
		return result.toString();
	}

}
