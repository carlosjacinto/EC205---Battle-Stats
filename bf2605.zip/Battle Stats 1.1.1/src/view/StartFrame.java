package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class StartFrame extends JFrame implements ActionListener {
	private Clip clip;

	private static final long serialVersionUID = 8490160171069157379L;

	private JButton startButton = new JButton("START");

	public StartFrame() {

		setTitle("BATTLE STATS 1.1");
		setSize(1366, 768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		getIniciarMusicaButton();
		
		startButton.setBackground(new Color(70, 150, 255));
		startButton.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		startButton.setForeground(Color.WHITE);
		startButton.addActionListener(this);

		setLayout(new GridBagLayout());
		JLabel background = new JLabel(new ImageIcon("Media/StartCover.jpg"));
		add(background);
		background.setLayout(new GridBagLayout());
		background.add(startButton);

		refresh();
	}

	private void refresh() {
		setSize(1360, 760);
		setSize(1366, 768);
	}

	public void getIniciarMusicaButton() {

		try {
			File soundFile = new File("Media/Theme.wav");
			AudioInputStream sound = AudioSystem.getAudioInputStream(soundFile);
			DataLine.Info info = new DataLine.Info(Clip.class, sound.getFormat());
			clip = (Clip) AudioSystem.getLine(info);
			clip.open(sound);
			clip.start();
			clip.loop(100000000);
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException ev) {
			JOptionPane.showMessageDialog(null, "Deu ruim a musica!");
		}
	}


	public void actionPerformed(ActionEvent e) {
		new LoginFrame();
		dispose();
	}

}
