package view;

public class EditarVeiculoFrame {

}
