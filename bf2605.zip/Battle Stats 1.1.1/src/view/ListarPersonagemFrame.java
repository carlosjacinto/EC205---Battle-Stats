package view;

public class ListarPersonagemFrame {

}
