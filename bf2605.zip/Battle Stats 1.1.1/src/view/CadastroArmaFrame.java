package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import control.ArmaDAO;
import model.Arma;

public class CadastroArmaFrame extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7180513158489494234L;

	private String[] tipos = { "Assalto", "ADP", "M.L.", "Rifle de precis�o", "Carabina", "Escopeta", "DMR", "Pistola" };
	JComboBox<String> tiposArma = new JComboBox<>(tipos);

	JSlider danoSlider = new JSlider(0,100);
	JSlider alcanceSlider = new JSlider(0,100);
	JSlider precisaoSlider = new JSlider(0,100);
	JSlider tiroSlider = new JSlider(0,100);
	JSlider estabilidadeSlider = new JSlider(0,100);
	JSlider cadenciaSlider = new JSlider(1,1000);
	JSlider capacidadeSlider = new JSlider(1,500);
	JTextField nomeTxt = new JTextField(40);
	JTextArea nomeTxtAr = new JTextArea("Nome", 1, 10);
	JTextArea danoTxtAr = new JTextArea("Dano", 1, 10);
	JTextArea alcanceTxtAr = new JTextArea("Alcance", 1, 10);
	JTextArea precisaoTxtAr = new JTextArea("Precis�o", 1, 10);
	JTextArea tiroSemVisadaTxtAr = new JTextArea("Tiro sem visada", 1, 10);
	JTextArea estabilidadeTxtAr = new JTextArea("Establilidade", 1, 10);
	JTextArea cadenciaTxtAr = new JTextArea("Cad�ncia", 1, 10);
	JTextArea capacidadeTxtAr = new JTextArea("Capacidade do pente", 1, 10);

	JButton okBt = new JButton("Confirmar");
	JButton cancelaBt = new JButton("Cancelar");

	JCheckBox check = new JCheckBox("Acess�rio");

	JPanel jp = new JPanel(new GridLayout(0, 1));
	JLabel background=new JLabel(new ImageIcon("Media/Default.jpg"));
	
	public CadastroArmaFrame() {
		
		setTitle("Main Menu");
		setSize(1366,768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setLayout(new BorderLayout());
		
		config();
		adicionar();
		refresh();

	}
	
	private void refresh(){
		setSize(1360,760);
		setSize(1366,768);
	}
	
	private void config(){
		
		danoSlider.setMinorTickSpacing(1);
		danoSlider.setMajorTickSpacing(10);
		danoSlider.setPaintTicks(true);
		danoSlider.setPaintLabels(true);
		alcanceSlider.setMinorTickSpacing(1);
		alcanceSlider.setMajorTickSpacing(10);
		alcanceSlider.setPaintTicks(true);
		alcanceSlider.setPaintLabels(true);
		precisaoSlider.setMinorTickSpacing(1);
		precisaoSlider.setMajorTickSpacing(10);
		precisaoSlider.setPaintTicks(true);
		precisaoSlider.setPaintLabels(true);
		tiroSlider.setMinorTickSpacing(1);
		tiroSlider.setMajorTickSpacing(10);
		tiroSlider.setPaintTicks(true);
		tiroSlider.setPaintLabels(true);
		estabilidadeSlider.setMinorTickSpacing(1);
		estabilidadeSlider.setMajorTickSpacing(10);
		estabilidadeSlider.setPaintTicks(true);
		estabilidadeSlider.setPaintLabels(true);
		cadenciaSlider.setMinorTickSpacing(10);
		cadenciaSlider.setMajorTickSpacing(100);
		cadenciaSlider.setPaintTicks(true);
		cadenciaSlider.setPaintLabels(true);
		capacidadeSlider.setMinorTickSpacing(5);
		capacidadeSlider.setMajorTickSpacing(50);
		capacidadeSlider.setPaintTicks(true);
		capacidadeSlider.setPaintLabels(true);
		tiposArma.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		tiposArma.setBackground(new Color(100, 100, 100));
		tiposArma.setForeground(Color.WHITE);
		nomeTxtAr.setEditable(false);
		nomeTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		nomeTxtAr.setBackground(new Color(0, 0, 0));
		nomeTxtAr.setForeground(Color.WHITE);
		danoTxtAr.setEditable(false);
		danoTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		danoTxtAr.setBackground(new Color(0, 0, 0));
		danoTxtAr.setForeground(Color.WHITE);
		alcanceTxtAr.setEditable(false);
		alcanceTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		alcanceTxtAr.setBackground(new Color(0, 0, 0));
		alcanceTxtAr.setForeground(Color.WHITE);
		precisaoTxtAr.setEditable(false);
		precisaoTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		precisaoTxtAr.setBackground(new Color(0, 0, 0));
		precisaoTxtAr.setForeground(Color.WHITE);
		tiroSemVisadaTxtAr.setEditable(false);
		tiroSemVisadaTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		tiroSemVisadaTxtAr.setBackground(new Color(0, 0, 0));
		tiroSemVisadaTxtAr.setForeground(Color.WHITE);
		estabilidadeTxtAr.setEditable(false);
		estabilidadeTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		estabilidadeTxtAr.setBackground(new Color(0, 0, 0));
		estabilidadeTxtAr.setForeground(Color.WHITE);
		cadenciaTxtAr.setEditable(false);
		cadenciaTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cadenciaTxtAr.setBackground(new Color(0, 0, 0));
		cadenciaTxtAr.setForeground(Color.WHITE);
		capacidadeTxtAr.setEditable(false);
		capacidadeTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		capacidadeTxtAr.setBackground(new Color(0, 0, 0));
		capacidadeTxtAr.setForeground(Color.WHITE);
		check.addActionListener(this);
		check.setBackground(new Color(255, 0, 0));
		check.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		check.setForeground(Color.WHITE);
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		okBt.setBackground(new Color(255, 0, 0));
		okBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		okBt.setForeground(Color.WHITE);
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		cancelaBt.setBackground(new Color(250, 95, 0));
		cancelaBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cancelaBt.setForeground(Color.WHITE);
	}
	
	private void adicionar(){
		add(background);
		background.setLayout(new GridBagLayout());
		jp.setVisible(true);
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tiposArma);
		jp.add(check);
		jp.add(danoTxtAr);
		jp.add(danoSlider);
		jp.add(alcanceTxtAr);
		jp.add(alcanceSlider);
		jp.add(precisaoTxtAr);
		jp.add(precisaoSlider);
		jp.add(tiroSemVisadaTxtAr);
		jp.add(tiroSlider);
		jp.add(estabilidadeTxtAr);
		jp.add(estabilidadeSlider);
		jp.add(cadenciaTxtAr);
		jp.add(cadenciaSlider);
		jp.add(capacidadeTxtAr);
		jp.add(capacidadeSlider);
		jp.add(okBt);
		jp.add(cancelaBt);
		background.add(jp);
	}

	boolean temCampoEmBranco() {
		if (nomeTxt.getText().equals(""))
			return true;
		return false;
	}

	public void actionPerformed(ActionEvent e) {

		if ("confirma".equals(e.getActionCommand())) {
			Arma novaArma = new Arma();
			ArmaDAO armaDAO = new ArmaDAO();
			
			if (!check.isSelected()) {
				if (temCampoEmBranco()) {
					JOptionPane.showMessageDialog(new JFrame(), "Preencha todos os campos", "Campos em branco",
							JOptionPane.WARNING_MESSAGE);
					return;
				}

				novaArma.setNome(nomeTxt.getText());
				novaArma.setTipo(tiposArma.getSelectedItem().toString());
				novaArma.setDano(Integer.parseInt(danoSlider.getName()));
				novaArma.setAcessorio(0);
				novaArma.setAlcance(Integer.parseInt(alcanceSlider.getName()));
				novaArma.setPrecisao(Integer.parseInt(precisaoSlider.getName()));
				novaArma.setTiroSemVisada(Integer.parseInt(tiroSlider.getName()));
				novaArma.setCadencia(Integer.parseInt(cadenciaSlider.getName()));
				novaArma.setCapacidadeDoPente(Integer.parseInt(cadenciaSlider.getName()));
				novaArma.setEstabilidade(Integer.parseInt(estabilidadeSlider.getName()));
			} 
			
			else{
				if(nomeTxt.getText().equals("")){
					JOptionPane.showMessageDialog(new JFrame(), "Preencha todos os campos", "Campos em branco",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				novaArma.setNome(nomeTxt.getText());
				novaArma.setTipo(tiposArma.getSelectedItem().toString());
				novaArma.setAcessorio(1);
			}
				

			if ((armaDAO.buscarArma(novaArma.getNome()) != null)) {
				JOptionPane.showMessageDialog(new JFrame(), "Arma j� cadastrada no sistema!", "Erro!",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			armaDAO.gravarArma(novaArma);
			JOptionPane.showMessageDialog(new JFrame(), "Arma cadastrada no sistema!", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
			dispose();
		}
		
		if ("cancela".equals(e.getActionCommand())) {
			new MainMenuAdmFrame();
			dispose();
			return;
		}

		if (check.isSelected()) {
			danoSlider.setVisible(false);
			danoTxtAr.setVisible(false);
			alcanceSlider.setVisible(false);
			alcanceTxtAr.setVisible(false);
			precisaoSlider.setVisible(false);
			precisaoTxtAr.setVisible(false);
			tiroSlider.setVisible(false);
			tiroSemVisadaTxtAr.setVisible(false);
			estabilidadeSlider.setVisible(false);
			estabilidadeTxtAr.setVisible(false);
			cadenciaSlider.setVisible(false);
			cadenciaTxtAr.setVisible(false);
			cadenciaSlider.setVisible(false);
			capacidadeTxtAr.setVisible(false);
			return;
		} else {
			danoSlider.setVisible(true);
			danoTxtAr.setVisible(true);
			alcanceSlider.setVisible(true);
			alcanceTxtAr.setVisible(true);
			precisaoSlider.setVisible(true);
			precisaoTxtAr.setVisible(true);
			tiroSlider.setVisible(true);
			tiroSemVisadaTxtAr.setVisible(true);
			estabilidadeSlider.setVisible(true);
			estabilidadeTxtAr.setVisible(true);
			cadenciaSlider.setVisible(true);
			cadenciaTxtAr.setVisible(true);
			capacidadeSlider.setVisible(true);
			capacidadeTxtAr.setVisible(true);
		}

	}
public static void main(String[] args) {
	new CadastroArmaFrame();
}
}
