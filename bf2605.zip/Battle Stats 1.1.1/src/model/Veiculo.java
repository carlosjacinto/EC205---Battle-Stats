package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import control.DataBase;

public class Veiculo {
	DataBase bd = new DataBase();
	Connection conex = bd.Conectar();

	private String tipo;
	private String nome;
	private int possuiArmamento;
	private String armaPrimaria = "";
	private String armaSecundaria = "";

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getArmaPrimaria() {
		return armaPrimaria;
	}

	public void setArmaPrimaria(String armaPrimaria) {
		this.armaPrimaria = armaPrimaria;
	}

	public String getArmaSecundaria() {
		return armaSecundaria;
	}

	public void setArmaSecundaria(String armaSecundaria) {
		this.armaSecundaria = armaSecundaria;
	}

	public int isPossuiArmamento() {
		return possuiArmamento;
	}

	public void setPossuiArmamento(int possuiArmamento) {
		this.possuiArmamento = possuiArmamento;
	}

	

	public void listarVeiculo() {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM veiculo";
			ResultSet rs = stmt.executeQuery(SQL);
			int i = 0;
			while (rs.next()) {
				i = 1;
				System.out.println("// Listar Veiculo //\n\nNome: " + rs.getString("nome"));
				System.out.println("\nTipo: " + rs.getString("tipo"));
				if (rs.getInt("possuiArmamento") == 1) {
					System.out.println("\nPossui Armamento: Sim");
					System.out.println("\nArma Primaria: " + rs.getString("armaPrimaria"));

					System.out.println("\nArma Secundaria: " + rs.getString("armaSecundaria") + "\n\n");
				} else
					System.out.println("\nPossui Armamento: N�o\n\n");

			}
			if (i == 0) {
				System.out.println("N�o existe dados para ser mostrados!!!");
			}

		} catch (java.lang.Exception ex) {
			System.out.println("Erro de consulta ao banco!");
			ex.printStackTrace();
		} finally {
			bd.Desconectar(conex);
		}

	}

	

	public boolean excluirVeiculo(String snome) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute("DELETE FROM veiculo WHERE nome LIKE '" + snome + "' ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}
	}

	public void editarVeiculo(Veiculo v, String snome) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();

			stmt.execute("UPDATE Veiculo SET nome='" + v.nome + "', tipo='" + v.tipo + "', possuiArmamento='"
					+ v.possuiArmamento + "', ArmaPrimaria='" + v.armaPrimaria + "', ArmaSecundaria='"
					+ v.armaSecundaria + "'  WHERE nome='" + snome + "' ");

			System.out.println("Altera��o feita com sucesso!!!");
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
		} finally {
			bd.Desconectar(conex);
		}
	}

}
