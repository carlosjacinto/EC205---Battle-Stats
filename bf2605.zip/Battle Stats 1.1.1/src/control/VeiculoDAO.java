package control;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Veiculo;

public class VeiculoDAO {
	
	DataBase bd = new DataBase();
	Connection conex = bd.Conectar();
	
	public boolean gravarVeiculo(Veiculo v) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute("INSERT INTO Veiculo(nome, tipo, possuiArmamento, armaPrimaria, armaSecundaria)VALUES ('"
					+ v.getNome() + "','" + v.getTipo() + "','" + v.isPossuiArmamento() + "','" + v.getArmaPrimaria() + "','"
					+ v.getArmaSecundaria() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}

	}
	
	public ResultSet buscarVeiculo(String snome) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM veiculo";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nome");

				if (snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	
	public ArrayList<String> buscaVeiculo(){		
		conex = bd.Conectar();
		
		try {
			ArrayList<String> selVeiculo = new ArrayList<>();
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM veiculo ORDER BY nome";
			ResultSet rs = stmt.executeQuery(SQL);
			
			
			while (rs.next()) {
				String nome = rs.getString("nome");	
				selVeiculo.add(nome);
				
			}
			rs.close();
			stmt.close();
			return selVeiculo;

		} catch (java.lang.Exception ex) {
			System.out.println("erro conexao");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
		
		
	}
}
