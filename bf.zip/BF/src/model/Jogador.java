package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bancodedados.Banco;

public class Jogador {
	Banco bd = new Banco();
	Connection conex = bd.Conectar();

	private String nomeDeUsuario;
	private String id;
	private String email;
	private int patente;
	private double kd;
	private int score;
	private int tempoJogo;
	private Classe classeFavorita;
	private Arma armaFavorita;
	private Veiculo veiculoFavorito;
	private String senha;

	public String getNomeDeUsuario() {
		return nomeDeUsuario;
	}

	public void setNomeDeUsuario(String nomeDeUsuario) {
		this.nomeDeUsuario = nomeDeUsuario;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPatente() {
		return patente;
	}

	public void setPatente(int patente) {
		this.patente = patente;
	}

	public double getKd() {
		return kd;
	}

	public void setKd(double kd) {
		this.kd = kd;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getTempoJogo() {
		return tempoJogo;
	}

	public void setTempoJogo(int tempoJogo) {
		this.tempoJogo = tempoJogo;
	}

	public Classe getClasseFavorita() {
		return classeFavorita;
	}

	public void setClasseFavorita(Classe classeFavorita) {
		this.classeFavorita = classeFavorita;
	}

	public Arma getArmaFavorita() {
		return armaFavorita;
	}

	public void setArmaFavorita(Arma armaFavorita) {
		this.armaFavorita = armaFavorita;
	}

	public Veiculo getVeiculoFavorito() {
		return veiculoFavorito;
	}

	public void setVeiculoFavorito(Veiculo veiculoFavorito) {
		this.veiculoFavorito = veiculoFavorito;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public boolean Login(String snome, int isenha) {
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador WHERE nomeDeUsuario LIKE '" + snome + "' AND senha LIKE '" + isenha
					+ "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nomeDeUsuario");
				int senha = rs.getInt("senha");

				if (senha == isenha && snome.equals(nome)) {
					System.out.println("Bem vindo " + rs.getString("nome") + " ao programa Battle Stats!!!!");
					return true;
				}
			}
			rs.close();
			stmt.close();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();

		}
		System.out.println("Login ou Senha inv�lidos.");
		return false;
	}

	public boolean novoJogador(Jogador j) {
		try {
			Statement stmt = conex.createStatement();
			stmt.execute("INSERT INTO Jogador(nomeDeUsuario, senha, nome, email, patente, kd, score, tempoJogo, classeFavorita, armaFavorita, veiculoFavorito)VALUES ('" + j.nomeDeUsuario + "','"
					+ j.senha + "','" + "ainda nao colocado" + "','" + j.email +"','" + j.patente +"','" + j.kd +"','" + j.score +"','" + j.tempoJogo +"','" + j.classeFavorita +"','" + j.armaFavorita +"','" + j.veiculoFavorito + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}
	}

}
