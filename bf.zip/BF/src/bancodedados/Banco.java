package bancodedados;

import java.sql.*;

public class Banco {
	private Connection Con;
	String driverName = "com.mysql.jdbc.Driver";                        
	String user = "root";
	String senha = "12345";
	String serverName = "localhost";
	String mydatabase ="battlefield";
	String url = "jdbc:mysql://" + serverName + "/" + mydatabase;
	

	public Banco() {
		this.Con = null;
	}

	public Connection Conectar() {
		try {
			Class.forName(driverName);
			Con = DriverManager.getConnection(url, user, senha);
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();
		}
		return Con;
	}

	public void Desconectar(Connection Con) {
		try {
			Con.close();
		} catch (SQLException e) {
			e.getMessage();
		}
	}

}
