package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bancodedados.Banco;

public class Classe {
	Banco bd = new Banco();
	Connection conex = bd.Conectar();
	
	private String nome;
	private String tipo;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public boolean excluirClasse(String snome) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute("DELETE FROM Classe WHERE nome LIKE '" + snome + "' ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}
	}

	public void listarClasse() {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM classe";
			ResultSet rs = stmt.executeQuery(SQL);
			int i = 0;
			while (rs.next()) {
				i = 1;
				System.out.println("// Listar Classe //\n\nNome: " + rs.getString("nome"));
				System.out.println("\nTipo: " + rs.getString("tipo") + "\n\n");
			}
			if (i == 0) {
				System.out.println("N�o existe dados para ser mostrados!!!");
			}

		} catch (java.lang.Exception ex) {
			System.out.println("Erro de consulta ao banco!");
			ex.printStackTrace();
		} finally {
			bd.Desconectar(conex);
		}

	}

	public void editarClasse(Classe c, String snome) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();

			stmt.execute("UPDATE Classe SET nome='" + c.nome + "', tipo='" + c.tipo + "' WHERE nome='" + snome + "' ");

			System.out.println("Altera��o feita com sucesso!!!");
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
		} finally {
			bd.Desconectar(conex);
		}
	}

	public ResultSet buscarClasse(String snome, int iop) {
		// iop =1 mostra, 2 = nao
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM Classe WHERE nome LIKE '" + snome + "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nome");

				if (snome.equals(nome)) {
					if (iop == 1) {
						System.out.println("// Listar Classe //\n\nNome: " + rs.getString("nome"));
						System.out.println("\nTipo: " + rs.getInt("tipo") + "\n\n");
					}
					return rs;
				}

			}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarClasse(Classe c) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO Classe(nome, tipo)VALUES ('"+ c.nome + "','" + c.tipo + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}

	}
	
}
