package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bancodedados.Banco;
import model.Veiculo;

public class CadastroVeiculoFrame extends JPanel implements ActionListener{
	
	Banco bd = new Banco();
	Connection conex = bd.Conectar();
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 480749330051613029L;

	JTextField nomeTxt = new JTextField(40);
	JTextField primariaTxt = new JTextField(40);
	JTextField secundariaTxt = new JTextField(40);
	JTextArea nomeTxtAr = new JTextArea("Nome",1,30);
	JTextArea tipoAr = new JTextArea("Tipo",1,30);
	JTextArea primariaTxtAr = new JTextArea("Arma primaria",1,30);
	JTextArea secundariaTxtAr = new JTextArea("Arma secundaria",1,30);
	
	JCheckBox check = new JCheckBox("Possui armamento");
	
	String[] tipos = {"Transporte", "Blindado", "Helic�ptero", "Jato", "Barco"};
	JComboBox<String> tipoCb = new JComboBox<>(tipos);
	
	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancela");
	
	private static JFrame frame = new JFrame();
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	
	public CadastroVeiculoFrame() {
		super(new BorderLayout());
		
		nomeTxtAr.setEditable(false);
		tipoAr.setEditable(false);
		primariaTxtAr.setEditable(false);
		primariaTxt.setVisible(false);
		primariaTxtAr.setVisible(false);
		secundariaTxtAr.setEditable(false);
		secundariaTxt.setVisible(false);
		secundariaTxtAr.setVisible(false);
		
		tipoCb.setSelectedIndex(0);
		
		check.addActionListener(this);
		
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tipoAr);
		jp.add(tipoCb);
		jp.add(check);
		jp.add(primariaTxtAr);
		jp.add(primariaTxt);
		jp.add(secundariaTxtAr);
		jp.add(secundariaTxt);
		jp.add(okBt);
		jp.add(cancelaBt);
		
		add(jp, BorderLayout.LINE_START);
		
	}
	
	boolean temCampoEmBranco(){
		if(nomeTxt.getText().equals("")) return true;
		if(check.isSelected()){
			if(primariaTxt.getText().equals("")) return true;
			if(secundariaTxt.getText().equals("")) return true;
		}
		return false;
	}
	
	public void actionPerformed(ActionEvent e) {
		if("confirma".equals(e.getActionCommand())){
			Veiculo veiculo = new Veiculo();
			if(check.isSelected()){
				if(temCampoEmBranco()){
					JOptionPane.showMessageDialog(frame, "Preencha todos os campos", "Campos em branco", JOptionPane.WARNING_MESSAGE);
					return;
				}
				veiculo.setPossuiArmamento(1);
				veiculo.setTipo(tipoCb.getSelectedItem().toString());
				veiculo.setNome(nomeTxt.getText());
				veiculo.setArmaPrimaria(primariaTxt.getText());
				veiculo.setArmaSecundaria(secundariaTxt.getText());
			}else{
				if(nomeTxt.getText().equals("")){
					JOptionPane.showMessageDialog(frame, "Preencha todos os campos", "Campos em branco", JOptionPane.WARNING_MESSAGE);
					return;
				}
				veiculo.setTipo(tipoCb.getSelectedItem().toString());
				veiculo.setNome(nomeTxt.getText());
			}
			
			if ((buscarVeiculo(veiculo.getNome()) != null)) {
				JOptionPane.showMessageDialog(frame, "Ve�culo J� cadastrado!", "Erro!",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			gravarVeiculo(veiculo);
			JOptionPane.showMessageDialog(frame, "Ve�culo cadastrado no sistema!", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
			frame.dispose();
			MainMenuAdmFrame.createAndShow();
			
		}
		if("cancela".equals(e.getActionCommand())){
			MainMenuAdmFrame volta = new MainMenuAdmFrame();
			frame.dispose();
			volta.createAndShow();
			return;
		}
		
		if(check.isSelected()){
			primariaTxt.setVisible(true);
			primariaTxtAr.setVisible(true);
			secundariaTxt.setVisible(true);
			secundariaTxtAr.setVisible(true);
			frame.pack();
			return;
		}
		else{
			primariaTxt.setVisible(false);
			primariaTxtAr.setVisible(false);
			secundariaTxt.setVisible(false);
			secundariaTxtAr.setVisible(false);
			frame.pack();
		}
		
	}
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new CadastroVeiculoFrame());
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		createAndShow();
	}

	public boolean gravarVeiculo(Veiculo v) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute("INSERT INTO Veiculo(nome, tipo, possuiArmamento, armaPrimaria, armaSecundaria)VALUES ('"
					+ v.getNome() + "','" + v.getTipo() + "','" + v.isPossuiArmamento() + "','" + v.getArmaPrimaria() + "','"
					+ v.getArmaSecundaria() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}

	}
	
	public ResultSet buscarVeiculo(String snome) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM veiculo";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nome");

				if (snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}
	
}
