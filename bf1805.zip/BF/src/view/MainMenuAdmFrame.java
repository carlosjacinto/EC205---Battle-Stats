package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainMenuAdmFrame extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4814570971500803418L;
	
	JButton visualizarContasBt = new JButton("Visalisar contas");
	JButton excluirContasBt = new JButton("Excluir contas");
	JButton visualizarArmasBt = new JButton("Visalisar armas");
	JButton cadastrarArmasBt = new JButton("Cadastrar armas");
	JButton editarArmasBt = new JButton("Editar armas");
	JButton excluirArmasBt = new JButton("Excluir armas");
	JButton visualizarClassesBt = new JButton("Visalisar classes");
	JButton cadastrarClassesBt = new JButton("Cadastrar classes");
	JButton editarClassesBt = new JButton("Editar classes");
	JButton excluirClassesBt = new JButton("Excluir classes");
	JButton visualizarVeiculosBt = new JButton("Visalisar veiculos");
	JButton cadastrarVeiculosBt = new JButton("Cadastrar veiculos");
	JButton editarVeiculosBt = new JButton("Editar veiculos");
	JButton excluirVeiculosBt = new JButton("Excluir veiculos");
	JButton voltarBt = new JButton("Voltar");
	
	private static JFrame frame = new JFrame("Menu");
	
	JPanel jp = new JPanel(new GridLayout(0, 1));
	
	public MainMenuAdmFrame() {
		
		visualizarContasBt.addActionListener(this);
		visualizarContasBt.setActionCommand("visualisarContas");
		excluirContasBt.addActionListener(this);
		excluirContasBt.setActionCommand("excluirContas");
		visualizarArmasBt.addActionListener(this);
		visualizarArmasBt.setActionCommand("visualisarArmas");
		cadastrarArmasBt.addActionListener(this);
		cadastrarArmasBt.setActionCommand("cadastrarArmas");
		editarArmasBt.addActionListener(this);
		editarArmasBt.setActionCommand("editarArmas");
		excluirArmasBt.addActionListener(this);
		excluirArmasBt.setActionCommand("excluirArmas");
		visualizarClassesBt.addActionListener(this);
		visualizarClassesBt.setActionCommand("visualisarClasses");
		cadastrarClassesBt.addActionListener(this);
		cadastrarClassesBt.setActionCommand("cadastrarClasses");
		editarClassesBt.addActionListener(this);
		editarClassesBt.setActionCommand("editarClasses");
		excluirClassesBt.addActionListener(this);
		excluirClassesBt.setActionCommand("excluirClasses");
		visualizarVeiculosBt.addActionListener(this);
		visualizarVeiculosBt.setActionCommand("visualisarVeiculos");
		cadastrarVeiculosBt.addActionListener(this);
		cadastrarVeiculosBt.setActionCommand("cadastrarVeiculos");
		editarVeiculosBt.addActionListener(this);
		editarVeiculosBt.setActionCommand("editarVeiculos");
		excluirVeiculosBt.addActionListener(this);
		excluirVeiculosBt.setActionCommand("excluirVeiculos");
		voltarBt.addActionListener(this);
		voltarBt.setActionCommand("voltar");
		
		jp.add(visualizarContasBt);
		jp.add(excluirContasBt);
		jp.add(visualizarArmasBt);
		jp.add(cadastrarArmasBt);
		jp.add(editarArmasBt);
		jp.add(excluirArmasBt);
		jp.add(visualizarClassesBt);
		jp.add(cadastrarClassesBt);
		jp.add(editarClassesBt);
		jp.add(excluirClassesBt);
		jp.add(visualizarVeiculosBt);
		jp.add(cadastrarVeiculosBt);
		jp.add(editarVeiculosBt);
		jp.add(excluirVeiculosBt);
		jp.add(voltarBt);
		
		add(jp, BorderLayout.LINE_START);
	}
	
	public void actionPerformed(ActionEvent e) {
		if("voltar".equals(e.getActionCommand())){
			LoginFrame volta = new LoginFrame();
			frame.dispose();
			volta.createAndShow();
		}
		else if("visualizarContas".equals(e.getActionCommand())){
		}
		else if("excluirContas".equals(e.getActionCommand())){
		}
		else if("visualizarArmas".equals(e.getActionCommand())){
		}
		else if("cadastrarArmas".equals(e.getActionCommand())){
			CadastroArmaFrame cadastrarArm = new CadastroArmaFrame();
			frame.dispose();
			cadastrarArm.createAndShow();
			return;
		}
		else if("editarArmas".equals(e.getActionCommand())){
		}
		else if("excluirArmas".equals(e.getActionCommand())){
		}
		else if("visualizarClasses".equals(e.getActionCommand())){
		}
		else if("cadastrarClasses".equals(e.getActionCommand())){
		}
		else if("editarClasses".equals(e.getActionCommand())){
		}
		else if("excluirClasses".equals(e.getActionCommand())){
		}
		else if("visualizarVeiculos".equals(e.getActionCommand())){
		}
		else if("cadastrarVeiculos".equals(e.getActionCommand())){
		}
		else if("editarVeiculos".equals(e.getActionCommand())){
		}
		else if("excluirVeiculos".equals(e.getActionCommand())){
		}
			
	}
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new MainMenuAdmFrame());
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		createAndShow();
	}
	
}
