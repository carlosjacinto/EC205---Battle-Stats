package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bancodedados.Banco;
import control.EmailValidator;

public class LoginFrame extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1999667136136945782L;
	
	Banco bd = new Banco();
	Connection conex = bd.Conectar();
	JTextField emailTxt = new JTextField(40);
	JPasswordField senhaTxt =  new JPasswordField(40);
	JTextArea emailTxtAr = new JTextArea("E-mail",1,40);
	JTextArea senhaTxtAr = new JTextArea("Senha",1,40);
	JButton okBt = new JButton("Login");
	JButton cadastroBt = new JButton("Nova conta");
	
	private static JFrame frame =  new JFrame("Battle Stats");
	
	JPanel jp = new JPanel(new GridLayout(0, 1));
	
	public LoginFrame() {
		super( new BorderLayout());
		
		emailTxtAr.setEditable(false);
		senhaTxtAr.setEditable(false);
		
		okBt.setActionCommand("loginB");
		okBt.addActionListener(this);
		
		cadastroBt.setActionCommand("cadastroB");
		cadastroBt.addActionListener(this);
		
		jp.add(emailTxtAr);
		jp.add(emailTxt);
		jp.add(senhaTxtAr);
		jp.add(senhaTxt);
		jp.add(okBt);
		jp.add(cadastroBt);
		add(jp,BorderLayout.LINE_START);
	}
	
	public boolean Login(String snome, String ssenha) {
		conex = bd.Conectar();
		
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador";
			ResultSet rs = stmt.executeQuery(SQL);
			
			while (rs.next()) {
				
				String nome = rs.getString("email");
				System.out.println(nome);
				System.out.println(snome);
				String senha = rs.getString("senha");
				System.out.println(ssenha);
				System.out.println(senha);
				if (senha.equals(ssenha) && snome.equals(nome)) {
					
					JOptionPane.showMessageDialog(frame,"Bem vindo " + rs.getString("nomeDeUsuario") + " ao programa Battle Stats!!!!", "Bem Vindo", JOptionPane.OK_OPTION);
					return true;
				}
			}
			rs.close();
			stmt.close();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		
		return false;
	}
	
	public boolean LoginAdm(String snome, String ssenha) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM usuariosadmin WHERE email LIKE '" + snome + "' AND senha LIKE '" + ssenha
					+ "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("email");
				String senha = rs.getString("senha");

				if (senha.equals(ssenha) && snome.equals(nome)) {
					JOptionPane.showMessageDialog(frame,"Bem vindo " + rs.getString("nome") + " ao programa Battle Stats!!!!", "Bem Vindo", JOptionPane.OK_OPTION);
					return true;
				}
			}
			rs.close();
			stmt.close();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		
		return false;
	}

	public void actionPerformed(ActionEvent e) {
		if("loginB".equals(e.getActionCommand())){
			
			if(emailTxt.getText().equals("") || senhaTxt.getPassword().equals("")){
				JOptionPane.showMessageDialog(frame, "Entre com o nome de usu�rio e senha","Campos em branco", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			EmailValidator emailValidator = new EmailValidator();
			if(!emailValidator.validate(emailTxt.getText().trim())){
				JOptionPane.showMessageDialog(frame,"Digite um e-mail v�lido","E-mail inv�lido!", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			if(Login(emailTxt.getText(), senhaTxt.getText().toString())){
				emailTxt.setText("");
				senhaTxt.setText("");
				MainMenuFrame menu = new MainMenuFrame();
				menu.createAndShow();
				frame.dispose();
				return;
			}
			
			if(LoginAdm(emailTxt.getText(), senhaTxt.getText().toString())){
				emailTxt.setText("");
				senhaTxt.setText("");
				MainMenuAdmFrame menu = new MainMenuAdmFrame();
				menu.createAndShow();
				frame.dispose();
			}
			JOptionPane.showMessageDialog(frame, "N�o encontramos nenhum usu�rio, verifique seus dados!","Usu�rio n�o existe!", JOptionPane.ERROR_MESSAGE);			
	
		}
		
		else{
			CadastroJogadorFrame novaConta = new CadastroJogadorFrame();
			frame.dispose();
			novaConta.createAndShow();
		}
	}
	
	public void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new LoginFrame());
		frame.pack();
		frame.setVisible(true);
	}
	
}
