package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bancodedados.Banco;
import model.Classe;

public class CadastroClasseFrame extends JPanel implements ActionListener{
	Banco bd = new Banco();
	Connection conex = bd.Conectar();
	/**
	 * 
	 */
	private static final long serialVersionUID = 6228372735673803479L;

	String[] tipos = {"Assalto", "ADP", "M.L.", "Rifle de precis�o"};
	JComboBox<String> tiposCb = new JComboBox<>(tipos);
	
	JTextArea nomeTxtAr = new JTextArea("Nome:",1,10);
	JTextArea tipoTxtAr = new JTextArea("Tipos de Arma:",1,10);
	JTextField nomeTxt = new JTextField(40);
	
	private static JFrame frame = new JFrame("Cadastro de classe");
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	
	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancela");
	
	public CadastroClasseFrame() {
		super(new BorderLayout());
		
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		
		nomeTxtAr.setEditable(false);
		tipoTxtAr.setEditable(false);
		
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tipoTxtAr);
		jp.add(tiposCb);
		jp.add(okBt);
		jp.add(cancelaBt);
		
		add(jp,BorderLayout.LINE_START);
		
	}
	
	boolean temCampoEmBranco(){
		if(nomeTxt.getText().equals("")) return true;
		return false;
	}
	
	public void actionPerformed(ActionEvent e) {
		if("confirma".equals(e.getActionCommand())){
			if(temCampoEmBranco()){
				JOptionPane.showMessageDialog(frame, "Preencha todos os campos", "Campos em branco", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			Classe classe = new Classe();
			classe.setNome(nomeTxt.getText());
			classe.setTipo(tiposCb.getSelectedItem().toString());
			if(buscarClasse(nomeTxt.getText())!=null){
				JOptionPane.showMessageDialog(frame, "Classe j� cadastrada no sistema!", "Classe j� existe!", JOptionPane.ERROR_MESSAGE);
				return;
			}
			JOptionPane.showMessageDialog(frame, "Classe cadastrada com sucesso!", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
			gravarClasse(classe);
			
			
			MainMenuAdmFrame volta = new MainMenuAdmFrame();
			frame.dispose();
			volta.createAndShow();
		}
		else{
			MainMenuAdmFrame volta = new MainMenuAdmFrame();
			frame.dispose();
			volta.createAndShow();
		}
	}
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new CadastroClasseFrame());
		frame.setVisible(true);
		frame.pack();
	}
	
	public static void main(String[] args) {
		createAndShow();
	}
	
	public ResultSet buscarClasse(String snome) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM Classe";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nome");

				if (snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarClasse(Classe c) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO Classe(nome, tipo)VALUES ('"+ c.getNome() + "','" + c.getTipo() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}

	}

}
