package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bancodedados.Banco;
import control.EmailValidator;
import model.Jogador;

public class CadastroJogadorFrame extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5405046071294782278L;

	Banco bd = new Banco();
	Connection conex = bd.Conectar();
	
	private static JFrame frame = new JFrame("Cadastro de Jogador");
	
	JTextField nomeUsuarioTxt = new JTextField(40);
	JTextField emailTxt = new JTextField(40);
	JTextField patenteTxt = new JTextField(40);
	JTextField kdTxt = new JTextField(40);
	JTextField scoreTxt = new JTextField(40);
	JTextField tempoJogoTxt = new JTextField(40);
	JPasswordField senhaTxt = new JPasswordField(40);
	JPasswordField senhaAgainTxt = new JPasswordField(40);
	JTextArea nomeUsuarioTxtAr = new JTextArea("Nome de usu�rio",1,40);
	JTextArea emailTxtAr = new JTextArea("E-mail",1,40);
	JTextArea patenteTxtAr = new JTextArea("Patente",1,40);
	JTextArea kdTxtAr = new JTextArea("K.D.",1,40);
	JTextArea scoreTxtAr = new JTextArea("Pontua��o",1,40);
	JTextArea tempoJogoTxtAr = new JTextArea("Tempo de Jogo",1,40);
	JTextArea senhaTxtAr = new JTextArea("Senha",1,40);
	JTextArea senhaAgainTxtAr = new JTextArea("Repita a senha",1,40);
	JTextArea selClasseTxtAr = new JTextArea("Selecione Sua Classe Favorita:",1,40);
	JTextArea selArmaTxtAr = new JTextArea("Selecione Sua Arma Favorita:",1,40);
	JTextArea selVeiculoTxtAr = new JTextArea("Selecione Seu Ve�culo Favorito:",1,40);
	JComboBox<?> selClasse = buscaClasse();;
	JComboBox<?> selArmaFavorita = buscaArma();
	JComboBox<?> selVeiculoFavorito = buscaVeiculo();
	
	JButton okBt = new JButton("Confirmar");
	JButton cancelBt = new JButton("Cancelar");

	JPanel jp = new JPanel(new GridLayout(0,1));
	
	public JComboBox<?> buscaVeiculo(){		
		conex = bd.Conectar();
		
		try {
			JComboBox<String> selVeiculo = new JComboBox<>();
			selVeiculo.addItem("--Selecione--");
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM veiculo ORDER BY nome";
			ResultSet rs = stmt.executeQuery(SQL);
			
			
			while (rs.next()) {
				String nome = rs.getString("nome");	
				selVeiculo.addItem(nome);
				
			}
			rs.close();
			stmt.close();
			return selVeiculo;

		} catch (java.lang.Exception ex) {
			System.out.println("erro conexao");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
		
		
	}
	
	public JComboBox<?> buscaArma (){		
		conex = bd.Conectar();
		
		try {
			JComboBox<String> selArma = new JComboBox<>();
			selArma.addItem("--Selecione--");
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM arma ORDER BY nome";
			ResultSet rs = stmt.executeQuery(SQL);
			
			
			while (rs.next()) {
				String nome = rs.getString("nome");	
				selArma.addItem(nome);
				
			}
			rs.close();
			stmt.close();
			return selArma;

		} catch (java.lang.Exception ex) {
			System.out.println("erro conexao");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
		
		
	}
	
	public JComboBox<?> buscaClasse (){		
		conex = bd.Conectar();
		
		try {
			JComboBox<String> selClasse = new JComboBox<>();
			selClasse.addItem("--Selecione--");
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM classe ORDER BY nome";
			ResultSet rs = stmt.executeQuery(SQL);
			
			
			while (rs.next()) {
				String nome = rs.getString("nome");	
				selClasse.addItem(nome);
				
			}
			rs.close();
			stmt.close();
			return selClasse;

		} catch (java.lang.Exception ex) {
			System.out.println("erro conexao");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
		
		
	}
	
	
	public ResultSet buscarJogador(String snome, String semail) {
		// iop = 1 mostrar dados , 2 nao mostrar dados
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador WHERE nomeDeUsuario LIKE '" + snome + "' OR email LIKE '" + semail
					+ "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nomeDeUsuario");
				String email = rs.getString("email");

				if (semail.toLowerCase().equals(email.toLowerCase()) || snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}
			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarJogador(Jogador j) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO Jogador(nomeDeUsuario, senha, nome, email, patente, kd, score, tempoJogo, classeFavorita, armaFavorita, veiculoFavorito)VALUES ('"
							+ j.getNomeDeUsuario() + "','" + j.getSenha() + "','" + j.getNome() + "','" + j.getEmail() + "','" + j.getPatente()
							+ "','" + j.getKd() + "','" + j.getScore() + "','" + j.getTempoJogo()+ "','"+j.getClasseFavorita()+ "','"+j.getArmaFavorita()
							+"','"+j.getVeiculoFavorito() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}
	}
	
	public CadastroJogadorFrame() {
		super (new BorderLayout());
		
		nomeUsuarioTxtAr.setEditable(false);
		emailTxtAr.setEditable(false);
		patenteTxtAr.setEditable(false);
		kdTxtAr.setEditable(false);
		scoreTxtAr.setEditable(false);
		tempoJogoTxtAr.setEditable(false);
		senhaTxtAr.setEditable(false);
		senhaAgainTxtAr.setEditable(false);
		selClasseTxtAr.setEditable(false);
		selArmaTxtAr.setEditable(false);
		selVeiculoTxtAr.setEditable(false);
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelBt.addActionListener(this);
		cancelBt.setActionCommand("cancela");
		
		jp.add(nomeUsuarioTxtAr);
		jp.add(nomeUsuarioTxt);
		jp.add(emailTxtAr);
		jp.add(emailTxt);
		jp.add(patenteTxtAr);
		jp.add(patenteTxt);
		jp.add(kdTxtAr);
		jp.add(kdTxt);
		jp.add(scoreTxtAr);
		jp.add(scoreTxt);
		jp.add(tempoJogoTxtAr);
		jp.add(tempoJogoTxt);
		jp.add(selClasseTxtAr);
		jp.add(selClasse);
		jp.add(selArmaTxtAr);
		jp.add(selArmaFavorita);
		jp.add(selVeiculoTxtAr);
		jp.add(selVeiculoFavorito);
		jp.add(senhaTxtAr);
		jp.add(senhaTxt);
		jp.add(senhaAgainTxtAr);
		jp.add(senhaAgainTxt);
		
		jp.add(okBt);
		jp.add(cancelBt);
		
		add(jp,BorderLayout.LINE_START);
	}
	
	boolean isNumeric(String str)  
	{  
	  try  
	  {  
	    @SuppressWarnings("unused")
		int d = Integer.parseInt(str);
	  }  
	  catch(NumberFormatException nfe)  
	  {  
	    return false;  
	  }  
	  return true;  
	}
	
	boolean stringEmNumero(){
		if(!isNumeric(patenteTxt.getText())) return true;
		if(!isNumeric(kdTxt.getText())) return true;
		if(!isNumeric(tempoJogoTxt.getText())) return true;
		if(!isNumeric(scoreTxt.getText())) return true;
		return false;
	}
	
	
	boolean temCampoVazio(){
		if(nomeUsuarioTxt.getText().equals("")) return true;
		if(emailTxt.getText().equals("")) return true;
		if(patenteTxt.getText().equals("")) return true;
		if(kdTxt.getText().equals("")) return true;
		if(scoreTxt.getText().equals("")) return true;
		if(tempoJogoTxt.getText().equals("")) return true;
		if(senhaTxt.getPassword().length==0) return true;
		if(senhaAgainTxt.getPassword().length==0) return true;
		return false;
	}
	
	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e) {
		if("confirma".equals(e.getActionCommand())){
			
			if(temCampoVazio()){
				JOptionPane.showMessageDialog(frame, "Preencha todos os campos!","Campos em branco",JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			EmailValidator emailValidator = new EmailValidator();
			if(!emailValidator.validate(emailTxt.getText().trim())){
				JOptionPane.showMessageDialog(frame, "Entre com um e-mail v�lido!","E-mail inv�lido",JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			if( !senhaAgainTxt.getText().toString().equals(senhaTxt.getText().toString())){
				JOptionPane.showMessageDialog(frame, "As senhas n�o combinam!", "Senhas diferentes", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			if(buscarJogador(nomeUsuarioTxt.getText(), emailTxt.getText())!=null){
				JOptionPane.showMessageDialog(frame, "J� existe um usu�rio cadastrado com esses dados!", "Conta j� existente", JOptionPane.ERROR_MESSAGE);
				return;
			}
			
			if(stringEmNumero()){
				JOptionPane.showMessageDialog(frame,"Patente, K/D, Score e Tempo de Jogo devem ser inteiros.","Valores inv�lidos",JOptionPane.ERROR_MESSAGE);
				return;
			}
			
			Jogador novo = new Jogador();
			novo.setNomeDeUsuario(nomeUsuarioTxt.getText());
			novo.setEmail(emailTxt.getText());
			novo.setPatente(Integer.parseInt(patenteTxt.getText()));
			novo.setKd(Integer.parseInt(kdTxt.getText()));
			novo.setScore(Integer.parseInt(scoreTxt.getText()));
			novo.setTempoJogo(Integer.parseInt(tempoJogoTxt.getText()));
			novo.setSenha(senhaTxt.getText().toString());
			novo.setClasseFavorita(selClasse.getSelectedItem().toString());
			novo.setArmaFavorita(selArmaFavorita.getSelectedItem().toString());
			novo.setVeiculoFavorito(selVeiculoFavorito.getSelectedItem().toString());
			gravarJogador(novo);
			JOptionPane.showMessageDialog(frame, "Cadastro realizado com sucesso!","Cadastro bem sucedido!",JOptionPane.OK_OPTION);
			LoginFrame volta = new LoginFrame();
			frame.dispose();
			volta.createAndShow();
		}
		else{
			LoginFrame volta = new LoginFrame();
			frame.dispose();
			volta.createAndShow();
		}
		
	}
	
	public static void createAndShow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new CadastroJogadorFrame());
		frame.pack();
		frame.setVisible(true);
	}
}
