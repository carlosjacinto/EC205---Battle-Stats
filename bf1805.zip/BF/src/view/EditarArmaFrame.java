package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class EditarArmaFrame extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8914113844849243183L;
	
	JTextField nomeTxt = new JTextField(40);
	JTextField alcanceTxt = new JTextField(40);
	JTextField precisaoTxt = new JTextField(40);
	JTextField tiroSemVisadaTxt = new JTextField(40);
	JTextField estabilidadeTxt = new JTextField(40);
	JTextField cadenciaTxt = new JTextField(40);
	JTextField capacidadePenteTxt = new JTextField(40);
	
	JTextArea nomeTxtAr = new JTextArea("Nome:",1,10);
	JTextArea alcanceTxtAr = new JTextArea("Alcance:",1,10);
	JTextArea precisaoTxtAr = new JTextArea("Precis�o:",1,10);
	JTextArea tiroSemVisadaTxtAr = new JTextArea("Tiro sem visada:",1,10);
	JTextArea estabilidadeTxtAr = new JTextArea("Estabilidade:",1,10);
	JTextArea cadenciaTxtAr = new JTextArea("Cad�ncia:",1,10);
	JTextArea capacidadePenteTxtAr = new JTextArea("Capacidade do pente:",1,10);
	
	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancela");
	
	String[] tipos = { "Assalto", "ADP", "M.L.", "Rifle de precis�o", "Carabina", "Escopeta", "DMR", "Pistola" };
	JComboBox<String> tipoArma = new JComboBox<String>(tipos);
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	
	public EditarArmaFrame(){

		super(new BorderLayout());
		
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		
		nomeTxtAr.setEditable(false);
		alcanceTxtAr.setEditable(false);
		precisaoTxtAr.setEditable(false);
		tiroSemVisadaTxtAr.setEditable(false);
		estabilidadeTxtAr.setEditable(false);
		cadenciaTxtAr.setEditable(false);
		capacidadePenteTxtAr.setEditable(false);
		
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tipoArma);
		jp.add(alcanceTxtAr);
		jp.add(alcanceTxt);
		jp.add(precisaoTxtAr);
		jp.add(precisaoTxt);
		jp.add(tiroSemVisadaTxtAr);
		jp.add(tiroSemVisadaTxt);
		jp.add(estabilidadeTxtAr);
		jp.add(estabilidadeTxt);
		jp.add(cadenciaTxtAr);
		jp.add(cadenciaTxt);
		jp.add(capacidadePenteTxtAr);
		jp.add(capacidadePenteTxt);
		jp.add(okBt);
		jp.add(cancelaBt);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
