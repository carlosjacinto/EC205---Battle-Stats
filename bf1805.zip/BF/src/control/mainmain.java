package control;

import view.LoginFrame;

public class mainmain {
	public static void main(String[] args) {
		LoginFrame start = new LoginFrame();
		start.createAndShow();
	}
}
