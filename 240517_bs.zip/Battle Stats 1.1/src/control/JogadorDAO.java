package control;

public class JogadorDAO {

}
