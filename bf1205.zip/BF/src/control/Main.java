package control;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;

import bancodedados.Banco;
import model.Arma;
import model.Classe;
import model.Jogador;
import model.Personagem;
import model.Veiculo;

public class Main {

	private static Scanner inp;
	private static Scanner inp2;
	private static Scanner inp3;
	private static Scanner inpu;
	private static Scanner inp4;

	public static void main(String[] args) {

		ArrayList<Jogador> contas = new ArrayList<>();
		ArrayList<Arma> armas = new ArrayList<>();
		ArrayList<Classe> classes = new ArrayList<>();
		ArrayList<Personagem> personagens = new ArrayList<>();
		ArrayList<Veiculo> veiculos = new ArrayList<>();

		Scanner inpt = new Scanner(System.in);
		int op1, op2, pos, senha;
		String nome, id;
		Jogador jog = new Jogador();

		do {
			System.out.println("Nome de usuario: ");
			nome = inpt.next() + inpt.nextLine();
			System.out.println("Senha: ");
			senha = inpt.nextInt();

		} while (!jog.Login(nome, senha));

		do {

			System.out.println(
					"///////// BATTLE STATS /////////\n\n[1] Cadastro\n[2] Edi��o\n[3] Listagem\n[4] Remo��o\n[5] Sair\n\nDigite uma op��o: ");

			op1 = inpt.nextInt();

			switch (op1) {
			case 1:
				System.out.println(
						"\n// Cadastrar //\n\n[1] Jogador\n[2] Classe\n[3] Arma\n[4] Ve�culo\n[5] Personagem\n[6] Sair\n\nDigite uma op��o: ");
				op2 = inpt.nextInt();
				switch (op2) {
				case 1:
					Jogador novoJog = new Jogador();
					novoJog = novaConta();
					if (jog.buscarJogador(novoJog.getNome(), novoJog.getEmail(), 2) == null)
						jog.gravarJogador(novoJog);
					else
						System.out.println("Usuario J� cadastrado!!!");
					break;
				case 2:
					Classe novaCl = new Classe();
					novaCl = novaClasse();
					classes.add(novaCl);
					break;
				case 3:
					Arma novaArm = new Arma();
					novaArm = novaArma();
					novaArm.gravarArma(novaArm);
					break;
				case 4:
					Veiculo novoVe = new Veiculo();
					novoVe = novoVeiculo();
					veiculos.add(novoVe);
					break;
				case 5:
					Personagem novoPe = new Personagem();
					novoPe = novoPersonagem();
					personagens.add(novoPe);
					break;
				case 6:
					break;
				}
				break;

			case 2:
				System.out.println(
						"\n// Editar //\n\n[1] Jogador\n[2] Classe\n[3] Arma\n[4] Ve�culo\n[5] Personagem\n[6] Sair\n\nDigite uma op��o: ");
				op2 = inpt.nextInt();
				switch (op2) {
				case 1:
					System.out.print("Nome de usuario ou email do jogador: ");
					nome = inpt.next() + inpt.nextLine();
					ResultSet resultado = jog.buscarJogador(nome, nome, 1);
					if (resultado == null)
						System.out.println("Jogador n�o encontrado!\n");
					else {
						Jogador novoJog = new Jogador();
						novoJog = editarJogador();
						jog.editarJogador(novoJog, nome, nome);
					}
					break;
				case 2:
					System.out.print("Nome da classe: ");
					nome = inpt.next() + inpt.nextLine();
					pos = procurarClasse(classes, nome);
					if (pos == -1)
						System.out.println("Classe n�o encontrada!\n");
					else {
						listarClasse(classes.get(pos));
						Classe newClasse = new Classe();
						newClasse = editarClasse();
						classes.set(pos, newClasse);
					}
					break;
				case 3:
					System.out.print("Nome da arma: ");
					nome = inpt.next() + inpt.nextLine();
					pos = procurarArma(armas, nome);
					if (pos == -1)
						System.out.println("Arma n�o encontrada!\n");
					else {
						listarArma(armas.get(pos));
						Arma newArma = new Arma();
						newArma = editarArma();
						armas.set(pos, newArma);
					}
					break;
				case 4:
					System.out.print("Nome do veiculo: ");
					nome = inpt.next() + inpt.nextLine();
					pos = procurarVeiculo(veiculos, nome);
					if (pos == -1)
						System.out.println("Veiculo n�o encontrado!\n");
					else {
						listarVeiculo(veiculos.get(pos));
						Veiculo newVeiculo = new Veiculo();
						newVeiculo = editarVeiculo();
						veiculos.set(pos, newVeiculo);
					}
					break;
				case 5:
					System.out.print("Nome do personagem: ");
					nome = inpt.next() + inpt.nextLine();
					pos = procurarPersonagem(personagens, nome);
					if (pos == -1)
						System.out.println("Personagem n�o encontrado!\n");
					else {
						listarPersonagem(personagens.get(pos));
						Personagem newPersonagem = new Personagem();
						newPersonagem = editarPersonagem();
						personagens.set(pos, newPersonagem);
					}
					break;
				case 6:
					break;
				}
				break;

			case 3:
				System.out.println(
						"\n// Listar //\n\n[1] Jogador\n[2] Classe\n[3] Arma\n[4] Ve�culo\n[5] Personagem\n[6] Sair\n\nDigite uma op��o: ");
				op2 = inpt.nextInt();
				switch (op2) {
				case 1:
					jog.listarJogador();
					break;
				case 2:
					for (Classe c : classes)
						listarClasse(c);
					break;
				case 3:
					for (Arma a : armas)
						listarArma(a);
					break;
				case 4:
					for (Veiculo v : veiculos)
						listarVeiculo(v);
					break;
				case 5:
					for (Personagem p : personagens)
						listarPersonagem(p);
					break;
				case 6:
					break;
				}
				break;

			case 4:
				System.out.println(
						"\n// Remover //\n\n[1] Jogador\n[2] Classe\n[3] Arma\n[4] Ve�culo\n[5] Personagem\n[6] Sair\n\nDigite uma op��o: ");
				op2 = inpt.nextInt();
				switch (op2) {
				case 1:
					System.out.print("ID do jogador: ");
					id = inpt.next() + inpt.nextLine();
					pos = procurarJogador(contas, id);
					if (pos == -1)
						System.out.println("Jogador n�o encontrado!\n");
					else {
						contas.remove(pos);
						System.out.println("Jogador removido!\n");
					}
					break;
				case 2:
					System.out.print("Nome da classe: ");
					nome = inpt.next() + inpt.nextLine();
					pos = procurarClasse(classes, nome);
					if (pos == -1)
						System.out.println("Classe n�o encontrada!\n");
					else {
						classes.remove(pos);
						System.out.println("Classe removida!\n");
					}
					break;
				case 3:
					System.out.print("Nome da arma: ");
					nome = inpt.next() + inpt.nextLine();
					pos = procurarArma(armas, nome);
					if (pos == -1)
						System.out.println("Arma n�o encontrada!\n");
					else {
						armas.remove(pos);
						System.out.println("Arma removido!\n");
					}
					break;
				case 4:
					System.out.print("Nome do veiculo: ");
					nome = inpt.next() + inpt.nextLine();
					pos = procurarVeiculo(veiculos, nome);
					if (pos == -1)
						System.out.println("Veiculo n�o encontrado!\n");
					else {
						veiculos.remove(pos);
						System.out.println("Veiculo removido!\n");
					}
					break;
				case 5:
					System.out.print("Nome do personagem: ");
					nome = inpt.next() + inpt.nextLine();
					pos = procurarPersonagem(personagens, nome);
					if (pos == -1)
						System.out.println("Persgonagem n�o encontrado!\n");
					else {
						personagens.remove(pos);
						System.out.println("Personagem removido!\n");
					}
					break;
				case 6:
					break;
				}
				break;

			case 5:
				break;

			}
		} while (!(op1 == 5));

		inpt.close();
	}

	static Connection TestaConexao() {
		Banco bd = new Banco();

		Connection conex = bd.Conectar();
		try {

			System.out.println("Banco de dados conectado com sucesso!!!");

		} catch (java.lang.Exception ex) {
			ex.printStackTrace();
			System.out.print("N�o foi possivel conectar ao banco de dados.\n Aplicativo sendo encerrado!");
			System.exit(0);
		}
		return conex;
	}

	static int procurarJogador(ArrayList<Jogador> contas, String nome) {
		int i = 0;
		for (Jogador j : contas) {
			if (j.getNome().compareTo(nome) == 0)
				return i;
			i++;
		}
		return -1;
	}

	static int procurarClasse(ArrayList<Classe> classes, String nome) {
		int i = 0;
		for (Classe c : classes) {
			if (c.getNome().compareTo(nome) == 0)
				return i;
			i++;
		}
		return -1;
	}

	static int procurarPersonagem(ArrayList<Personagem> personagens, String nome) {
		int i = 0;
		for (Personagem p : personagens) {
			if (p.getNome().compareTo(nome) == 0)
				return i;
			i++;
		}
		return -1;
	}

	static int procurarArma(ArrayList<Arma> armas, String nome) {
		int i = 0;
		for (Arma a : armas) {
			if (a.getNome().compareTo(nome) == 0)
				return i;
			i++;
		}
		return -1;
	}

	static int procurarVeiculo(ArrayList<Veiculo> veiculos, String nome) {
		int i = 0;
		for (Veiculo v : veiculos) {
			if (v.getNome().compareTo(nome) == 0)
				return i;
			i++;
		}
		return -1;
	}

	static Jogador novaConta() {
		inp = new Scanner(System.in);
		Jogador novaConta = new Jogador();
		System.out.println("// Novo jogador //\n\nNome de usu�rio: ");
		novaConta.setNomeDeUsuario(inp.next() + inp.nextLine());
		System.out.println("Nome: ");
		novaConta.setNome(inp.next() + inp.nextLine());
		System.out.println("E-mail: ");
		novaConta.setEmail(inp.next() + inp.nextLine());
		System.out.println("Patente: ");
		novaConta.setPatente(inp.nextInt());
		System.out.println("K.D.: ");
		novaConta.setKd(inp.nextDouble());
		System.out.println("Score: ");
		novaConta.setScore(inp.nextInt());
		System.out.println("Temp de jogo: ");
		novaConta.setTempoJogo(inp.nextInt());
		System.out.println("Senha: ");
		novaConta.setSenha(inp.next() + inp.nextLine());

		return novaConta;
	}

	static Jogador editarJogador() {
		Jogador j = new Jogador();

		System.out.println("// Editar jogador //\n\nNome de usu�rio: ");
		j.setNomeDeUsuario(inp.next() + inp.nextLine());
		System.out.println("Nome: ");
		j.setNome(inp.next() + inp.nextLine());
		System.out.println("E-mail: ");
		j.setEmail(inp.next() + inp.nextLine());
		System.out.println("Patente: ");
		j.setPatente(inp.nextInt());
		System.out.println("K.D.: ");
		j.setKd(inp.nextDouble());
		System.out.println("Score: ");
		j.setScore(inp.nextInt());
		System.out.println("Temp de jogo: ");
		j.setTempoJogo(inp.nextInt());
		System.out.println("Senha: ");
		j.setSenha(inp.next() + inp.nextLine());

		return j;
	}

	static Arma novaArma() {
		inp2 = new Scanner(System.in);
		Arma novaArma = new Arma();
		System.out.println("// Nova arma //\n\nNome: ");
		novaArma.setNome(inp2.next() + inp2.nextLine());
		System.out.println("Tipo: ");
		novaArma.setTipo(inp2.next() + inp2.nextLine());

		int op;
		System.out.println("Acess�rio? (1-Sim / 0-N�o): ");
		op = inp2.nextInt();
		if (op == 0) {
			System.out.println("Dano: ");
			novaArma.setDano(inp2.nextInt());
			System.out.println("Alcance: ");
			novaArma.setAlcance(inp2.nextInt());
			System.out.println("Precis�o: ");
			novaArma.setPrecisao(inp2.nextInt());
			System.out.println("Tiro sem visada: ");
			novaArma.setTiroSemVisada(inp2.nextInt());
			System.out.println("Estabilidade: ");
			novaArma.setEstabilidade(inp2.nextInt());
			System.out.println("Cad�ncia: ");
			novaArma.setCadencia(inp2.nextInt());
			System.out.println("Capacidade do pente: ");
			novaArma.setCapacidadeDoPente(inp2.nextInt());
		} else
			novaArma.setAcessorio(1);
		return novaArma;
	}

	static Arma editarArma() {
		Arma arma = new Arma();
		Scanner inp = new Scanner(System.in);
		System.out.println("// Editar arma //\n\nNome: ");
		arma.setNome(inp.next() + inp.nextLine());
		System.out.println("Tipo: ");
		arma.setTipo(inp.next() + inp.nextLine());
		if (arma.isAcessorio() == 0) {
			System.out.println("Dano: ");
			arma.setDano(inp.nextInt());
			System.out.println("Alcance: ");
			arma.setAlcance(inp.nextInt());
			System.out.println("Precis�o: ");
			arma.setPrecisao(inp.nextInt());
			System.out.println("Tiro sem visada: ");
			arma.setTiroSemVisada(inp.nextInt());
			System.out.println("Estabilidade: ");
			arma.setEstabilidade(inp.nextInt());
			System.out.println("Cad�ncia: ");
			arma.setCadencia(inp.nextInt());
			System.out.println("Capacidade do pente: ");
			arma.setCapacidadeDoPente(inp.nextInt());
		}

		inp.close();
		return arma;
	}

	static void listarArma(Arma arma) {

		System.out.println("// Listar arma //\n\nNome: " + arma.getNome());
		System.out.println("\nTipo: " + arma.getTipo());
		if (arma.isAcessorio() == 0) {
			System.out.println("\nDano: " + arma.getDano());
			System.out.println("\nAlcance: " + arma.getAlcance());
			System.out.println("\nPrecisao: " + arma.getPrecisao());
			System.out.println("\nTiro sem visada: " + arma.getTiroSemVisada());
			System.out.println("\nEstabilidade: " + arma.getEstabilidade());
			System.out.println("\nCad�ncia: " + arma.getCadencia());
			System.out.println("\nCapaciade do pente: " + arma.getCapacidadeDoPente() + "\n\n");
		}
	}

	static Classe novaClasse() {
		inp3 = new Scanner(System.in);
		Classe novaClasse = new Classe();
		System.out.println("// Nova classe //\n\nNome: ");
		novaClasse.setNome(inp3.next() + inp3.nextLine());
		System.out.println("Tipo: ");
		novaClasse.setTipo(inp3.next() + inp3.nextLine());

		return novaClasse;
	}

	static Classe editarClasse() {
		Classe classe = new Classe();
		Scanner inp = new Scanner(System.in);
		System.out.println("// Editar classe //\n\nNome: ");
		classe.setNome(inp.next() + inp.nextLine());
		System.out.println("Tipo: ");
		classe.setTipo(inp.next() + inp.nextLine());
		inp.close();
		return classe;
	}

	static void listarClasse(Classe classe) {
		System.out.println("// Listar arma //\n\nNome: " + classe.getNome());
		System.out.println("\nTipo: " + classe.getTipo() + "\n\n");
	}

	static Personagem novoPersonagem() {
		Personagem novoPersonagem = new Personagem();
		Classe classe = new Classe();
		Arma arma = new Arma();
		inpu = new Scanner(System.in);

		System.out.println("Nome: ");
		novoPersonagem.setNome(inpu.next() + inpu.nextLine());
		novoPersonagem.setClasse(classe);
		novoPersonagem.setArmaPrimaria(arma);
		novoPersonagem.setArmaSecundaria(arma);
		novoPersonagem.setItemUm(arma);
		novoPersonagem.setItemDois(arma);

		return novoPersonagem;
	}

	static Personagem editarPersonagem() {
		Personagem personagem = new Personagem();
		Classe classe = new Classe();
		Arma arma = new Arma();
		Scanner inpu = new Scanner(System.in);

		System.out.println("Nome: ");
		personagem.setNome(inpu.next() + inpu.nextLine());
		personagem.setClasse(classe);
		personagem.setArmaPrimaria(arma);
		personagem.setArmaSecundaria(arma);
		personagem.setItemUm(arma);
		personagem.setItemDois(arma);

		inpu.close();
		return personagem;
	}

	static void listarPersonagem(Personagem personagem) {
		System.out.println("// Listar personagem //\n\nNome: " + personagem.getNome());
		System.out.println("\nClasse: " + personagem.getClasse().getNome());
		System.out.println("\nArma prim�ria: " + personagem.getArmaPrimaria().getNome());
		System.out.println("\nArma secund�ria: " + personagem.getArmaSecundaria().getNome());
		System.out.println("\nItem 1: " + personagem.getItemUm().getNome());
		System.out.println("\nItem 2: " + personagem.getItemDois().getNome() + "\n\n");
	}

	static Veiculo novoVeiculo() {
		Veiculo novoVeiculo = new Veiculo();
		inp4 = new Scanner(System.in);

		System.out.println("// Novo veiculo //\n\nNome: ");
		novoVeiculo.setNome(inp4.next() + inp4.nextLine());
		System.out.println("Tipo: ");
		novoVeiculo.setTipo(inp4.next() + inp4.nextLine());

		int op;
		System.out.println("Possui armamento? (1-Sim / 0-N�o): ");
		op = inp4.nextInt();
		if (op == 1) {
			novoVeiculo.setPossuiArmamento(true);
			System.out.println("Arma prim�ria: ");
			novoVeiculo.setArmaPrimaria(inp4.next() + inp4.nextLine());
			System.out.println("Arma Secund�ria: ");
			novoVeiculo.setArmaSecundaria(inp4.next() + inp4.nextLine());
		}

		return novoVeiculo;
	}

	static Veiculo editarVeiculo() {
		Veiculo veiculo = new Veiculo();
		Scanner inp = new Scanner(System.in);

		System.out.println("// Editar veiculo //\n\nNome: ");
		veiculo.setNome(inp.next() + inp.nextLine());
		System.out.println("Tipo: ");
		veiculo.setTipo(inp.next() + inp.nextLine());
		if (veiculo.isPossuiArmamento()) {
			System.out.println("Arma prim�ria: ");
			veiculo.setArmaPrimaria(inp.next() + inp.nextLine());
			System.out.println("Arma Secund�ria: ");
			veiculo.setArmaSecundaria(inp.next() + inp.nextLine());
		}

		inp.close();
		return veiculo;
	}

	static void listarVeiculo(Veiculo veiculo) {
		System.out.println("// Listar veiculo //\n\nNome: " + veiculo.getNome());
		System.out.println("\nTipo: " + veiculo.getTipo());
		if (veiculo.isPossuiArmamento()) {
			System.out.println("\nArma prim�ria: " + veiculo.getArmaPrimaria());
			System.out.println("\nArma secund�ria: " + veiculo.getArmaSecundaria() + "\n\n");
		}
	}

}
