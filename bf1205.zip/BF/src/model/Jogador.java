package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bancodedados.Banco;

public class Jogador {
	Banco bd = new Banco();
	Connection conex = bd.Conectar();

	private String nomeDeUsuario;
	private String nome;
	private int id;
	private String email;
	private int patente;
	private double kd;
	private int score;
	private int tempoJogo;
	private Classe classeFavorita;
	private Arma armaFavorita;
	private Veiculo veiculoFavorito;
	private String senha;

	public String getNomeDeUsuario() {
		return nomeDeUsuario;
	}

	public void setNomeDeUsuario(String nomeDeUsuario) {
		this.nomeDeUsuario = nomeDeUsuario;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPatente() {
		return patente;
	}

	public void setPatente(int patente) {
		this.patente = patente;
	}

	public double getKd() {
		return kd;
	}

	public void setKd(double kd) {
		this.kd = kd;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getTempoJogo() {
		return tempoJogo;
	}

	public void setTempoJogo(int tempoJogo) {
		this.tempoJogo = tempoJogo;
	}

	public Classe getClasseFavorita() {
		return classeFavorita;
	}

	public void setClasseFavorita(Classe classeFavorita) {
		this.classeFavorita = classeFavorita;
	}

	public Arma getArmaFavorita() {
		return armaFavorita;
	}

	public void setArmaFavorita(Arma armaFavorita) {
		this.armaFavorita = armaFavorita;
	}

	public Veiculo getVeiculoFavorito() {
		return veiculoFavorito;
	}

	public void setVeiculoFavorito(Veiculo veiculoFavorito) {
		this.veiculoFavorito = veiculoFavorito;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public boolean Login(String snome, int isenha) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador WHERE nomeDeUsuario LIKE '" + snome + "' AND senha LIKE '" + isenha
					+ "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nomeDeUsuario");
				int senha = rs.getInt("senha");

				if (senha == isenha && snome.equals(nome)) {
					System.out.println("Bem vindo " + rs.getString("nome") + " ao programa Battle Stats!!!!");
					return true;
				}
			}
			rs.close();
			stmt.close();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		System.out.println("Login ou Senha inv�lidos.");
		return false;
	}

	public void listarJogador() {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador";
			ResultSet rs = stmt.executeQuery(SQL);
			int i = 0;
			while (rs.next()) {
				i = 1;
				System.out.println("// Listar jogador //\n\nNome de usu�rio: " + rs.getString("nomeDeUsuario"));
				System.out.println("\nNome: " + rs.getString("nome"));
				System.out.println("\nE-mail: " + rs.getString("email"));
				System.out.println("\nPatente: " + rs.getInt("patente"));
				System.out.println("\nK.D.: " + rs.getInt("kd"));
				System.out.println("\nScore: " + rs.getInt("score"));
				System.out.println("\nTemp de jogo: " + rs.getInt("tempoJogo") + "\n\n");
			}
			if (i == 0) {
				System.out.println("N�o existe dados para ser mostrados!!!");
			}

		} catch (java.lang.Exception ex) {
			System.out.println("Erro de consulta ao banco!");
			ex.printStackTrace();
		} finally {
			bd.Desconectar(conex);
		}

	}

	public ResultSet buscarJogador(String snome, String semail, int iop) {
		//iop = 1 mostrar dados , 2 nao mostrar dados
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador WHERE nomeDeUsuario LIKE '" + snome + "' OR email LIKE '" + semail
					+ "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nomeDeUsuario");
				String email = rs.getString("email");
				if (iop == 1) {
					System.out.println("// Listar jogador //\n\nNome de usu�rio: " + rs.getString("nomeDeUsuario"));
					System.out.println("\nNome: " + rs.getString("nome"));
					System.out.println("\nE-mail: " + rs.getString("email"));
					System.out.println("\nPatente: " + rs.getInt("patente"));
					System.out.println("\nK.D.: " + rs.getInt("kd"));
					System.out.println("\nScore: " + rs.getInt("score"));
					System.out.println("\nTemp de jogo: " + rs.getInt("tempoJogo") + "\n\n");
				}
				if (semail.equals(email) || snome.equals(nome)) {
					return rs;
				}

			}
			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarJogador(Jogador j) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO Jogador(nomeDeUsuario, senha, nome, email, patente, kd, score, tempoJogo, classeFavorita, armaFavorita, veiculoFavorito)VALUES ('"
							+ j.nomeDeUsuario + "','" + j.senha + "','" + j.nome + "','" + j.email + "','" + j.patente
							+ "','" + j.kd + "','" + j.score + "','" + j.tempoJogo + "','" + j.classeFavorita + "','"
							+ j.armaFavorita + "','" + j.veiculoFavorito + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}
	}

	public void editarJogador(Jogador j, String snome, String semail) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute("UPDATE Jogador SET nomeDeUsuario='" + j.nomeDeUsuario + "', Senha='" + j.senha + "', Nome='"
					+ j.nome + "', Email='" + j.email + "', Patente='" + j.patente + "', Kd='" + j.kd + "', score='"
					+ j.score + "', tempoJogo ='" + j.tempoJogo + "', classeFavorita='" + j.classeFavorita
					+ "', ArmaFavorita='" + j.armaFavorita + "', VeiculoFavorito='" + j.veiculoFavorito
					+ "'  WHERE email='" + semail + "' ");
			System.out.println("Altera��o feita com sucesso!!!");
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
		} finally {
			bd.Desconectar(conex);
		}
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
