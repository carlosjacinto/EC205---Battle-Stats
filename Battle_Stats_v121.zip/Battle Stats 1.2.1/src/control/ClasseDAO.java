package control;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Classe;

public class ClasseDAO {
	
	DataBase bd = new DataBase();
	Connection conex = bd.Conectar();
	
	public ResultSet buscarClasse(String snome) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM Classe";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nome");

				if (snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarClasse(Classe c) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO Classe(nome, tipo)VALUES ('"+ c.getNome() + "','" + c.getTipo() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}

	}

	
	public ArrayList<String> buscaClasse (){		
		conex = bd.Conectar();
		
		try {
			ArrayList<String> selClasse = new ArrayList<String>();
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM classe ORDER BY nome";
			ResultSet rs = stmt.executeQuery(SQL);
			
			
			while (rs.next()) {
				String nome = rs.getString("nome");	
				selClasse.add(nome);
				
			}
			rs.close();
			stmt.close();
			return selClasse;

		} catch (java.lang.Exception ex) {
			System.out.println("erro conexao");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
		
		
	}
}
