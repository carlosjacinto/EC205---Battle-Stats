package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class StartFrame extends JFrame implements ActionListener {

	private JPanel contentPane;

	private Clip clip;

	private static final long serialVersionUID = 8490160171069157379L;

	private void refresh() {
		setSize(1360, 760);
		setSize(1366, 768);
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StartFrame frame = new StartFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StartFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.DARK_GRAY);
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(5, 19, 0, 692);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(1, 0, 0, 0));

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(5, 5, 1355, 734);
		lblNewLabel.setIcon(new ImageIcon("Media//StartCover.jpg"));
		contentPane.add(lblNewLabel);

		JButton startbutton = new JButton("Start");
		startbutton.setBounds(1149, 682, 95, 23);
		startbutton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new LoginFrame();
				setVisible(false);
				stopMusica();
			}
		});
		contentPane.add(startbutton);

		setTitle("BATTLE STATS 1.1");
		setSize(1366, 768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		getIniciarMusicaButton();

		refresh();

	}

	public void getIniciarMusicaButton() {

		try {
			File soundFile = new File("Media/main_theme.wav");
			AudioInputStream sound = AudioSystem.getAudioInputStream(soundFile);
			DataLine.Info info = new DataLine.Info(Clip.class, sound.getFormat());
			clip = (Clip) AudioSystem.getLine(info);
			clip.open(sound);
			clip.start();
			clip.loop(100000000);
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException ev) {
			JOptionPane.showMessageDialog(null, "Deu ruim a musica!");
		}
	}
	
	public void stopMusica(){
		clip.stop();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}
