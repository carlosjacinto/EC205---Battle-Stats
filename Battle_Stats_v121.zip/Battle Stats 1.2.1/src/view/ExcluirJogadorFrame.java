package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Toolkit;

public class ExcluirJogadorFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7094580009793806318L;
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroJogadorFrame frame = new CadastroJogadorFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExcluirJogadorFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\icon.png"));
		setTitle("Nova conta");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\r_jogador_cover1.jpg"));
		contentPane.add(label, BorderLayout.WEST);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\r_jogador_cover2.jpg"));
		contentPane.add(lblNewLabel, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNomeDeUsurio = new JLabel("Nome de usu\u00E1rio");
		lblNomeDeUsurio.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNomeDeUsurio.setForeground(Color.WHITE);
		lblNomeDeUsurio.setBounds(10, 0, 108, 14);
		panel.add(lblNomeDeUsurio);
		
		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblEmail.setForeground(Color.WHITE);
		lblEmail.setBounds(10, 61, 46, 14);
		panel.add(lblEmail);
		
		JLabel lblPatente = new JLabel("Patente");
		lblPatente.setForeground(Color.WHITE);
		lblPatente.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPatente.setBounds(10, 119, 134, 14);
		panel.add(lblPatente);
		
		JLabel lblKd = new JLabel("K/D");
		lblKd.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblKd.setForeground(Color.WHITE);
		lblKd.setBounds(10, 175, 75, 14);
		panel.add(lblKd);
		
		JLabel lblNewLabel_1 = new JLabel("Score");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(10, 231, 75, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblTempoDeJogo = new JLabel("Tempo de jogo");
		lblTempoDeJogo.setForeground(Color.WHITE);
		lblTempoDeJogo.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblTempoDeJogo.setBounds(10, 287, 108, 14);
		panel.add(lblTempoDeJogo);
		
		JLabel lblClasseFavorita = new JLabel("Classe Favorita");
		lblClasseFavorita.setForeground(Color.WHITE);
		lblClasseFavorita.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblClasseFavorita.setBounds(10, 343, 108, 14);
		panel.add(lblClasseFavorita);
		
		JLabel lblArmaFavorita = new JLabel("Arma favorita");
		lblArmaFavorita.setForeground(Color.WHITE);
		lblArmaFavorita.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblArmaFavorita.setBounds(10, 399, 118, 14);
		panel.add(lblArmaFavorita);
		
		JLabel lblVeiculoFavorito = new JLabel("Veiculo favorito");
		lblVeiculoFavorito.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblVeiculoFavorito.setForeground(Color.WHITE);
		lblVeiculoFavorito.setBounds(10, 455, 108, 14);
		panel.add(lblVeiculoFavorito);
		
		textField = new JTextField();
		textField.setBounds(10, 30, 420, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(10, 86, 420, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnConfirmar = new JButton("Confirmar");
		btnConfirmar.setBounds(10, 511, 200, 23);
		panel.add(btnConfirmar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(10, 545, 150, 23);
		panel.add(btnCancelar);
		
		textField_2 = new JTextField();
		textField_2.setBounds(10, 144, 420, 20);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(10, 200, 420, 20);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(10, 256, 420, 20);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(10, 312, 420, 20);
		panel.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(10, 368, 420, 20);
		panel.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(10, 424, 420, 20);
		panel.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBounds(10, 480, 420, 20);
		panel.add(textField_8);
		textField_8.setColumns(10);
	}
}
