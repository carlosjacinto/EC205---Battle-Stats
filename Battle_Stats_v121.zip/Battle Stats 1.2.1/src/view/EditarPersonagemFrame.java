package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Toolkit;

public class EditarPersonagemFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5464860311145194661L;
	
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroPersonagemFrame frame = new CadastroPersonagemFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarPersonagemFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\icon.png"));
		setTitle("Editar personagem");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\e_personagem_cover1.png"));
		contentPane.add(label, BorderLayout.WEST);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\e_personagem_cover2.png"));
		contentPane.add(label_1, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblClasse = new JLabel("Classe");
		lblClasse.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblClasse.setForeground(Color.WHITE);
		lblClasse.setBounds(10, 11, 46, 14);
		panel.add(lblClasse);
		
		JComboBox<String> comboBox = new JComboBox<>();
		comboBox.setBounds(10, 36, 420, 20);
		panel.add(comboBox);
		
		JLabel lblArma = new JLabel("Arma prim\u00E1ria");
		lblArma.setForeground(Color.WHITE);
		lblArma.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblArma.setBounds(10, 67, 138, 14);
		panel.add(lblArma);
		
		JComboBox<String> comboBox_1 = new JComboBox<>();
		comboBox_1.setBounds(10, 92, 420, 20);
		panel.add(comboBox_1);
		
		JLabel lblArmaSecundria = new JLabel("Arma secund\u00E1ria");
		lblArmaSecundria.setForeground(Color.WHITE);
		lblArmaSecundria.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblArmaSecundria.setBounds(10, 123, 127, 14);
		panel.add(lblArmaSecundria);
		
		JComboBox<String> comboBox_2 = new JComboBox<>();
		comboBox_2.setBounds(10, 148, 420, 20);
		panel.add(comboBox_2);
		
		JLabel lblItem = new JLabel("Item 1");
		lblItem.setForeground(Color.WHITE);
		lblItem.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblItem.setBounds(10, 179, 46, 14);
		panel.add(lblItem);
		
		JComboBox<String> comboBox_3 = new JComboBox<>();
		comboBox_3.setBounds(10, 204, 420, 20);
		panel.add(comboBox_3);
		
		JLabel lblItem_1 = new JLabel("Item 2");
		lblItem_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblItem_1.setForeground(Color.WHITE);
		lblItem_1.setBounds(10, 235, 46, 14);
		panel.add(lblItem_1);
		
		JComboBox<String> comboBox_4 = new JComboBox<>();
		comboBox_4.setBounds(10, 260, 420, 20);
		panel.add(comboBox_4);
		
		JButton btnNewButton = new JButton("Confirmar");
		btnNewButton.setBounds(10, 291, 200, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cancelar");
		btnNewButton_1.setBounds(10, 325, 150, 23);
		panel.add(btnNewButton_1);
	}

}
