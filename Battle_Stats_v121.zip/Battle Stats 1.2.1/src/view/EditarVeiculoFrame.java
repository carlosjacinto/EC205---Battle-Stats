package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.Toolkit;

public class EditarVeiculoFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3550894899265380001L;
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroVeiculoFrame frame = new CadastroVeiculoFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarVeiculoFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\icon.png"));
		setFont(new Font("Leelawadee UI", Font.BOLD, 12));
		setForeground(Color.BLACK);
		setTitle("Novo Veiculo");
		setBackground(Color.DARK_GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\e_veiculo_cover1.jpg"));
		contentPane.add(label, BorderLayout.WEST);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\e_veiculo_cover2.jpg"));
		contentPane.add(label_1, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JComboBox<String> comboBox = new JComboBox<>();
		comboBox.setBounds(10, 11, 420, 20);
		panel.add(comboBox);
		
		textField = new JTextField();
		textField.setBounds(10, 68, 420, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBackground(Color.GRAY);
		lblNewLabel.setBounds(190, 42, 37, 15);
		panel.add(lblNewLabel);
		
		JRadioButton rdbtnNo = new JRadioButton("N\u00E3o");
		buttonGroup.add(rdbtnNo);
		rdbtnNo.setBounds(321, 101, 109, 23);
		panel.add(rdbtnNo);
		
		JRadioButton rdbtnSim = new JRadioButton("Sim");
		buttonGroup.add(rdbtnSim);
		rdbtnSim.setBounds(209, 101, 109, 23);
		panel.add(rdbtnSim);
		
		JLabel lblArmaPrimria = new JLabel("Arma prim\u00E1ria?");
		lblArmaPrimria.setForeground(Color.WHITE);
		lblArmaPrimria.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblArmaPrimria.setBounds(35, 104, 109, 14);
		panel.add(lblArmaPrimria);
		
		textField_1 = new JTextField();
		textField_1.setBounds(10, 146, 420, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JRadioButton rdbtnNo_1 = new JRadioButton("N\u00E3o");
		buttonGroup_1.add(rdbtnNo_1);
		rdbtnNo_1.setBounds(321, 180, 109, 23);
		panel.add(rdbtnNo_1);
		
		JRadioButton rdbtnSim_1 = new JRadioButton("Sim");
		buttonGroup_1.add(rdbtnSim_1);
		rdbtnSim_1.setBounds(209, 180, 109, 23);
		panel.add(rdbtnSim_1);
		
		JLabel lblArmaSecundria = new JLabel("Arma secund\u00E1ria?");
		lblArmaSecundria.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblArmaSecundria.setForeground(Color.WHITE);
		lblArmaSecundria.setBounds(35, 183, 109, 14);
		panel.add(lblArmaSecundria);
		
		JButton btnConfirmar = new JButton("Confirmar");
		btnConfirmar.setBounds(10, 273, 200, 23);
		panel.add(btnConfirmar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(10, 308, 150, 23);
		panel.add(btnCancelar);
		
		textField_2 = new JTextField();
		textField_2.setBounds(10, 226, 420, 20);
		panel.add(textField_2);
		textField_2.setColumns(10);
	}
}
