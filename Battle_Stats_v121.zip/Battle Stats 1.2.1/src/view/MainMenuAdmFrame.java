package view;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.Toolkit;

public class MainMenuAdmFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5957645396936954203L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenuAdmFrame frame = new MainMenuAdmFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainMenuAdmFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\icon.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		setVisible(true);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\menu_adm_cover1.jpg"));
		contentPane.add(label, BorderLayout.WEST);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\menu_adm_cover2.jpg"));
		contentPane.add(label_1, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("Cadastrar Arma");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(218, 59, 1));
		btnNewButton.setBounds(10, 71, 420, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Visualizar Arma");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setBackground(new Color(218, 59, 1));
		btnNewButton_1.setBounds(10, 105, 420, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Editar Arma");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setBackground(new Color(218, 59, 1));
		btnNewButton_2.setBounds(10, 139, 420, 23);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Excluir Arma");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setBackground(new Color(218, 59, 1));
		btnNewButton_3.setBounds(10, 173, 420, 23);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Visualizar Contas");
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_4.setForeground(new Color(255, 255, 255));
		btnNewButton_4.setBackground(new Color(218, 59, 1));
		btnNewButton_4.setBounds(10, 207, 420, 23);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Excluir Conta");
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_5.setForeground(new Color(255, 255, 255));
		btnNewButton_5.setBackground(new Color(218, 59, 1));
		btnNewButton_5.setBounds(10, 241, 420, 23);
		panel.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Visualizar Classe");
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_6.setForeground(new Color(255, 255, 255));
		btnNewButton_6.setBackground(new Color(218, 59, 1));
		btnNewButton_6.setBounds(10, 275, 420, 23);
		panel.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Cadastrar Classe");
		btnNewButton_7.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_7.setForeground(new Color(255, 255, 255));
		btnNewButton_7.setBackground(new Color(218, 59, 1));
		btnNewButton_7.setBounds(10, 309, 420, 23);
		panel.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("Editar Classe");
		btnNewButton_8.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_8.setForeground(new Color(255, 255, 255));
		btnNewButton_8.setBackground(new Color(218, 59, 1));
		btnNewButton_8.setBounds(10, 343, 420, 23);
		panel.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("Excluir Classe");
		btnNewButton_9.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_9.setForeground(new Color(255, 255, 255));
		btnNewButton_9.setBackground(new Color(218, 59, 1));
		btnNewButton_9.setBounds(10, 377, 420, 23);
		panel.add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("Visualizar Ve�culos");
		btnNewButton_10.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_10.setForeground(new Color(255, 255, 255));
		btnNewButton_10.setBackground(new Color(218, 59, 1));
		btnNewButton_10.setBounds(10, 411, 420, 23);
		panel.add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("Cadastrar Ve�culo");
		btnNewButton_11.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_11.setForeground(new Color(255, 255, 255));
		btnNewButton_11.setBackground(new Color(218, 59, 1));
		btnNewButton_11.setBounds(10, 445, 420, 23);
		panel.add(btnNewButton_11);
		
		JButton btnNewButton_12 = new JButton("Editar Ve�culo");
		btnNewButton_12.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_12.setForeground(new Color(255, 255, 255));
		btnNewButton_12.setBackground(new Color(218, 59, 1));
		btnNewButton_12.setBounds(10, 479, 420, 23);
		panel.add(btnNewButton_12);
		
		JButton btnNewButton_13 = new JButton("Excluir Ve�culo");
		btnNewButton_13.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_13.setForeground(new Color(255, 255, 255));
		btnNewButton_13.setBackground(new Color(218, 59, 1));
		btnNewButton_13.setBounds(10, 513, 420, 23);
		panel.add(btnNewButton_13);
		
		JButton btnNewButton_14 = new JButton("Voltar");
		btnNewButton_14.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_14.setForeground(new Color(255, 255, 255));
		btnNewButton_14.setBackground(new Color(218, 59, 1));
		btnNewButton_14.setBounds(10, 547, 420, 23);
		panel.add(btnNewButton_14);
	}
}
