package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Toolkit;

public class ExcluirVeiculoFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9210504324802020240L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroVeiculoFrame frame = new CadastroVeiculoFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExcluirVeiculoFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\icon.png"));
		setFont(new Font("Leelawadee UI", Font.BOLD, 12));
		setForeground(Color.BLACK);
		setTitle("Novo Veiculo");
		setBackground(Color.DARK_GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\r_veiculo_cover1.jpg"));
		contentPane.add(label, BorderLayout.WEST);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\r_veiculo_cover2.jpg"));
		contentPane.add(label_1, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(10, 136, 420, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBackground(Color.GRAY);
		lblNewLabel.setBounds(191, 110, 37, 15);
		panel.add(lblNewLabel);
		
		JLabel lblArmaPrimria = new JLabel("Arma prim\u00E1ria");
		lblArmaPrimria.setForeground(Color.WHITE);
		lblArmaPrimria.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblArmaPrimria.setBounds(160, 168, 109, 14);
		panel.add(lblArmaPrimria);
		
		textField_1 = new JTextField();
		textField_1.setBounds(10, 193, 420, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblArmaSecundria = new JLabel("Arma secund\u00E1ria");
		lblArmaSecundria.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblArmaSecundria.setForeground(Color.WHITE);
		lblArmaSecundria.setBounds(160, 222, 109, 14);
		panel.add(lblArmaSecundria);
		
		JButton btnConfirmar = new JButton("Confirmar");
		btnConfirmar.setBounds(10, 323, 200, 23);
		panel.add(btnConfirmar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(10, 357, 150, 23);
		panel.add(btnCancelar);
		
		textField_2 = new JTextField();
		textField_2.setBounds(10, 247, 420, 20);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblTipo = new JLabel("Tipo");
		lblTipo.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblTipo.setForeground(Color.WHITE);
		lblTipo.setBounds(10, 54, 46, 14);
		panel.add(lblTipo);
		
		textField_3 = new JTextField();
		textField_3.setBounds(10, 79, 420, 20);
		panel.add(textField_3);
		textField_3.setColumns(10);
	}
}
