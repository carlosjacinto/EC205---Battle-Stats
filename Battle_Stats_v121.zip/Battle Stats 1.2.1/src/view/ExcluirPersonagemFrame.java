package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.JTextField;

public class ExcluirPersonagemFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6074953434626669L;
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroPersonagemFrame frame = new CadastroPersonagemFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExcluirPersonagemFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\icon.png"));
		setTitle("Novo personagem");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\r_personagem_cover1.png"));
		contentPane.add(label, BorderLayout.WEST);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\r_personagem_cover2.png"));
		contentPane.add(label_1, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblClasse = new JLabel("Classe");
		lblClasse.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblClasse.setForeground(Color.WHITE);
		lblClasse.setBounds(10, 11, 46, 14);
		panel.add(lblClasse);
		
		JLabel lblArma = new JLabel("Arma prim\u00E1ria");
		lblArma.setForeground(Color.WHITE);
		lblArma.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblArma.setBounds(10, 67, 138, 14);
		panel.add(lblArma);
		
		JLabel lblArmaSecundria = new JLabel("Arma secund\u00E1ria");
		lblArmaSecundria.setForeground(Color.WHITE);
		lblArmaSecundria.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblArmaSecundria.setBounds(10, 123, 127, 14);
		panel.add(lblArmaSecundria);
		
		JLabel lblItem = new JLabel("Item 1");
		lblItem.setForeground(Color.WHITE);
		lblItem.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblItem.setBounds(10, 179, 46, 14);
		panel.add(lblItem);
		
		JLabel lblItem_1 = new JLabel("Item 2");
		lblItem_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblItem_1.setForeground(Color.WHITE);
		lblItem_1.setBounds(10, 235, 46, 14);
		panel.add(lblItem_1);
		
		JButton btnNewButton = new JButton("Confirmar");
		btnNewButton.setBounds(10, 291, 200, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cancelar");
		btnNewButton_1.setBounds(10, 325, 150, 23);
		panel.add(btnNewButton_1);
		
		textField = new JTextField();
		textField.setBounds(10, 36, 420, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(10, 92, 420, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(10, 148, 420, 20);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(10, 204, 420, 20);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(10, 260, 420, 20);
		panel.add(textField_4);
		textField_4.setColumns(10);
	}

}
