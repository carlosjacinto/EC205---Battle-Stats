package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Toolkit;

public class EditarJogadorFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8880209769404198981L;
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroJogadorFrame frame = new CadastroJogadorFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarJogadorFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\icon.png"));
		setTitle("Editar conta");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\e_jogador_cover_1.jpg"));
		contentPane.add(label, BorderLayout.WEST);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.2.1\\Media\\e_jogador_cover2.jpg"));
		contentPane.add(lblNewLabel, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNomeDeUsurio = new JLabel("Nome de usu\u00E1rio");
		lblNomeDeUsurio.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNomeDeUsurio.setForeground(Color.WHITE);
		lblNomeDeUsurio.setBounds(10, 0, 108, 14);
		panel.add(lblNomeDeUsurio);
		
		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblEmail.setForeground(Color.WHITE);
		lblEmail.setBounds(10, 61, 46, 14);
		panel.add(lblEmail);
		
		JLabel lblPatente = new JLabel("Patente");
		lblPatente.setForeground(Color.WHITE);
		lblPatente.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPatente.setBounds(10, 119, 134, 14);
		panel.add(lblPatente);
		
		JLabel lblKd = new JLabel("K/D");
		lblKd.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblKd.setForeground(Color.WHITE);
		lblKd.setBounds(10, 175, 75, 14);
		panel.add(lblKd);
		
		JLabel lblNewLabel_1 = new JLabel("Score");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(10, 231, 75, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblTempoDeJogo = new JLabel("Tempo de jogo");
		lblTempoDeJogo.setForeground(Color.WHITE);
		lblTempoDeJogo.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblTempoDeJogo.setBounds(10, 287, 108, 14);
		panel.add(lblTempoDeJogo);
		
		JLabel lblClasseFavorita = new JLabel("Classe Favorita");
		lblClasseFavorita.setForeground(Color.WHITE);
		lblClasseFavorita.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblClasseFavorita.setBounds(10, 343, 108, 14);
		panel.add(lblClasseFavorita);
		
		JLabel lblArmaFavorita = new JLabel("Arma favorita");
		lblArmaFavorita.setForeground(Color.WHITE);
		lblArmaFavorita.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblArmaFavorita.setBounds(10, 399, 118, 14);
		panel.add(lblArmaFavorita);
		
		JLabel lblVeiculoFavorito = new JLabel("Veiculo favorito");
		lblVeiculoFavorito.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblVeiculoFavorito.setForeground(Color.WHITE);
		lblVeiculoFavorito.setBounds(10, 455, 108, 14);
		panel.add(lblVeiculoFavorito);
		
		JLabel lblSenha = new JLabel("Trocar senha");
		lblSenha.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblSenha.setForeground(Color.WHITE);
		lblSenha.setBounds(10, 511, 118, 14);
		panel.add(lblSenha);
		
		JLabel lblConfirmarSenha = new JLabel("Confirmar senha");
		lblConfirmarSenha.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblConfirmarSenha.setForeground(Color.WHITE);
		lblConfirmarSenha.setBounds(10, 567, 108, 14);
		panel.add(lblConfirmarSenha);
		
		textField = new JTextField();
		textField.setBounds(10, 30, 420, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(10, 86, 420, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JSpinner spinner = new JSpinner();
		spinner.setBounds(10, 144, 420, 20);
		panel.add(spinner);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setBounds(10, 200, 420, 20);
		panel.add(spinner_1);
		
		JSpinner spinner_2 = new JSpinner();
		spinner_2.setBounds(10, 256, 420, 20);
		panel.add(spinner_2);
		
		JSpinner spinner_3 = new JSpinner();
		spinner_3.setBounds(10, 312, 420, 20);
		panel.add(spinner_3);
		
		JComboBox<String> comboBox = new JComboBox<>();
		comboBox.setBounds(11, 368, 419, 20);
		panel.add(comboBox);
		
		JComboBox<String> comboBox_1 = new JComboBox<>();
		comboBox_1.setBounds(10, 424, 420, 20);
		panel.add(comboBox_1);
		
		JComboBox<String> comboBox_2 = new JComboBox<>();
		comboBox_2.setBounds(10, 480, 420, 20);
		panel.add(comboBox_2);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(10, 536, 420, 20);
		panel.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(10, 592, 420, 20);
		panel.add(passwordField_1);
		
		JButton btnConfirmar = new JButton("Confirmar");
		btnConfirmar.setBounds(10, 623, 200, 23);
		panel.add(btnConfirmar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(10, 657, 150, 23);
		panel.add(btnCancelar);
	}
}
