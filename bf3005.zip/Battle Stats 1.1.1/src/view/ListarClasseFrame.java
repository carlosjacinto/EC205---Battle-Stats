package view;

public class ListarClasseFrame {

}
