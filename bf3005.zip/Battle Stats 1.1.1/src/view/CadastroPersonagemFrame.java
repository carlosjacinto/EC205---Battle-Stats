package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class CadastroPersonagemFrame extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7182186633670861622L;

	JTextArea classeTxtAr = new JTextArea("Classe",1,30);
	JTextArea primariaTxtAr = new JTextArea("Arma primaria",1,30);
	JTextArea secundariaTxtAr = new JTextArea("Arma secundaria",1,30);
	JTextArea item1TxtAr = new JTextArea("Item 1",1,30);
	JTextArea item2TxtAr = new JTextArea("Item 2",1,30);
	
	JComboBox<String> classeCb = new JComboBox<>();
	JComboBox<String> primariaCb = new JComboBox<>();
	JComboBox<String> secundariaCb = new JComboBox<>();
	JComboBox<String> item1Cb = new JComboBox<>();
	JComboBox<String> item2Cb = new JComboBox<>();
	
	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancelar");
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	JLabel background=new JLabel(new ImageIcon("Media/Default.jpg"));
	
	public CadastroPersonagemFrame() {
		
		setTitle("Cadastro de personagem");
		setSize(1366,768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setLayout(new BorderLayout());
		
		config();
		adicionar();
		refresh();
		
	}
	
	private void refresh(){
		setSize(1360,760);
		setSize(1366,768);
	}
	
	private void adicionar(){
		add(background);
		background.setLayout(new GridBagLayout());
		jp.add(classeTxtAr);
		jp.add(classeCb);
		jp.add(primariaTxtAr);
		jp.add(primariaCb);
		jp.add(secundariaTxtAr);
		jp.add(secundariaCb);
		jp.add(item1TxtAr);
		jp.add(item1Cb);
		jp.add(item2TxtAr);
		jp.add(item2Cb);
		jp.add(okBt);
		jp.add(cancelaBt);
		background.add(jp);
	}
	
	private void config(){
		classeTxtAr.setEditable(false);
		classeTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		classeTxtAr.setBackground(new Color(0, 0, 0));
		classeTxtAr.setForeground(Color.WHITE);
		primariaTxtAr.setEditable(false);
		primariaTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		primariaTxtAr.setBackground(new Color(0, 0, 0));
		primariaTxtAr.setForeground(Color.WHITE);
		secundariaTxtAr.setEditable(false);
		secundariaTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		secundariaTxtAr.setBackground(new Color(0, 0, 0));
		secundariaTxtAr.setForeground(Color.WHITE);
		item1TxtAr.setEditable(false);
		item1TxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		item1TxtAr.setBackground(new Color(0, 0, 0));
		item1TxtAr.setForeground(Color.WHITE);
		item2TxtAr.setEditable(false);
		item2TxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		item2TxtAr.setBackground(new Color(0, 0, 0));
		item2TxtAr.setForeground(Color.WHITE);
		classeCb.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		classeCb.setBackground(new Color(100, 100, 100));
		classeCb.setForeground(Color.WHITE);
		primariaCb.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		primariaCb.setBackground(new Color(100, 100, 100));
		primariaCb.setForeground(Color.WHITE);
		secundariaCb.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		secundariaCb.setBackground(new Color(100, 100, 100));
		secundariaCb.setForeground(Color.WHITE);
		item1Cb.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		item1Cb.setBackground(new Color(100, 100, 100));
		item1Cb.setForeground(Color.WHITE);
		item2Cb.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		item2Cb.setBackground(new Color(100, 100, 100));
		item2Cb.setForeground(Color.WHITE);
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		okBt.setBackground(new Color(255, 0, 0));
		okBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		okBt.setForeground(Color.WHITE);
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		cancelaBt.setBackground(new Color(250, 95, 0));
		cancelaBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cancelaBt.setForeground(Color.WHITE);
	}
	
	public void actionPerformed(ActionEvent e) {
		if("confirma".equals(e.getActionCommand())){
			new MainMenuFrame();
			dispose();
		}
		else{
			new MainMenuFrame();
			dispose();
		}
	}
	
}
