package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import control.VeiculoDAO;
import model.Veiculo;

public class CadastroVeiculoFrame extends JFrame implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 480749330051613029L;

	JTextField nomeTxt = new JTextField(40);
	JTextField primariaTxt = new JTextField(40);
	JTextField secundariaTxt = new JTextField(40);
	JTextArea nomeTxtAr = new JTextArea("Nome",1,30);
	JTextArea tipoAr = new JTextArea("Tipo",1,30);
	JTextArea primariaTxtAr = new JTextArea("Arma primaria",1,30);
	JTextArea secundariaTxtAr = new JTextArea("Arma secundaria",1,30);
	
	JCheckBox check = new JCheckBox("Possui armamento");

	private String[] tipos = {"Transporte", "Blindado", "Helic�ptero", "Jato", "Barco"};
	JComboBox<String> tipoCb = new JComboBox<>(tipos);
	
	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancela");
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	JLabel background=new JLabel(new ImageIcon("Media/Default.jpg"));
	
	public CadastroVeiculoFrame() {
		
		setTitle("Cadastrar veiculo");
		setSize(1366,768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setLayout(new BorderLayout());
		
		config();
		adicionar();
		refresh();
		
	}
	
	private void refresh(){
		setSize(1360,760);
		setSize(1366,768);
	}
	
	private void adicionar(){
		add(background);
		background.setLayout(new GridBagLayout());
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tipoAr);
		jp.add(tipoCb);
		jp.add(check);
		jp.add(primariaTxtAr);
		jp.add(primariaTxt);
		jp.add(secundariaTxtAr);
		jp.add(secundariaTxt);
		jp.add(okBt);
		jp.add(cancelaBt);
		background.add(jp);
	}
	
	private void config(){
		nomeTxtAr.setEditable(false);
		nomeTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		nomeTxtAr.setBackground(new Color(0, 0, 0));
		nomeTxtAr.setForeground(Color.WHITE);
		tipoAr.setEditable(false);
		tipoAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		tipoAr.setBackground(new Color(0, 0, 0));
		tipoAr.setForeground(Color.WHITE);
		primariaTxtAr.setEditable(false);
		primariaTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		primariaTxtAr.setBackground(new Color(0, 0, 0));
		primariaTxtAr.setForeground(Color.WHITE);
		primariaTxt.setVisible(false);
		primariaTxtAr.setVisible(false);
		secundariaTxtAr.setEditable(false);
		secundariaTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		secundariaTxtAr.setBackground(new Color(0, 0, 0));
		secundariaTxtAr.setForeground(Color.WHITE);
		secundariaTxt.setVisible(false);
		secundariaTxtAr.setVisible(false);
		tipoCb.setSelectedIndex(0);
		tipoCb.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		tipoCb.setBackground(new Color(100, 100, 100));
		tipoCb.setForeground(Color.WHITE);
		check.addActionListener(this);
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		okBt.setBackground(new Color(255, 0, 0));
		okBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		okBt.setForeground(Color.WHITE);
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		cancelaBt.setBackground(new Color(250, 95, 0));
		cancelaBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cancelaBt.setForeground(Color.WHITE);
	}
	
	boolean temCampoEmBranco(){
		if(nomeTxt.getText().equals(""))
			return true;
		if(check.isSelected()){
			if(primariaTxt.getText().equals("")) 
				return true;
			if(secundariaTxt.getText().equals("")) 
				return true;
		}
		return false;
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if("confirma".equals(e.getActionCommand())){
			Veiculo veiculo = new Veiculo();
			VeiculoDAO veiculoDao = new VeiculoDAO();
			
			if(check.isSelected()){
				if(temCampoEmBranco()){
					JOptionPane.showMessageDialog(new JFrame(), "Preencha todos os campos", "Campos em branco", JOptionPane.WARNING_MESSAGE);
					return;
				}
				veiculo.setPossuiArmamento(1);
				veiculo.setTipo(tipoCb.getSelectedItem().toString());
				veiculo.setNome(nomeTxt.getText());
				veiculo.setArmaPrimaria(primariaTxt.getText());
				veiculo.setArmaSecundaria(secundariaTxt.getText());
			}else{
				if(nomeTxt.getText().equals("")){
					JOptionPane.showMessageDialog(new JFrame(), "Preencha todos os campos", "Campos em branco", JOptionPane.WARNING_MESSAGE);
					return;
				}
				veiculo.setTipo(tipoCb.getSelectedItem().toString());
				veiculo.setNome(nomeTxt.getText());
			}
			
			if ((veiculoDao.buscarVeiculo(veiculo.getNome()) != null)) {
				JOptionPane.showMessageDialog(new JFrame(), "Ve�culo J� cadastrado!", "Erro!",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			veiculoDao.gravarVeiculo(veiculo);
			JOptionPane.showMessageDialog(new JFrame(), "Ve�culo cadastrado no sistema!", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
			dispose();
			new MainMenuAdmFrame();
		}
		
		if("cancela".equals(e.getActionCommand())){
			dispose();
			new MainMenuAdmFrame();
		}
		
		if(check.isSelected()){
			primariaTxt.setVisible(true);
			primariaTxtAr.setVisible(true);
			secundariaTxt.setVisible(true);
			secundariaTxtAr.setVisible(true);
			pack();
		}
		else{
			primariaTxt.setVisible(false);
			primariaTxtAr.setVisible(false);
			secundariaTxt.setVisible(false);
			secundariaTxtAr.setVisible(false);
			pack();
		}
		
	}

}
