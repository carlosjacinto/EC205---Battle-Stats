package control;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.Jogador;

public class JogadorDAO {

	DataBase bd = new DataBase();
	Connection conex = bd.Conectar();

	public String Login(String snome, String ssenha) {
		conex = bd.Conectar();

		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador";
			ResultSet rs = stmt.executeQuery(SQL);

			while (rs.next()) {

				String nome = rs.getString("email");
				// System.out.println(nome);
				// System.out.println(snome);
				String senha = rs.getString("senha");
				// System.out.println(ssenha);
				// System.out.println(senha);
				if (senha.equals(ssenha) && snome.equals(nome)) {
					return rs.getString("nomeDeUsuario");

				}
			}
			rs.close();
			stmt.close();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}

		return null;
	}

	public String LoginAdm(String snome, String ssenha) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM usuariosadmin WHERE email LIKE '" + snome + "' AND senha LIKE '" + ssenha + "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("email");
				String senha = rs.getString("senha");

				if (senha.equals(ssenha) && snome.equals(nome)) {
					return rs.getString("login");
				}
			}
			rs.close();
			stmt.close();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}

		return null;
	}

	public ResultSet buscarJogador(String snome, String semail) {
		// iop = 1 mostrar dados , 2 nao mostrar dados
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM jogador WHERE nomeDeUsuario LIKE '" + snome + "' OR email LIKE '" + semail
					+ "'";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nomeDeUsuario");
				String email = rs.getString("email");

				if (semail.toLowerCase().equals(email.toLowerCase())
						|| snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}
			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarJogador(Jogador j) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO Jogador(nomeDeUsuario, senha, nome, email, patente, kd, score, tempoJogo, classeFavorita, armaFavorita, veiculoFavorito)VALUES ('"
							+ j.getNomeDeUsuario() + "','" + j.getSenha() + "','" + j.getNome() + "','" + j.getEmail()
							+ "','" + j.getPatente() + "','" + j.getKd() + "','" + j.getScore() + "','"
							+ j.getTempoJogo() + "','" + j.getClasseFavorita() + "','" + j.getArmaFavorita() + "','"
							+ j.getVeiculoFavorito() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}
	}

}
