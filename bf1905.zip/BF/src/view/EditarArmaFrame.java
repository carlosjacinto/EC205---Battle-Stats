package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bancodedados.Banco;
import model.Arma;

public class EditarArmaFrame extends JPanel implements ActionListener {
	Banco bd = new Banco();
	Connection conex = bd.Conectar();
	/**
	 * 
	 */
	private static final long serialVersionUID = 8914113844849243183L;

	int id;
	String nome;
	int acess;

	JTextField nomeTxt = new JTextField(40);
	JTextField danoTxt = new JTextField(40);
	JTextField alcanceTxt = new JTextField(40);
	JTextField precisaoTxt = new JTextField(40);
	JTextField tiroSemVisadaTxt = new JTextField(40);
	JTextField estabilidadeTxt = new JTextField(40);
	JTextField cadenciaTxt = new JTextField(40);
	JTextField capacidadePenteTxt = new JTextField(40);

	JTextArea nomeTxtAr = new JTextArea("Nome:", 1, 10);
	JTextArea danoTxtAr = new JTextArea("Dano:", 1, 10);
	JTextArea alcanceTxtAr = new JTextArea("Alcance:", 1, 10);
	JTextArea precisaoTxtAr = new JTextArea("Precis�o:", 1, 10);
	JTextArea tiroSemVisadaTxtAr = new JTextArea("Tiro sem visada:", 1, 10);
	JTextArea estabilidadeTxtAr = new JTextArea("Estabilidade:", 1, 10);
	JTextArea cadenciaTxtAr = new JTextArea("Cad�ncia:", 1, 10);
	JTextArea capacidadePenteTxtAr = new JTextArea("Capacidade do pente:", 1, 10);

	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancela");

	String[] tipos = { "Assalto", "ADP", "M.L.", "Rifle de precis�o", "Carabina", "Escopeta", "DMR", "Pistola" };
	JComboBox<String> tipoArma = new JComboBox<String>(tipos);

	private static JFrame frame = new JFrame("Editar Arma");

	JPanel jp = new JPanel(new GridLayout(0, 1));

	public EditarArmaFrame(Arma a, int iid) {

		super(new BorderLayout());
		id = iid;
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");

		nomeTxtAr.setEditable(false);
		alcanceTxtAr.setEditable(false);
		precisaoTxtAr.setEditable(false);
		tiroSemVisadaTxtAr.setEditable(false);
		estabilidadeTxtAr.setEditable(false);
		cadenciaTxtAr.setEditable(false);
		capacidadePenteTxtAr.setEditable(false);
		
		nomeTxt.setText(a.getNome());
		tipoArma.setSelectedItem(a.getTipo());
		acess = a.getAcessorio();
		if (acess == 0) {
			
			 alcanceTxt.setText(""+a.getAlcance());
			 danoTxt.setText(""+a.getDano());
			 precisaoTxt.setText(""+a.getPrecisao());
			 tiroSemVisadaTxt.setText(""+a.getTiroSemVisada());
			 estabilidadeTxt.setText(""+a.getEstabilidade());
			 cadenciaTxt.setText(""+a.getCadencia());
			 capacidadePenteTxt.setText(""+a.getCapacidadeDoPente());
			 
		} else {
			alcanceTxt.setVisible(false);
			danoTxt.setVisible(false);
			precisaoTxt.setVisible(false);
			tiroSemVisadaTxt.setVisible(false);
			estabilidadeTxt.setVisible(false);
			cadenciaTxt.setVisible(false);
			capacidadePenteTxt.setVisible(false);
			alcanceTxtAr.setVisible(false);
			precisaoTxtAr.setVisible(false);
			tiroSemVisadaTxtAr.setVisible(false);
			estabilidadeTxtAr.setVisible(false);
			cadenciaTxtAr.setVisible(false);
			capacidadePenteTxtAr.setVisible(false);

		}
		
		
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tipoArma);
		jp.add(danoTxtAr);
		jp.add(danoTxt);
		jp.add(alcanceTxtAr);
		jp.add(alcanceTxt);
		jp.add(precisaoTxtAr);
		jp.add(precisaoTxt);
		jp.add(tiroSemVisadaTxtAr);
		jp.add(tiroSemVisadaTxt);
		jp.add(estabilidadeTxtAr);
		jp.add(estabilidadeTxt);
		jp.add(cadenciaTxtAr);
		jp.add(cadenciaTxt);
		jp.add(capacidadePenteTxtAr);
		jp.add(capacidadePenteTxt);
		jp.add(okBt);
		jp.add(cancelaBt);

		add(jp, BorderLayout.LINE_START);
	}

	boolean temCampoEmBranco() {
		if (nomeTxt.getText().equals(""))
			return true;
		if (danoTxt.getText().equals(""))
			return true;
		if (alcanceTxt.getText().equals(""))
			return true;
		if (precisaoTxt.getText().equals(""))
			return true;
		if (tiroSemVisadaTxt.getText().equals(""))
			return true;
		if (estabilidadeTxt.getText().equals(""))
			return true;
		if (cadenciaTxt.getText().equals(""))
			return true;
		if (capacidadePenteTxt.getText().equals(""))
			return true;
		return false;
	}

	public void editarArmaSQL(Arma a) {
		conex = bd.Conectar();
		//System.out.println(id);
		try {
			Statement stmt = conex.createStatement();

			ResultSet rs = stmt.executeQuery("Select * from arma WHERE nome ='" + a.getNome() + "'");
			while(rs.next()){
			if (id != rs.getInt("id")) {
				JOptionPane.showMessageDialog(frame, "J� existe uma arma no banco de dados com esse nome", "Erro",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			System.out.println(id);
			}
			System.out.println(id);
			stmt.execute("UPDATE Arma SET nome='" + a.getNome() + "', tipo='" + a.getTipo() + "', acessorio='"
					+ a.getAcessorio() + "', dano='" + a.getDano() + "', alcance='" + a.getAlcance() + "', precisao='"
					+ a.getPrecisao() + "', tiroSemVisada='" + a.getTiroSemVisada() + "', estabilidade ='"
					+ a.getEstabilidade() + "', cadencia='" + a.getCadencia() + "', capacidadeDoPente='"
					+ a.getCapacidadeDoPente() + "'  WHERE id='" + id + "' ");
			
			rs.close();
			stmt.close();

			// System.out.println("Altera��o feita com sucesso!!!");
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir SEU PORRRAAAA..." + sqle.getMessage());
		} finally {
			bd.Desconectar(conex);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if ("confirma".equals(e.getActionCommand())) {
			Arma arma = new Arma();
			if (!nomeTxt.getText().equals("")) {
				arma.setNome(nomeTxt.getText());
				arma.setTipo(tipoArma.getSelectedItem().toString());
				if (acess == 0) {
					if (temCampoEmBranco()) {
						JOptionPane.showMessageDialog(frame, "Preencha o campo nome", "Campo em branco",
						JOptionPane.WARNING_MESSAGE);
						return;
					}
					arma.setAcessorio(0);
					arma.setDano(Integer.parseInt(danoTxt.getText()));
					arma.setAlcance(Integer.parseInt(alcanceTxt.getText()));
					arma.setPrecisao(Integer.parseInt(precisaoTxt.getText()));
					arma.setTiroSemVisada(Integer.parseInt(tiroSemVisadaTxt.getText()));
					arma.setEstabilidade(Integer.parseInt(estabilidadeTxt.getText()));
					arma.setCadencia(Integer.parseInt(cadenciaTxt.getText()));
					arma.setCapacidadeDoPente(Integer.parseInt(capacidadePenteTxt.getText()));

				} else {
					arma.setAcessorio(1);
				}

				editarArmaSQL(arma);
				JOptionPane.showMessageDialog(frame, "Arma foi atualizada no sistema!", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
				frame.dispose();
				MainMenuAdmFrame.createAndShow();

			} else {
			}
		}else{
			frame.dispose();
			MainMenuAdmFrame.createAndShow();
		}
	}

	public void createAndShow(Arma a, int iid) {

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new EditarArmaFrame(a,iid));
		frame.setVisible(true);
		frame.pack();
		
		System.out.println(a.getNome());

		System.out.println(nomeTxt.getText());
		
		//System.out.println(id);
		nome = a.getNome();
		frame.pack();
		
	}
	


}
