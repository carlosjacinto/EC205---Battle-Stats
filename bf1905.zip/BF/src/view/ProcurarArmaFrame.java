package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bancodedados.Banco;
import model.Arma;

public class ProcurarArmaFrame extends JPanel implements ActionListener {
	Banco bd = new Banco();
	Connection conex = bd.Conectar();
	int id = 0;
	/**
	 * 
	 */
	private static final long serialVersionUID = -2825582222282271639L;

	JTextField nomeTxt = new JTextField(40);

	JTextArea nomeTxtAr = new JTextArea("Nome:", 1, 10);

	JButton okBt = new JButton("Confirmar");
	JButton cancelaBt = new JButton("Cancelar");

	private static JFrame frame = new JFrame("Procurar Arma");

	JPanel jp = new JPanel(new GridLayout(0, 1));

	public ProcurarArmaFrame() {
		super(new BorderLayout());

		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");

		nomeTxtAr.setEditable(false);

		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(okBt);
		jp.add(cancelaBt);

		add(jp, BorderLayout.LINE_START);

	}

	public Arma buscarArma(String snome) {
		// iop =1 mostra, 2 = nao
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM arma";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nome");

				if (snome.toLowerCase().equals(nome.toLowerCase())) {
					Arma a = new Arma();
					id = rs.getInt("id");
					a.setAcessorio(rs.getInt("acessorio"));
					a.setNome(rs.getString("nome"));
					a.setTipo(rs.getString("tipo"));
					if(a.getAcessorio()==0){
						a.setAlcance(rs.getInt("alcance"));
						a.setCadencia(rs.getInt("cadencia"));
						a.setCapacidadeDoPente(rs.getInt("capacidadeDoPente"));
						a.setDano(rs.getInt("dano"));
						a.setEstabilidade(rs.getInt("estabilidade"));
						a.setPrecisao(rs.getInt("precisao"));
						a.setTiroSemVisada(rs.getInt("tiroSemVisada"));
					}
					return a;
				}

			}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if ("confirma".equals(e.getActionCommand())) {
			if (nomeTxt.getText().equals("")) {
				JOptionPane.showMessageDialog(frame, "Preencha o campo nome", "Campo em branco",
						JOptionPane.WARNING_MESSAGE);
				return;
			}
			Arma a = new Arma();
			a = buscarArma(nomeTxt.getText());
			if (a == null) {
				JOptionPane.showMessageDialog(frame, "Arma n�o cadastrada", "Erro", JOptionPane.WARNING_MESSAGE);
				return;
			}

			EditarArmaFrame ed = new EditarArmaFrame(a,id);		
			ed.createAndShow(a, id);
			frame.dispose();

		} else {

		}

	}

	public static void createAndShow() {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new ProcurarArmaFrame());
		frame.setVisible(true);
		frame.pack();
	}

	public static void main(String[] args) {
		createAndShow();
	}

}
