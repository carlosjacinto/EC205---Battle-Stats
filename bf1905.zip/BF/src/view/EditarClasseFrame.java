package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bancodedados.Banco;
import model.Classe;

public class EditarClasseFrame extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = -585478044390968010L;
	
	Banco bd = new Banco();
	Connection conex = bd.Conectar();
	
	String[] tipos = {"Assalto", "ADP", "M.L.", "Rifle de precis�o"};
	JComboBox<String> tiposCb = new JComboBox<>(tipos);
	
	JTextArea nomeTxtAr = new JTextArea("Nome:",1,10);
	JTextArea tipoTxtAr = new JTextArea("Tipos de Arma:",1,10);
	JTextField nomeTxt = new JTextField(40);
	
	private static JFrame frame = new JFrame("Cadastro de classe");
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	
	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancela");
	
	public EditarClasseFrame(Classe classe, int iid) {
		super(new BorderLayout());
		
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		
		nomeTxtAr.setEditable(false);
		tipoTxtAr.setEditable(false);
		
		nomeTxt.setText(classe.getNome());
		tiposCb.setSelectedItem(classe.getTipo());
		
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tipoTxtAr);
		jp.add(tiposCb);
		jp.add(okBt);
		jp.add(cancelaBt);
		
		add(jp,BorderLayout.LINE_START);
		
	}
	
	boolean temCampoEmBranco(){
		if(nomeTxt.getText().equals("")) return true;
		return false;
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if("confirma".equals(e.getActionCommand().toString())){
			Classe classe = new Classe();
			if(temCampoEmBranco()){
				JOptionPane.showMessageDialog(frame, "Preencha o campo nome", "Campo em branco",
						JOptionPane.WARNING_MESSAGE);
						return;
			}
			classe.setNome(nomeTxt.getText());
			classe.setTipo(tiposCb.getSelectedItem().toString());
			
		}else{
			
		}
	}

}
