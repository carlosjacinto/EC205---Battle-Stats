package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bancodedados.Banco;
import model.Arma;
import model.Classe;

public class ProcurarClasseFrame extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4335329840747221249L;
	
	Banco bd = new Banco();
	Connection conex = bd.Conectar();
	int id = 0;
	
	JTextField nomeTxt = new JTextField(40);

	JTextArea nomeTxtAr = new JTextArea("Nome:", 1, 10);

	JButton okBt = new JButton("Confirmar");
	JButton cancelaBt = new JButton("Cancelar");

	private static JFrame frame = new JFrame("Procurar Arma");

	JPanel jp = new JPanel(new GridLayout(0, 1));
	
	public ProcurarClasseFrame(){
		super(new BorderLayout());

		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");

		nomeTxtAr.setEditable(false);

		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(okBt);
		jp.add(cancelaBt);

		add(jp, BorderLayout.LINE_START);
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if ("confirma".equals(e.getActionCommand())){
			if(nomeTxt.getText().equals("")){
				JOptionPane.showMessageDialog(frame, "Preencha o campo nome", "Campo em branco",
						JOptionPane.WARNING_MESSAGE);
				return;
			}
			Classe classe;
			classe = buscarClasse(nomeTxt.getText());
			
		}else{
			//Bot�o cancela
		}
		
	}
	
	public static void createAndShow() {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new ProcurarArmaFrame());
		frame.setVisible(true);
		frame.pack();
	}
	
	public Classe buscarClasse(String snome) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM classe";
			ResultSet rs = stmt.executeQuery(SQL);
			Classe classe = new Classe();
			while (rs.next()) {
				String nome = rs.getString("nome");
				
				if (snome.toLowerCase().equals(nome.toLowerCase())) {
					
					id = rs.getInt("id");
	
					classe.setNome(rs.getString("nome"));
					classe.setTipo(rs.getString("tipo"));
					
					}
					return classe;
				}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}
	
	public static void main(String[] args) {
		createAndShow();
	}
	
}
