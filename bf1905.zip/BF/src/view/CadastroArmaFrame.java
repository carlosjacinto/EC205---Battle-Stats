package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bancodedados.Banco;
import model.Arma;

public class CadastroArmaFrame extends JPanel implements ActionListener {
	Banco bd = new Banco();
	Connection conex = bd.Conectar();
	/**
	 * 
	 */
	private static final long serialVersionUID = 7180513158489494234L;

	String[] tipos = { "Assalto", "ADP", "M.L.", "Rifle de precis�o", "Carabina", "Escopeta", "DMR", "Pistola" };
	JComboBox<String> tiposArma = new JComboBox<>(tipos);

	JTextField nomeTxt = new JTextField(40);
	JTextField danoTxt = new JTextField(40);
	JTextField alcanceTxt = new JTextField(40);
	JTextField precisaoTxt = new JTextField(40);
	JTextField tiroSemVisadaTxt = new JTextField(40);
	JTextField estabilidadeTxt = new JTextField(40);
	JTextField cadenciaTxt = new JTextField(40);
	JTextField capacidadeTxt = new JTextField(40);
	JTextArea nomeTxtAr = new JTextArea("Nome", 1, 10);
	JTextArea danoTxtAr = new JTextArea("Dano", 1, 10);
	JTextArea alcanceTxtAr = new JTextArea("Alcance", 1, 10);
	JTextArea precisaoTxtAr = new JTextArea("Precis�o", 1, 10);
	JTextArea tiroSemVisadaTxtAr = new JTextArea("Tiro sem visada", 1, 10);
	JTextArea estabilidadeTxtAr = new JTextArea("Establilidade", 1, 10);
	JTextArea cadenciaTxtAr = new JTextArea("Cad�ncia", 1, 10);
	JTextArea capacidadeTxtAr = new JTextArea("Capacidade do pente", 1, 10);

	JButton okBt = new JButton("Confirmar");
	JButton cancelaBt = new JButton("Cancelar");

	JCheckBox check = new JCheckBox("Acess�rio");

	JPanel jp = new JPanel(new GridLayout(0, 1));

	private static JFrame frame = new JFrame("Cadastrar Arma");

	public CadastroArmaFrame() {
		super(new BorderLayout());

		nomeTxtAr.setEditable(false);
		danoTxtAr.setEditable(false);
		alcanceTxtAr.setEditable(false);
		precisaoTxtAr.setEditable(false);
		tiroSemVisadaTxtAr.setEditable(false);
		estabilidadeTxtAr.setEditable(false);
		cadenciaTxtAr.setEditable(false);
		capacidadeTxtAr.setEditable(false);

		check.addActionListener(this);

		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");

		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tiposArma);
		jp.add(check);
		jp.add(danoTxtAr);
		jp.add(danoTxt);
		jp.add(alcanceTxtAr);
		jp.add(alcanceTxt);
		jp.add(precisaoTxtAr);
		jp.add(precisaoTxt);
		jp.add(tiroSemVisadaTxtAr);
		jp.add(tiroSemVisadaTxt);
		jp.add(estabilidadeTxtAr);
		jp.add(estabilidadeTxt);
		jp.add(cadenciaTxtAr);
		jp.add(cadenciaTxt);
		jp.add(capacidadeTxtAr);
		jp.add(capacidadeTxt);
		jp.add(okBt);
		jp.add(cancelaBt);

		add(jp, BorderLayout.LINE_START);
	}

	boolean temCampoEmBranco() {
		if (nomeTxt.getText().equals(""))
			return true;
		if (danoTxt.getText().equals(""))
			return true;
		if (alcanceTxt.getText().equals(""))
			return true;
		if (precisaoTxt.getText().equals(""))
			return true;
		if (tiroSemVisadaTxt.getText().equals(""))
			return true;
		if (estabilidadeTxt.getText().equals(""))
			return true;
		if (cadenciaTxt.getText().equals(""))
			return true;
		if (capacidadeTxt.getText().equals(""))
			return true;
		return false;
	}

	public void actionPerformed(ActionEvent e) {

		if ("confirma".equals(e.getActionCommand())) {
			Arma novaArma = new Arma();
			if (!check.isSelected()) {
				if (temCampoEmBranco()) {
					JOptionPane.showMessageDialog(frame, "Preencha todos os campos", "Campos em branco",
							JOptionPane.WARNING_MESSAGE);
					return;
				}

				novaArma.setNome(nomeTxt.getText());
				novaArma.setTipo(tiposArma.getSelectedItem().toString());
				novaArma.setDano(Integer.parseInt(danoTxt.getText()));

				novaArma.setAcessorio(0);
				novaArma.setAlcance(Integer.parseInt(alcanceTxt.getText()));
				novaArma.setPrecisao(Integer.parseInt(precisaoTxt.getText()));
				novaArma.setTiroSemVisada(Integer.parseInt(tiroSemVisadaTxt.getText()));
				novaArma.setCadencia(Integer.parseInt(cadenciaTxt.getText()));
				novaArma.setCapacidadeDoPente(Integer.parseInt(capacidadeTxt.getText()));
				novaArma.setEstabilidade(Integer.parseInt(estabilidadeTxt.getText()));
			} else{
				novaArma.setNome(nomeTxt.getText());
				novaArma.setTipo(tiposArma.getSelectedItem().toString());
				novaArma.setAcessorio(1);
				if(nomeTxt.getText().equals("")){
					JOptionPane.showMessageDialog(frame, "Preencha todos os campos", "Campos em branco",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
			}
				

			if ((buscarArma(novaArma.getNome()) != null)) {
				JOptionPane.showMessageDialog(frame, "Arma j� cadastrada no sistema!", "Erro!",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			gravarArma(novaArma);
			JOptionPane.showMessageDialog(frame, "Arma cadastrada no sistema!", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
			frame.dispose();
			MainMenuAdmFrame.createAndShow();
		}
		if ("cancela".equals(e.getActionCommand())) {
			frame.dispose();
			MainMenuAdmFrame.createAndShow();
			return;
		}

		if (check.isSelected()) {
			danoTxt.setVisible(false);
			danoTxtAr.setVisible(false);
			alcanceTxt.setVisible(false);
			alcanceTxtAr.setVisible(false);
			precisaoTxt.setVisible(false);
			precisaoTxtAr.setVisible(false);
			tiroSemVisadaTxt.setVisible(false);
			tiroSemVisadaTxtAr.setVisible(false);
			estabilidadeTxt.setVisible(false);
			estabilidadeTxtAr.setVisible(false);
			cadenciaTxt.setVisible(false);
			cadenciaTxtAr.setVisible(false);
			capacidadeTxt.setVisible(false);
			capacidadeTxtAr.setVisible(false);
			frame.pack();
			return;
		} else {
			danoTxt.setVisible(true);
			danoTxtAr.setVisible(true);
			alcanceTxt.setVisible(true);
			alcanceTxtAr.setVisible(true);
			precisaoTxt.setVisible(true);
			precisaoTxtAr.setVisible(true);
			tiroSemVisadaTxt.setVisible(true);
			tiroSemVisadaTxtAr.setVisible(true);
			estabilidadeTxt.setVisible(true);
			estabilidadeTxtAr.setVisible(true);
			cadenciaTxt.setVisible(true);
			cadenciaTxtAr.setVisible(true);
			capacidadeTxt.setVisible(true);
			capacidadeTxtAr.setVisible(true);
			frame.pack();
		}

	}

	public ResultSet buscarArma(String snome) {
		// iop =1 mostra, 2 = nao
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM arma";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nome");

				if (snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarArma(Arma a) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO arma(nome, tipo, acessorio, dano, alcance, precisao, tiroSemVisada, estabilidade, cadencia, capacidadeDoPente)VALUES ('"
							+ a.getNome() + "','" + a.getTipo() + "','" + a.getAcessorio() + "','" + a.getDano() + "','"
							+ a.getAlcance() + "','" + a.getPrecisao() + "','" + a.getTiroSemVisada() + "','"
							+ a.getEstabilidade() + "','" + a.getCadencia() + "','" + a.getCapacidadeDoPente() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}

	}

	public static void createAndShow() {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new CadastroArmaFrame());
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		createAndShow();
	}

}
