package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MainMenuAdmFrame extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4814570971500803418L;
	
	JButton visualizarContasBt = new JButton("Visalisar contas");
	JButton excluirContasBt = new JButton("Excluir contas");
	JButton visualizarArmasBt = new JButton("Visalisar armas");
	JButton cadastrarArmasBt = new JButton("Cadastrar armas");
	JButton editarArmasBt = new JButton("Editar armas");
	JButton excluirArmasBt = new JButton("Excluir armas");
	JButton visualizarClassesBt = new JButton("Visalisar classes");
	JButton cadastrarClassesBt = new JButton("Cadastrar classes");
	JButton editarClassesBt = new JButton("Editar classes");
	JButton excluirClassesBt = new JButton("Excluir classes");
	JButton visualizarVeiculosBt = new JButton("Visalisar veiculos");
	JButton cadastrarVeiculosBt = new JButton("Cadastrar veiculos");
	JButton editarVeiculosBt = new JButton("Editar veiculos");
	JButton excluirVeiculosBt = new JButton("Excluir veiculos");
	JButton voltarBt = new JButton("Voltar");
	
	JPanel jp = new JPanel(new GridLayout(0, 1));
	JLabel background=new JLabel(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.1\\Images/Default.jpg"));
	
	public MainMenuAdmFrame() {
		
		setTitle("Main Menu");
		setSize(1366,768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setLayout(new BorderLayout());
		
		config();
		adicionar();
		refresh();
	}
	
	private void refresh(){
		setSize(1360,760);
		setSize(1366,768);
	}
	
	private void adicionar(){
		add(background);
		background.setLayout(new GridBagLayout());
		jp.add(visualizarContasBt);
		jp.add(excluirContasBt);
		jp.add(visualizarArmasBt);
		jp.add(cadastrarArmasBt);
		jp.add(editarArmasBt);
		jp.add(excluirArmasBt);
		jp.add(visualizarClassesBt);
		jp.add(cadastrarClassesBt);
		jp.add(editarClassesBt);
		jp.add(excluirClassesBt);
		jp.add(visualizarVeiculosBt);
		jp.add(cadastrarVeiculosBt);
		jp.add(editarVeiculosBt);
		jp.add(excluirVeiculosBt);
		jp.add(voltarBt);
		background.add(jp);
	}
	
	private void config(){
		visualizarContasBt.addActionListener(this);
		visualizarContasBt.setActionCommand("visualisarContas");
		visualizarContasBt.setBackground(new Color(255, 0, 0));
		visualizarContasBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		visualizarContasBt.setForeground(Color.WHITE);
		excluirContasBt.addActionListener(this);
		excluirContasBt.setActionCommand("excluirContas");
		excluirContasBt.setBackground(new Color(255, 0, 0));
		excluirContasBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		excluirContasBt.setForeground(Color.WHITE);
		visualizarArmasBt.addActionListener(this);
		visualizarArmasBt.setActionCommand("visualisarArmas");
		visualizarArmasBt.setBackground(new Color(255, 0, 0));
		visualizarArmasBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		visualizarArmasBt.setForeground(Color.WHITE);
		cadastrarArmasBt.addActionListener(this);
		cadastrarArmasBt.setActionCommand("cadastrarArmas");
		cadastrarArmasBt.setBackground(new Color(255, 0, 0));
		cadastrarArmasBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cadastrarArmasBt.setForeground(Color.WHITE);
		editarArmasBt.addActionListener(this);
		editarArmasBt.setActionCommand("editarArmas");
		editarArmasBt.setBackground(new Color(255, 0, 0));
		editarArmasBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		editarArmasBt.setForeground(Color.WHITE);
		excluirArmasBt.addActionListener(this);
		excluirArmasBt.setActionCommand("excluirArmas");
		excluirArmasBt.setBackground(new Color(255, 0, 0));
		excluirArmasBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		excluirArmasBt.setForeground(Color.WHITE);
		visualizarClassesBt.addActionListener(this);
		visualizarClassesBt.setActionCommand("visualisarClasses");
		visualizarClassesBt.setBackground(new Color(255, 0, 0));
		visualizarClassesBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		visualizarClassesBt.setForeground(Color.WHITE);
		cadastrarClassesBt.addActionListener(this);
		cadastrarClassesBt.setActionCommand("cadastrarClasses");
		cadastrarClassesBt.setBackground(new Color(255, 0, 0));
		cadastrarClassesBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cadastrarClassesBt.setForeground(Color.WHITE);
		editarClassesBt.addActionListener(this);
		editarClassesBt.setActionCommand("editarClasses");
		editarClassesBt.setBackground(new Color(255, 0, 0));
		editarClassesBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		editarClassesBt.setForeground(Color.WHITE);
		excluirClassesBt.addActionListener(this);
		excluirClassesBt.setActionCommand("excluirClasses");
		excluirClassesBt.setBackground(new Color(255, 0, 0));
		excluirClassesBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		excluirClassesBt.setForeground(Color.WHITE);
		visualizarVeiculosBt.addActionListener(this);
		visualizarVeiculosBt.setActionCommand("visualisarVeiculos");
		visualizarVeiculosBt.setBackground(new Color(255, 0, 0));
		visualizarVeiculosBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		visualizarVeiculosBt.setForeground(Color.WHITE);
		cadastrarVeiculosBt.addActionListener(this);
		cadastrarVeiculosBt.setActionCommand("cadastrarVeiculos");
		cadastrarVeiculosBt.setBackground(new Color(255, 0, 0));
		cadastrarVeiculosBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cadastrarVeiculosBt.setForeground(Color.WHITE);
		editarVeiculosBt.addActionListener(this);
		editarVeiculosBt.setActionCommand("editarVeiculos");
		editarVeiculosBt.setBackground(new Color(255, 0, 0));
		editarVeiculosBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		editarVeiculosBt.setForeground(Color.WHITE);
		excluirVeiculosBt.addActionListener(this);
		excluirVeiculosBt.setActionCommand("excluirVeiculos");
		excluirVeiculosBt.setBackground(new Color(255, 0, 0));
		excluirVeiculosBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		excluirVeiculosBt.setForeground(Color.WHITE);
		voltarBt.addActionListener(this);
		voltarBt.setActionCommand("voltar");
		voltarBt.setBackground(new Color(255, 0, 0));
		voltarBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		voltarBt.setForeground(Color.WHITE);
	}
	
	public void actionPerformed(ActionEvent e) {
		if("voltar".equals(e.getActionCommand())){
			
		}
		else if("visualizarContas".equals(e.getActionCommand())){
		}
		else if("excluirContas".equals(e.getActionCommand())){
		}
		else if("visualizarArmas".equals(e.getActionCommand())){
		}
		else if("cadastrarArmas".equals(e.getActionCommand())){
			
		}
		else if("editarArmas".equals(e.getActionCommand())){
		}
		else if("excluirArmas".equals(e.getActionCommand())){
		}
		else if("visualizarClasses".equals(e.getActionCommand())){
		}
		else if("cadastrarClasses".equals(e.getActionCommand())){
		}
		else if("editarClasses".equals(e.getActionCommand())){
		}
		else if("excluirClasses".equals(e.getActionCommand())){
		}
		else if("visualizarVeiculos".equals(e.getActionCommand())){
		}
		else if("cadastrarVeiculos".equals(e.getActionCommand())){
		}
		else if("editarVeiculos".equals(e.getActionCommand())){
		}
		else if("excluirVeiculos".equals(e.getActionCommand())){
		}
			
	}
	
	public static void main(String[] args) {
		new MainMenuAdmFrame();
	}
	
}
