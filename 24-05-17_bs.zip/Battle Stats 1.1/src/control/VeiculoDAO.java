package control;

public class VeiculoDAO {

}
