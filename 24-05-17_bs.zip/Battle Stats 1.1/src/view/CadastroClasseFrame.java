package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import control.DataBase;
import model.Classe;

public class CadastroClasseFrame extends JFrame implements ActionListener{
	
	DataBase bd = new DataBase();
	Connection conex = bd.Conectar();
	/**
	 * 
	 */
	private static final long serialVersionUID = 6228372735673803479L;

	private String[] tipos = {"Assalto", "ADP", "M.L.", "Rifle de precis�o"};
	JComboBox<String> tiposCb = new JComboBox<>(tipos);
	
	JTextArea nomeTxtAr = new JTextArea("Nome:",1,10);
	JTextArea tipoTxtAr = new JTextArea("Tipos de Arma:",1,10);
	JTextField nomeTxt = new JTextField(40);
	
	JButton okBt = new JButton("Confirma");
	JButton cancelaBt = new JButton("Cancela");
	
	JPanel jp = new JPanel(new GridLayout(0,1));
	JLabel background=new JLabel(new ImageIcon("C:\\Users\\Eduardo\\Documents\\Battle Stats 1.1\\Images/Default.jpg"));
	
	public CadastroClasseFrame() {

		setTitle("Cadastro de classe");
		setSize(1366,768);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setLayout(new BorderLayout());
		
		config();
		adicionar();
		
		refresh();
	}
	
	private void refresh(){
		setSize(1360,760);
		setSize(1366,768);
	}
	
	private void adicionar(){
		add(background);
		background.setLayout(new GridBagLayout());
		jp.add(nomeTxtAr);
		jp.add(nomeTxt);
		jp.add(tipoTxtAr);
		jp.add(tiposCb);
		jp.add(okBt);
		jp.add(cancelaBt);		
		background.add(jp);
	}
	
	private void config(){
		okBt.addActionListener(this);
		okBt.setActionCommand("confirma");
		okBt.setBackground(new Color(255, 0, 0));
		okBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		okBt.setForeground(Color.WHITE);
		cancelaBt.addActionListener(this);
		cancelaBt.setActionCommand("cancela");
		cancelaBt.setBackground(new Color(255, 0, 0));
		cancelaBt.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		cancelaBt.setForeground(Color.WHITE);
		nomeTxtAr.setEditable(false);
		nomeTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		nomeTxtAr.setBackground(new Color(0, 0, 0));
		nomeTxtAr.setForeground(Color.WHITE);
		tipoTxtAr.setEditable(false);
		tipoTxtAr.setFont(new Font("HelveticaNeue", Font.BOLD, 20));
		tipoTxtAr.setBackground(new Color(0, 0, 0));
		tipoTxtAr.setForeground(Color.WHITE);
	}
	
	boolean temCampoEmBranco(){
		if(nomeTxt.getText().equals("")) return true;
		return false;
	}
	
	public void actionPerformed(ActionEvent e) {
		if("confirma".equals(e.getActionCommand())){
			if(temCampoEmBranco()){
				JOptionPane.showMessageDialog(new JFrame(), "Preencha todos os campos", "Campos em branco", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			Classe classe = new Classe();
			classe.setNome(nomeTxt.getText());
			classe.setTipo(tiposCb.getSelectedItem().toString());
			if(buscarClasse(nomeTxt.getText())!=null){
				JOptionPane.showMessageDialog(new JFrame(), "Classe j� cadastrada no sistema!", "Classe j� existe!", JOptionPane.ERROR_MESSAGE);
				return;
			}
			JOptionPane.showMessageDialog(new JFrame(), "Classe cadastrada com sucesso!", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
			gravarClasse(classe);
			
		}
		else{
		}
	}
	
	
	public static void main(String[] args) {
		new CadastroClasseFrame();
	}
	
	public ResultSet buscarClasse(String snome) {
		conex = bd.Conectar();
		try {
			Statement stmt = (Statement) conex.createStatement();
			String SQL = "SELECT * FROM Classe";
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				String nome = rs.getString("nome");

				if (snome.toLowerCase().equals(nome.toLowerCase())) {
					return rs;
				}

			}

			rs.close();
			stmt.close();

		} catch (java.lang.Exception ex) {
			System.out.println("que bosta deu ruim aqui");
			ex.printStackTrace();

		} finally {
			bd.Desconectar(conex);
		}
		return null;
	}

	public boolean gravarClasse(Classe c) {
		conex = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute(
					"INSERT INTO Classe(nome, tipo)VALUES ('"+ c.getNome() + "','" + c.getTipo() + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}

	}

}
