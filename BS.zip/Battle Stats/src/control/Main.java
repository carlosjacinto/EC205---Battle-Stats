package control;

import model.Arma;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		ArrayList<Arma> armas = new ArrayList<>();
		Scanner inp = new Scanner(System.in);
		
		ArrayList<String> tipo = new ArrayList<>();
		tipo.add("1- Fuzil de assalto"); tipo.add("2- ADP"); tipo.add("3- M.L."); tipo.add("4- Rifle de precis�o"); tipo.add("5- Carabina"); tipo.add("6- DMR"); tipo.add("7- Escopeta"); tipo.add("8- Secundaria");

		int op=0;
		
		do{
			System.out.println("Menu:\n1-Cadastrar arma\n2-Listar arma\n3-Editar arma\n4-Excluir\n0-Sair");
			op = inp.nextInt();
			
			switch(op){
			
			case 1:
				Arma novaArma = new Arma();
				System.out.println("Nome da arma: ");
				novaArma.setNome(inp.next() + inp.nextLine());
				System.out.println("Dano: ");
				novaArma.setDano(inp.nextInt());
				System.out.println("Alcance: ");
				novaArma.setAlcance(inp.nextInt());
				System.out.println("Precisao: ");
				novaArma.setPrecisao(inp.nextInt());
				System.out.println("Tiro sem visada: ");
				novaArma.setTiroSemVisada(inp.nextInt());
				System.out.println("Estabilidade: ");
				novaArma.setEstabilidade(inp.nextInt());
				System.out.println("Cad�ncia: ");
				novaArma.setCadencia(inp.nextInt());
				System.out.println("Capacidade do pente: ");
				novaArma.setCapacidadeDoPente(inp.nextInt());
				armas.add(novaArma);
				break;
			case 2:
				int tm = armas.size();
				for(int i=0;i<tm;i++){
				}
				break;
			case 3:
				break;
			case 4:
				break;
			}
			
		}while(op!=0);
		
		inp.close();
	}
}
