package model;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import bancodedados.Banco;

public class Arma {
	Banco bd = new Banco();
	Connection conex = bd.Conectar();

	private String nome;
	private String tipo;
	private int acessorio = 0;
	private int dano;
	private int alcance;
	private int precisao;
	private int tiroSemVisada;
	private int estabilidade;
	private int cadencia;
	private int capacidadeDoPente;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int isAcessorio() {
		return acessorio;
	}

	public void setAcessorio(int acessorio) {
		this.acessorio = acessorio;
	}

	public int getDano() {
		return dano;
	}

	public void setDano(int dano) {
		this.dano = dano;
	}

	public int getAlcance() {
		return alcance;
	}

	public void setAlcance(int alcance) {
		this.alcance = alcance;
	}

	public int getPrecisao() {
		return precisao;
	}

	public void setPrecisao(int precisao) {
		this.precisao = precisao;
	}

	public int getTiroSemVisada() {
		return tiroSemVisada;
	}

	public void setTiroSemVisada(int tiroSemVisada) {
		this.tiroSemVisada = tiroSemVisada;
	}

	public int getEstabilidade() {
		return estabilidade;
	}

	public void setEstabilidade(int estabilidade) {
		this.estabilidade = estabilidade;
	}

	public int getCadencia() {
		return cadencia;
	}

	public void setCadencia(int cadencia) {
		this.cadencia = cadencia;
	}

	public int getCapacidadeDoPente() {
		return capacidadeDoPente;
	}

	public void setCapacidadeDoPente(int capacidadeDoPente) {
		this.capacidadeDoPente = capacidadeDoPente;
	}

	public boolean gravarArma(Arma a) {
		conex  = bd.Conectar();
		try {
			Statement stmt = conex.createStatement();
			stmt.execute("INSERT INTO arma(nome, tipo, acessorio, dano, alcance, precisao, tiroSemVisada, estabilidade, cadencia, capacidadeDoPente)VALUES ('"
							+ a.nome + "','" + a.tipo + "','" + a.acessorio + "','" + a.dano + "','" + a.alcance + "','"
							+ a.precisao + "','" + a.tiroSemVisada + "','" + a.estabilidade + "','" + a.cadencia + "','"
							+ a.capacidadeDoPente + "') ");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Erro ao inserir..." + sqle.getMessage());
			return false;
		} finally {
			bd.Desconectar(conex);
		}
		
		/*public boolean buscarArma(Arma a) {
			conex  = bd.Conectar();
			try {
				Statement stmt = conex.createStatement();
				stmt.execute(
						"INSERT INTO arma(nome, tipo, acessorio, dano, alcance, precisao, tiroSemVisada, estabilidade, cadencia, capacidadeDoPente)VALUES ('"
								+ a.nome + "','" + a.tipo + "','" + a.acessorio + "','" + a.dano + "','" + a.alcance + "','"
								+ a.precisao + "','" + a.tiroSemVisada + "','" + a.estabilidade + "','" + a.cadencia + "','"
								+ a.capacidadeDoPente + "') ");
				return true;
			} catch (SQLException sqle) {
				System.out.println("Erro ao inserir..." + sqle.getMessage());
				return false;
			} finally {
				bd.Desconectar(conex);
			}
		 	*/
	}
}
